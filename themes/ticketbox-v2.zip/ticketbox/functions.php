<?php
/**
 * ticketbox functions and definitions
 *
 * @package ticketbox
 */

$themeInfo            =  wp_get_theme();
$themeName            = trim($themeInfo['Title']);
$themeAuthor          = trim($themeInfo['Author']);
$themeAuthor_URI      = trim($themeInfo['AuthorURI']);
$themeVersion         = trim($themeInfo['Version']);

define('DAWNTHEMES_NAME', $themeName);
define('DAWNTHEMES_AUTHOR', $themeAuthor);
define('DAWNTHEMES_AUTHOR_URI', $themeAuthor_URI);
define('DAWNTHEMES_VERSION', $themeVersion);

if(!defined('MATUBE_DT_ASSETS_URI'))
	define('MATUBE_DT_ASSETS_URI', get_template_directory_uri() . '/assets');

/*
 * Require dt core
 * Dont edit this
 */
do_action('dawn_themes_includes');

include_once (get_template_directory() . '/includes/core/dawn-core.php');
if( is_admin() ){
	include_once (get_template_directory() . '/includes/admin/theme-options.php');
	include_once (get_template_directory() . '/includes/admin/meta-data.php');
	include_once (get_template_directory() . '/includes/admin/category-metadata.php');
}
/* Initialize Visual shodecode editor */
if( class_exists('WPBakeryVisualComposerAbstract') && class_exists('DawnThemes_VisualComposer') ){
	function requireVcExtend(){
		require_once ( get_template_directory().'/includes/vc-extend/vc_extend.php');
	}
	add_action('init', 'requireVcExtend', 2);
}

	
include_once (get_template_directory()	.'/includes/megamenu/megamenu.php');
include_once (get_template_directory() . '/includes/dt-functions.php');
include_once (get_template_directory() . '/includes/dt-hooks.php');
include_once (get_template_directory() . '/includes/widgets.php');

include_once (get_template_directory().'/includes/walker.php');
// Plugins Required - recommended
$plugin_path = get_template_directory() . '/includes/plugins';
if ( file_exists( $plugin_path . '/tgmpa_register.php' ) ) {
	include_once ( $plugin_path. '/tgm-plugin-activation.php');
	include_once ($plugin_path . '/tgmpa_register.php');
}

/*
 * scripts enqueue for admin
 */
function ticketbox_admin_js_and_css(){
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
}
add_action('admin_enqueue_scripts', 'ticketbox_admin_js_and_css');

/**
 * Set up the content width value based on the theme's design.
 *
 * @see dt_content_width()
 *
 */
$content_width = 1140;
if ( ! isset( $content_width ) ) {
	$content_width = 940; /* pixels */
}

if ( ! function_exists( 'ticketbox_setup' ) ) :
/**
 * ticketbox setup.
 *
 * Set up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 *
 */
function ticketbox_setup() {

	/*
	 * Make ticketbox available for translation.
	 *
	 * Translations can be added to the /languages/ directory.
	 * If you're building a theme based on dawn, use a find and
	 * replace to change 'ticketbox' to the name of your theme in all
	 * template files.
	 */
	load_theme_textdomain( 'ticketbox', get_template_directory() . '/languages' );
	
	//Setup the WordPress core custom background & custom header feature.
	add_theme_support( 'custom-background', apply_filters( 'ticketbox_custom_background_args', array(
	'default-color' => 'ffffff',
	) ) );
	add_theme_support( 'custom-header', apply_filters('ticketbox_custom_header_args', array()) );
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	*/
	// This theme styles the visual editor to resemble the theme style.
	add_editor_style('assets/css/editor-style.css');
	
	// Add RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );
	
	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	*/
	add_theme_support( 'title-tag' );
	
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
	// This theme uses its own gallery styles.
	add_filter( 'use_default_gallery_style', '__return_false' );
		

	// Enable support for Post Thumbnails, and declare two sizes.
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1140, 430, true );
	add_image_size( 'ticketbox-single-post-thumbnail-size', 1140, 430, true );
	
	add_image_size( 'ticketbox-posts-wg-thumbnail-size', 130, 73, true );
	// Listing 
	add_image_size( 'ticketbox-post-grid-thumbnail-size', 555, 210, true );
	/*
	 *  register thumbnail size for shortcodes
	 */
	add_image_size( 'ticketbox-thumbnail-640x360', 640, 360, true );
	add_image_size( 'ticketbox-thumbnail-415x234', 415, 234, true );
	// Post category

	/*
	 * Enable support for Post Formats.
	 * See https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array('video','gallery') );
	
	// This theme support woocommerce
	//add_theme_support( 'woocommerce' );
	
	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
	'primary'   => esc_html__( 'Primary Menu', 'ticketbox' ),
	//'secondary' => esc_html__( 'Secondary menu in Footer', 'ticketbox' ),
	) );
	
}
endif; // ticketbox_setup
add_action( 'after_setup_theme', 'ticketbox_setup' );

/**
 * Adjust content_width value for image attachment template.
 *
 */
function ticketbox_content_width() {
	if ( is_attachment() && wp_attachment_is_image() ) {
		$GLOBALS['content_width'] = 810;
	}
}
add_action( 'template_redirect', 'ticketbox_content_width' );

/**
 * Register widget areas.
 *
 */
function ticketbox_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Main Sidebar', 'ticketbox' ),
		'id'            => 'main-sidebar',
		'description'   => esc_html__( 'Main sidebar that appears on the right.', 'ticketbox' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title"><span>',
		'after_title'   => '</span></h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget #1', 'ticketbox' ),
		'id'            => 'footer-sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget #2', 'ticketbox' ),
		'id'            => 'footer-sidebar-2',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget #3', 'ticketbox' ),
		'id'            => 'footer-sidebar-3',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget #4', 'ticketbox' ),
		'id'            => 'footer-sidebar-4',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget #5', 'ticketbox' ),
		'id'            => 'footer-sidebar-5',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'ticketbox_widgets_init' );

/**
 * Register styles AND scripts
 */
function ticketbox_register_lib_assets(){
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	
	wp_register_style('slick', get_template_directory_uri() . '/assets/lib/slick/slick.css');
	wp_register_style('slick-theme', get_template_directory_uri() . '/assets/lib/slick/slick-theme.css');
	wp_register_script('slick', get_template_directory_uri() . '/assets/lib/slick/slick.min.js', array('jquery'), '1.5.9', false);
	
	wp_register_style('elegant-icon',get_template_directory_uri().'/assets/lib/elegant-icon/css/elegant-icon.css');
	
	wp_register_style( 'preloader', get_template_directory_uri().'/assets/lib/preloader/preloader.css', '1.0.0' );
	wp_register_script( 'preloader', get_template_directory_uri().'/assets/lib/preloader/preloader'.$suffix.'.js', array('jquery') , '1.0.0', false );
	
	wp_register_script( 'stellar', get_template_directory_uri().'/assets/lib/jquery.stellar'.$suffix.'.js', array('appear') , '2.0.4', true );
	
	wp_register_style( 'chosen', get_template_directory_uri().'/assets/lib/chosen/chosen.min.css', '1.1.0' );
	wp_register_script( 'chosen', get_template_directory_uri().'/assets/lib/chosen/chosen.jquery' . $suffix .'.js', array( 'jquery' ), '1.0.0', true );
	
	wp_register_script( 'ajax-chosen', get_template_directory_uri().'/assets/lib/chosen/ajax-chosen.jquery' . $suffix . '.js', array( 'jquery', 'chosen' ), '1.0.0', true );
	wp_register_script( 'appear', get_template_directory_uri().'/assets/lib/jquery.appear' . $suffix . '.js', array( 'jquery' ), '1.0.0', true );
	wp_register_script( 'typed', get_template_directory_uri().'/assets/lib/typed' . $suffix .'.js', array( 'jquery','appear' ), '1.0.0', true );
	wp_register_script( 'easing', get_template_directory_uri().'/assets/lib/easing' . $suffix . '.js', array( 'jquery' ), '1.3.0', true );
	wp_register_script( 'waypoints', get_template_directory_uri().'/assets/lib/waypoints' . $suffix . '.js', array( 'jquery' ), '2.0.5', true );
	wp_register_script( 'transit', get_template_directory_uri().'/assets/lib/jquery.transit' . $suffix . '.js', array( 'jquery' ), '0.9.12', true );
	wp_register_script( 'imagesloaded', get_template_directory_uri().'/assets/lib/imagesloaded.pkgd' . $suffix . '.js', array( 'jquery' ), '3.1.8', true );
	
	wp_register_script( 'requestAnimationFrame', get_template_directory_uri().'/assets/lib/requestAnimationFrame' . $suffix . '.js', null, '0.0.17', true );
	wp_register_script( 'parallax', get_template_directory_uri().'/assets/lib/jquery.parallax' . $suffix . '.js', array( 'jquery'), '1.1.3', true );
	
	wp_register_script( 'owl.carousel', get_template_directory_uri().'/assets/lib/owl-carousel/owl.carousel' . $suffix . '.js', array( 'jquery'), '1.3.3', true );
	wp_register_style( 'owl.theme', get_template_directory_uri().'/assets/lib/owl-carousel/owl.theme.css',array(), '1.3.3' );
	wp_register_style( 'owl.transitions', get_template_directory_uri().'/assets/lib/owl-carousel/owl.transitions.css',array(), '1.3.3' );
	wp_register_style( 'owl.carousel', get_template_directory_uri().'/assets/lib/owl-carousel/owl.carousel.css',array( 'owl.theme','owl.transitions'), '1.3.3' );
	
	wp_register_script( 'boostrap', get_template_directory_uri().'/assets/lib/bootstrap' . $suffix . '.js', array('jquery','imagesloaded'), '3.2.0', true );
	wp_register_script( 'superfish',get_template_directory_uri().'/assets/lib/superfish-1.7.4.min.js',array( 'jquery' ),'1.7.4',true );
	
	wp_register_script( 'countTo', get_template_directory_uri().'/assets/lib/jquery.countTo' . $suffix . '.js', array( 'jquery', 'appear' ), '2.0.2', true );
	wp_register_script( 'countdown', get_template_directory_uri().'/assets/lib/countdown/jquery.countdown.min.js', array('jquery'), '2.1.0', true);
	wp_register_script( 'infinitescroll', get_template_directory_uri().'/assets/lib/jquery.infinitescroll' . $suffix . '.js', array( 'jquery'), '2.1.0', true );
	
	wp_register_script( 'ProgressCircle', get_template_directory_uri().'/assets/lib/ProgressCircle' . $suffix . '.js', array( 'jquery','appear'), '2.0.2', true );
	
	wp_register_style( 'magnific-popup', get_template_directory_uri().'/assets/lib/magnific-popup/magnific-popup.css' );
	wp_register_script( 'magnific-popup', get_template_directory_uri().'/assets/lib/magnific-popup/jquery.magnific-popup' . $suffix . '.js', array( 'jquery'), '0.9.9', true );
	
	wp_register_script( 'touchSwipe', get_template_directory_uri().'/assets/lib/jquery.touchSwipe' . $suffix . '.js', array( 'jquery'), '1.6.6', true );
	
	wp_register_script( 'carouFredSel', get_template_directory_uri().'/assets/lib/jquery.carouFredSel' . $suffix . '.js', array( 'jquery','touchSwipe', 'easing','imagesloaded','transit'), '6.2.1', true );
	wp_register_script( 'isotope', get_template_directory_uri().'/assets/lib/isotope.pkgd' . $suffix . '.js', array( 'jquery', 'imagesloaded' ), '6.2.1', true );
	
	wp_register_script( 'easyzoom', get_template_directory_uri().'/assets/lib/easyzoom/easyzoom' . $suffix . '.js', array( 'jquery'), '0.9.9', true );
	wp_register_script( 'unveil', get_template_directory_uri().'/assets/lib/jquery.unveil' . $suffix . '.js', array( 'jquery'), '1.0.0', true );
	
}
add_action( 'template_redirect', 'ticketbox_register_lib_assets' );
/**
 * Enqueue styles
 */
function ticketbox_enqueue_theme_styles(){
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	$protocol = ticketbox_dt_get_protocol();
	$main_css_id = basename(get_template_directory());
	
	//Playfair Display
	ticketbox_dt_enqueue_google_font();
	if ( 'off' !== _x( 'on', 'Google font: on or off', 'ticketbox' ) ) {
		wp_enqueue_style('ticketbox-google-font','http://fonts.googleapis.com/css?family=Lato');
	}
	
	// Add Awesome font, used in the main stylesheet.
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '3.3.5' );
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/fonts/font-awesome/css/font-awesome.min.css', array(), '4.6.3');
	wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/css/animate.css', array());
	
	if ( class_exists( 'WPCF7_ContactForm' ) )
		wp_deregister_style( 'contact-form-7' );
	
	// Load our main stylesheet.
	wp_enqueue_style( $main_css_id, get_template_directory_uri() . '/assets/css/style' . $suffix . '.css', false, DAWNTHEMES_VERSION );
	
	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'ie', get_template_directory_uri() . '/assets/css/ie.css', array( 'ticketbox-style' ), '20131205' );
	wp_style_add_data( 'ie', 'conditional', 'lt IE 9' );

	// Custom CSS
	wp_register_style($main_css_id.'-wp',get_stylesheet_uri(),false,DAWNTHEMES_VERSION);
	do_action('ticketbox_main_inline_style', $main_css_id);
	wp_enqueue_style($main_css_id.'-wp');
}
add_action( 'wp_enqueue_scripts', 'ticketbox_enqueue_theme_styles' );
/**
 * Enqueue scripts
 */
function ticketbox_scripts() {
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	
	if ( is_singular() )
		wp_enqueue_script( 'comment-reply' );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_singular() && wp_attachment_is_image() ) {
		wp_enqueue_script( 'keyboard-image-navigation', get_template_directory_uri() . '/assets/js/keyboard-image-navigation.js', array( 'jquery' ), '20130402' );
	}
	
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '3.5.5', true );

	wp_register_script( 'dawnthemes-script', get_template_directory_uri() . '/assets/js/script'.$suffix.'.js', array( 'jquery' ), DAWNTHEMES_VERSION, true );
	$logo_retina = '';
	$DawnThemesL10n = array(
		'ajax_url'=>admin_url( 'admin-ajax.php', 'relative' ),
		'protocol'=>ticketbox_dt_get_protocol(),
		'navbarFixedHeight'=>50,
		'breakpoint'=>apply_filters('dt_js_breakpoint', 900),
		'nav_breakpoint'=>apply_filters('dt_nav_breakpoint', 900),
		'is_mobile_theme' => 'no',
		'cookie_path'=>COOKIEPATH,
		'screen_sm'=>768,
		'screen_md'=>992,
		'screen_lg'=>1200,
		'next'=>esc_attr__('Next','ticketbox'),
		'prev'=>esc_attr__('Prev','ticketbox'),
		'touch_animate'=>apply_filters('dt_js_touch_animate', true),
		'logo_retina'=>$logo_retina,
		'ajax_finishedMsg'=>esc_attr__('All posts displayed','ticketbox'),
		'ajax_msgText'=>esc_attr__('Loading the next set of posts...','ticketbox'),
		'woocommerce'=>(defined('WOOCOMMERCE_VERSION') ? 1 : 0),
		'imageLazyLoading'=>(dawnthemes_get_theme_option('woo-lazyload',1) ? 1 : 0),
		'add_to_wishlist_text'=>esc_attr(apply_filters('dt_yith_wishlist_is_active',defined( 'YITH_WCWL' )) ? apply_filters( 'dt_yith_wcwl_button_label', get_option( 'yith_wcwl_add_to_wishlist_text' )) : ''),
		'user_logged_in'=>(is_user_logged_in() ? 1 : 0),
		'loadingmessage'=>esc_attr__('Sending info, please wait...','ticketbox'),
	);
	wp_localize_script('dawnthemes-script', 'DawnThemesL10n', $DawnThemesL10n);
	wp_enqueue_script('dawnthemes-script');
}
add_action( 'wp_enqueue_scripts', 'ticketbox_scripts' );

if ( ! function_exists( 'ticketbox_renderurlajax' ) ) :
function ticketbox_renderurlajax() {
?>
	<script type="text/javascript">
		var ticketbox_dt_ajaxurl = '<?php echo esc_js( admin_url('admin-ajax.php') ); ?>';
	</script>
	<?php
}
add_action('wp_head', 'ticketbox_renderurlajax');
endif;

if ( ! function_exists( 'ticketbox_the_attached_image' ) ) :
/**
 * Print the attached image with a link to the next attached image.
 */
function ticketbox_the_attached_image() {
	$post = get_post();
	/**
	 * Filter the default attachment size.
	 *
	 * @param array $dimensions {
	 *     An array of height and width dimensions.
	 *
	 *     @type int $height Height of the image in pixels. Default 810.
	 *     @type int $width  Width of the image in pixels. Default 810.
	 * }
	 */
	$attachment_size     = apply_filters( 'dt_attachment_size', array( 810, 810 ) );
	$next_attachment_url = wp_get_attachment_url();

	/*
	 * Grab the IDs of all the image attachments in a gallery so we can get the URL
	 * of the next adjacent image in a gallery, or the first image (if we're
	 * looking at the last image in a gallery), or, in a gallery of one, just the
	 * link to that image file.
	 */
	$attachment_ids = get_posts( array(
		'post_parent'    => $post->post_parent,
		'fields'         => 'ids',
		'numberposts'    => -1,
		'post_status'    => 'inherit',
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'order'          => 'ASC',
		'orderby'        => 'menu_order ID',
	) );

	// If there is more than 1 attachment in a gallery...
	if ( count( $attachment_ids ) > 1 ) {
		foreach ( $attachment_ids as $attachment_id ) {
			if ( $attachment_id == $post->ID ) {
				$next_id = current( $attachment_ids );
				break;
			}
		}

		// get the URL of the next image attachment...
		if ( $next_id ) {
			$next_attachment_url = get_attachment_link( $next_id );
		}

		// or get the URL of the first image attachment.
		else {
			$next_attachment_url = get_attachment_link( reset( $attachment_ids ) );
		}
	}

	printf( '<a href="%1$s" rel="attachment">%2$s</a>',
		esc_url( $next_attachment_url ),
		wp_get_attachment_image( $post->ID, $attachment_size )
	);
}
endif;

if ( ! function_exists( 'ticketbox_list_authors' ) ) :
/**
 * Print a list of all site contributors who published at least one post.
 */
function ticketbox_list_authors() {
	$contributor_ids = get_users( array(
		'fields'  => 'ID',
		'orderby' => 'post_count',
		'order'   => 'DESC',
		'who'     => 'authors',
	) );

	foreach ( $contributor_ids as $contributor_id ) :
		$post_count = count_user_posts( $contributor_id );

		// Move on if user has not published a post (yet).
		if ( ! $post_count ) {
			continue;
		}
	?>

	<div class="contributor">
		<div class="contributor-info">
			<div class="contributor-avatar"><?php echo get_avatar( $contributor_id, 132 ); ?></div>
			<div class="contributor-summary">
				<h2 class="contributor-name"><?php echo get_the_author_meta( 'display_name', $contributor_id ); ?></h2>
				<p class="contributor-bio">
					<?php echo get_the_author_meta( 'description', $contributor_id ); ?>
				</p>
				<a class="button contributor-posts-link" href="<?php echo esc_url( get_author_posts_url( $contributor_id ) ); ?>">
					<?php printf( _n( '%d Article', '%d Articles', $post_count, 'ticketbox' ), $post_count ); ?>
				</a>
			</div><!-- .contributor-summary -->
		</div><!-- .contributor-info -->
	</div><!-- .contributor -->

	<?php
	endforeach;
}
endif;

/**
 * Extend the default WordPress body classes.
 *
 * Adds body classes to denote:
 * 1. Single or multiple authors.
 * 2. Presence of header image except in Multisite signup and activate pages.
 * 3. Index views.
 * 4. Full-width content layout.
 * 5. Presence of footer widgets.
 * 6. Single views.
 * 7. Featured content layout.
 *
 * @param array $classes A list of existing body class values.
 * @return array The filtered body class list.
 */
function ticketbox_body_classes( $classes ) {
	$theme_mode =  dawnthemes_get_theme_option('theme-mode','');
	if( $theme_mode == 'dark' )
		$classes[] = 'dark-mode';
	
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	$header_layout = dawnthemes_get_theme_option('header_layout','header-1');
	$classes[] = 'style-'.$header_layout;

	if ( is_archive() || is_search() || is_home() ) {
		wp_enqueue_style('slick');
		wp_enqueue_script('slick');
	}

	if ( ( ! is_active_sidebar( 'sidebar-2' ) )
		|| is_page_template( 'page-templates/full-width.php' )
		|| is_page_template( 'page-templates/front-page.php' )
		|| is_attachment() ) {
		$classes[] = 'full-width';
	}

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		$classes[] = 'footer-widgets';
	}

	if ( is_singular() && ! is_front_page() ) {
		$classes[] = 'singular';
	}
	
	// Sticky menu
	if( dawnthemes_get_theme_option('sticky-menu', '1') == '1' ){
		$classes[]	= 'sticky-menu';
	}

	return $classes;
}
add_filter( 'body_class', 'ticketbox_body_classes' );

/**
 * Extend the default WordPress post classes.
 *
 * Adds a post class to denote:
 * Non-password protected page with a post thumbnail.
 *
 * @param array $classes A list of existing post class values.
 * @return array The filtered post class list.
 */
function ticketbox_post_classes( $classes ) {
	if ( ! post_password_required() && ! is_attachment() && has_post_thumbnail() ) {
		$classes[] = 'has-post-thumbnail';
	}

	return $classes;
}
add_filter( 'post_class', 'ticketbox_post_classes' );

/**
 * Create a nicely formatted and more specific title element text for output
 * in head of document, based on current view.
 *
 * @global int $paged WordPress archive pagination page count.
 * @global int $page  WordPress paginated post page count.
 *
 * @param string $title Default title text for current view.
 * @param string $sep Optional separator.
 * @return string The filtered title.
 */
function ticketbox_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() ) {
		return $title;
	}

	// Add the site name.
	$title .= get_bloginfo( 'name', 'display' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) ) {
		$title = "$title $sep $site_description";
	}

	// Add a page number if necessary.
	if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
		$title = "$title $sep " . sprintf( __( 'Page %s', 'ticketbox' ), max( $paged, $page ) );
	}

	return $title;
}
add_filter( 'wp_title', 'ticketbox_wp_title', 10, 2 );

if ( ! function_exists( 'ticketbox_comment' ) ) :
/**
 * Template for comments and pingbacks.
*
* To override this walker in a child theme without modifying the comments template
* simply create your own dt_comment(), and that function will be used instead.
*
* Used as a callback by wp_list_comments() for displaying the comments.
*/
function ticketbox_dt_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
	case 'pingback' :
	case 'trackback' :
		// Display trackbacks differently than normal comments.
		?>
 	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
 		<p><?php esc_html_e( 'Pingback:', 'ticketbox' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( '(Edit)', 'ticketbox' ), '<span class="edit-link">', '</span>' ); ?></p>
 	<?php
 			break;
 		default :
 		// Proceed with normal comments.
 		global $post;
 	?>
 	<li <?php comment_class('block-author author'); ?> id="li-comment-<?php comment_ID(); ?>">
 		<div id="comment-<?php comment_ID(); ?>" class="comment">
 			<div class="blog-img-wrap">
	 			<a href="<?php  echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>" class="image">
	 			<?php
	 				echo get_avatar( $comment, 70);
	 			?>
	 			</a>
 			</div>
 			<div class="group author-content">
 				<div class="meta box-left">
 					<div class="comment-author font-2">
 					<?php
 						printf( '<span class="fn author">%1$s</span>',
 							get_the_author_meta('display_name')
 						);
 					?>
 					</div>
 					<div class="date">
 					<?php 
 						printf( '<time datetime="%2$s" class="date">%3$s</time>',
 								esc_url( get_comment_link( $comment->comment_ID ) ),
 								get_comment_time( 'c' ),
 								/* translators: 1: date, 2: time */
 								sprintf( __( '%1$s  at %2$s ', 'ticketbox' ), get_comment_date(), get_comment_time() )
 							);?>
 					</div>
 							
 				</div>
 				
 				<div class="box-right">
                       <?php comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'ticketbox' ), 'after' => ' <span></span>', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
 					<!-- .reply -->
                </div>
                
 				<div class="cmt box-comment">					
 					<?php if ( '0' == $comment->comment_approved ) : ?>
 					<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'ticketbox' ); ?></p>					
 				<?php endif; ?>
 					<?php comment_text(); ?>
 					<?php
 						edit_comment_link( esc_html__( 'Edit', 'ticketbox' ), '<p class="edit-link">', '</p>' ); ?>
 				</div><!-- .comment-content -->
             </div><!-- .comment-meta -->
 		</div><!-- #comment-## -->
 	<?php
 		break;
 	endswitch; // end comment_type check
 }
 endif;

 
 //change comment form
 if(!function_exists('ticketbox_dt_comment_form')){
 	function ticketbox_dt_comment_form( $args = array(), $post_id = null ) {
 		if ( null === $post_id )
 			$post_id = get_the_ID();
 		else
 			$id = $post_id;
 
 		$commenter = wp_get_current_commenter();
 		$user = wp_get_current_user();
 		$user_identity = $user->exists() ? $user->display_name : '';
 
 		$args = wp_parse_args( $args );
 		if ( ! isset( $args['format'] ) )
 			$args['format'] = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : 'xhtml';
 
 		$req      = get_option( 'require_name_email' );
 		$aria_req = ( $req ? " aria-required='true'" : '' );
		$html_req = ( $req ? " required='required'" : '' );
		$html5    = 'html5' === $args['format'];
 		$fields   =  array(
 			'author' => '<div class="row"><div class="col-md-4 comment-form-author">' . '<label for="author" class="hidden">' . esc_html__( 'Name', 'ticketbox') . ( $req ? ' <span class="required">*</span>' : '' ) . '</label> ' .
 						'<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . $html_req . ' placeholder="'. ($req ? esc_html__('Your Name *','ticketbox') : esc_html__('Your Name','ticketbox')).'" /></div>',
 			'email'  => '<div class="col-md-4 comment-form-email"><label for="email" class="hidden">' . esc_html__( 'Email', 'ticketbox' ) . ( $req ? ' <span class="required">*</span>' : '' ) . '</label> ' .
 						'<input id="email" class="l" name="email" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . $html_req . ' placeholder="'.( $req ? esc_html__('Your Email *','ticketbox') : esc_html__('Your Email','ticketbox')).'" /></div>',
 			'url'    => '<div class="col-md-4 comment-form-url"><label for="url" class="hidden">' . esc_html__( 'Website', 'ticketbox' ) . '</label> ' .
 						'<input id="url" class="" name="url" ' . ( $html5 ? 'type="url"' : 'type="text"' ) . ' value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" placeholder="'. ($req ? esc_html__('Website','ticketbox') : esc_html__('Website','ticketbox')).'"  /></div></div>',
 		);
 
 		$required_text = sprintf( ' ' . __('Required fields are marked %s', 'ticketbox'), '<span class="required">*</span>' );
 		if ( comments_open( $post_id ) ) :
 		/**
 		 * Filter the default comment form fields.
 		 *
 		 * @since 3.0.0
 		 *
 		 * @param array $fields The default comment fields.
 		 */
 		$fields = apply_filters( 'comment_form_default_fields', $fields );
 		$defaults = array(
 			'fields'               => $fields,
 			'comment_field'        => '<p class="comment-form-comment"><label for="comment" class="hidden">' . _x( 'Comment', 'noun', 'ticketbox') . '</label> <textarea id="comment" name="comment" cols="25" rows="8" aria-required="true" class="" placeholder="'.esc_html__('Your Comment *','ticketbox').'"></textarea></p>',
 			'must_log_in'          => '<p class="must-log-in">' . sprintf( __( 'You must be <a href="%s">logged in</a> to post a comment.' ,'ticketbox' ), wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
 			'logged_in_as'         => '<p class="logged-in-as">' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>','ticketbox'), get_edit_user_link(), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
 			'comment_notes_before' => '<p class="comment-notes"><span id="email-notes">' . esc_html__( 'Your email address will not be published.', 'ticketbox' ) . '</span>'. ( $req ? $required_text : '' ) . '</p>',
 			'comment_notes_after'  => '',
 			'id_form'              => 'commentform',
 			'id_submit'            => 'submit',
 			'title_reply'          => esc_html__( 'Leave a Reply','ticketbox' ),
 			'title_reply_to'       => esc_html__( 'Leave a Reply to %s','ticketbox'  ),
 			'cancel_reply_link'    => esc_html__( 'Cancel reply','ticketbox'  ),
 			'label_submit'         => esc_html__( 'Post comment' ,'ticketbox' ),
 			'format'               => 'xhtml',
 		);
 	
 		comment_form( $defaults );
 		endif;
 	}
 }
 
 /*-----------------------------------------------------------------------------------*/
 /* You can add custom functions below */
 /*-----------------------------------------------------------------------------------*/
 
 
 
 
 
 
 /*-----------------------------------------------------------------------------------*/
 /* Don't add any code below here or the sky will fall down */
 /*-----------------------------------------------------------------------------------*/
 ?>