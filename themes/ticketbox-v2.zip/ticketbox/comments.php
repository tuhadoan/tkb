<?php
/**
 * The template for displaying Comments
 *
 * The area of the page that contains comments and the comment form.
 *
 * @package dawn
 */

/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>

	<h2 class="comments-title">
		<span>
		<?php
			echo get_comments_number_text( esc_html__('Leave a comment', 'ticketbox'), esc_html__('1 Comment', 'ticketbox'), get_comments_number() . esc_html__(' Comments', 'ticketbox') );
		?>
		</span>
	</h2>

	<?php the_comments_navigation(); ?>

	<ol class="comment-list">
		<?php
			wp_list_comments( array(
				'style'       => 'ol',
				'short_ping'  => true,
				'avatar_size' => 70,
				'callback' => 'ticketbox_dt_comment',
			) );
		?>
	</ol><!-- .comment-list -->

	<?php the_comments_navigation(); ?>

	<?php 
		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'ticketbox' ); ?></p>
	<?php endif; ?>

	<?php endif; // have_comments() ?>

	<?php
		ticketbox_dt_comment_form();
	?>

</div><!-- #comments -->
