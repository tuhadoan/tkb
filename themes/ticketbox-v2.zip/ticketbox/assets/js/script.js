;(function($){
  'use strict';
  var body = $( 'body' ),
    $win = $( window );
  
  var dtLoadmore = function(element, options,callback){
     this.$element    = $(element);
     this.callback = callback;
     this.options = $.extend({},dtLoadmore.defaults, options);
     this.contentSelector = this.options.contentSelector || this.$element.find('.loadmore-wrap');
     this.options.contentSelector = this.contentSelector;
     this.init();
  }
  dtLoadmore.defaults = {
      contentSelector: null,
      nextSelector: "div.navigation a:first",
      navSelector: "div.navigation",
      itemSelector: "div.post",
      dataType: 'html',
      finishedMsg: "<em>Congratulations, you've reached the end of the internet.</em>",
      maxPage: undefined,
      loading:{
        speed:0,
        start: undefined
      },
      state: {
            isDuringAjax: false,
            isInvalidPage: false,
            isDestroyed: false,
            isDone: false, // For when it goes all the way through the archive.
          isPaused: false,
          isBeyondMaxPage: false,
          currPage: 1
      }
  };
  dtLoadmore.prototype.init = function(){
    this.create();
  }
  dtLoadmore.prototype.create = function(){
   var self       = this, 
    $this       = this.$element,
    contentSelector = this.contentSelector,
    action      = this.action,
    btn       = this.btn,
    loading     = this.loading,
    options     = this.options;
    
    var _determinepath = function(path){
      if (path.match(/^(.*?)\b2\b(.*?$)/)) {
               path = path.match(/^(.*?)\b2\b(.*?$)/).slice(1);
           } else if (path.match(/^(.*?)2(.*?$)/)) {
               if (path.match(/^(.*?page=)2(\/.*|$)/)) {
                   path = path.match(/^(.*?page=)2(\/.*|$)/).slice(1);
                   return path;
               }
               path = path.match(/^(.*?)2(.*?$)/).slice(1);

           } else {
               if (path.match(/^(.*?page=)1(\/.*|$)/)) {
                   path = path.match(/^(.*?page=)1(\/.*|$)/).slice(1);
                   return path;
               } else {
                options.state.isInvalidPage = true;
               }
           }
      return path;
    }
    if(!$(options.nextSelector).length){
      return;
    }
    
    // callback loading
    options.callback = function(data, url) {
           if (self.callback) {
            self.callback.call($(options.contentSelector)[0], data, options, url);
           }
       };
       
       options.loading.start = function($btn) {
        if(options.state.isBeyondMaxPage)
          return;
          $btn.hide();
               $(options.navSelector).hide();
               $btn.closest('.loadmore-action').find('.loadmore-loading').show(options.loading.speed, $.proxy(function() {
                loadAjax(options,$btn);
               }, self));
        };
    
    var loadAjax = function(options,$btn){
      var path = $(options.nextSelector).attr('href');
        path = _determinepath(path);
      
      var callback=options.callback,
        desturl,frag,box,children,data;
      
      options.state.currPage++;
      options.maxPage = $(options.contentSelector).data('maxpage') || options.maxPage;
      // Manually control maximum page
           if ( options.maxPage !== undefined && options.state.currPage > options.maxPage ){
            options.state.isBeyondMaxPage = true;
               return;
           }
           desturl = path.join(options.state.currPage);
           box = $('<div/>');
           box.load(desturl + ' ' + options.itemSelector,undefined,function(responseText){
            children = box.children();
            if (children.length === 0) {
              $btn.closest('.loadmore-action').find('.loadmore-loading').hide(options.loading.speed,function(){
                options.state.isBeyondMaxPage = true;
                $btn.html(options.finishedMsg).show();
              });
                   return ;
               }
            frag = document.createDocumentFragment();
               while (box[0].firstChild) {
                   frag.appendChild(box[0].firstChild);
               }
               $(options.contentSelector)[0].appendChild(frag);
               data = children.get();
               $btn.closest('.loadmore-action').find('.loadmore-loading').hide();
               if(options.maxPage !== undefined && options.maxPage == options.state.currPage ){
                options.state.isBeyondMaxPage = true;
                $btn.html(options.finishedMsg);
               }
               $btn.show(options.loading.speed);
               options.callback(data);
              
           });
    }
    
    
    $(document).on('click','[data-paginate="loadmore"] .btn-loadmore',function(e){
       e.stopPropagation();
       e.preventDefault();
       options.loading.start.call($(options.contentSelector)[0],$(this));
    });
  }
  
  
  dtLoadmore.prototype.update = function(key){
    if ($.isPlainObject(key)) {
           this.options = $.extend(true,this.options,key);
       }
  }
  $.fn.dtLoadmore = function(options,callback){
    var thisCall = typeof options;
    switch (thisCall) {
           // method
           case 'string':
               var args = Array.prototype.slice.call(arguments, 1);
               this.each(function () {
                   var instance = $.data(this, 'dtloadmore');
                   if (!instance) {
                       return false;
                   }
                   if (!$.isFunction(instance[options]) || options.charAt(0) === '_') {
                       return false;
                   }
                   instance[options].apply(instance, args);
               });
  
           break;
  
           case 'object':
               this.each(function () {
                 var instance = $.data(this, 'dtloadmore');
                 if (instance) {
                     instance.update(options);
                 } else {
                     instance = new dtLoadmore(this, options, callback);
                     $.data(this, 'dtloadmore', instance);
                 }
             });
  
           break;
  
       }

    return this;
  };
}(window.jQuery));
(function($) {
  'use strict';
  $.fn.dt_mediaelementplayer = function(options){
    var defaults = {};
        options = $.extend(defaults, options);
        return this.each(function() {
            var el = $(this);
            el.attr('width', '100%').attr('height', '100%');
            $(el).closest('.video-embed-wrap').each(function() {
                var aspectRatio = $(this).height() / $(this).width();
                $(this).attr('data-aspectRatio', aspectRatio).css({
                    'height': $(this).width() * aspectRatio + 'px',
                    'width': '100%'
                });
            });
            el.mediaelementplayer({
                mode: 'auto',
                defaultVideoWidth: '100%',
                defaultVideoHeight: '100%',
                videoWidth: '100%',
                videoHeight: '100%',
                audioWidth: "100%",
                audioHeight: 30,
                startVolume: 0.8,
                loop: false,
                enableAutosize: true,
                features: ['playpause', 'progress', 'duration', 'volume', 'fullscreen'],
                alwaysShowControls: false,
                iPadUseNativeControls: false,
                iPhoneUseNativeControls: false,
                AndroidUseNativeControls: false,
                alwaysShowHours: false,
                showTimecodeFrameCount: false,
                framesPerSecond: 25,
                enableKeyboard: true,
                pauseOtherPlayers: true,
                keyActions: [],
            });
            window.setTimeout(function() {
                $(el).closest('.video-embed-wrap').css({
                    'height': '100%',
                    'width': '100%'
                });
            }, 1000);
            $(el).closest('.mejs-container').css({
                'height': '100%',
                'width': '100%'
            });
        });
  };
}(window.jQuery));
(function() {
    'use strict';
    var lastTime = 0;
    var vendors = ['ms', 'moz', 'webkit', 'o'];
    for (var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
        window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
        window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] || window[vendors[x] + 'CancelRequestAnimationFrame'];
    }
    if (!window.requestAnimationFrame) window.requestAnimationFrame = function(callback) {
        var currTime = new Date().getTime();
        var timeToCall = Math.max(0, 16 - (currTime - lastTime));
        var id = window.setTimeout(function() {
            callback(currTime + timeToCall);
        }, timeToCall);
        lastTime = currTime + timeToCall;
        return id;
    };
    if (!window.cancelAnimationFrame) window.cancelAnimationFrame = function(id) {
        clearTimeout(id);
    };
}());
(function($){
  var DawnThemes = window.DawnThemes || {};
  'use strict';
  var body = $( 'body' ),
    $win = $( window );
  DawnThemes.getNavbarFixedHeight = function() {
        return parseInt(DawnThemesL10n.navbarFixedHeight);
    };
    DawnThemes.userAgent = {
        isIE7: false,
        isIE8: false,
        isLowIE: false,
        isAndroid: false,
        isTouch: false,
        isIOS: false,
        init: function() {
            var appVersion = navigator.appVersion,
                userAgent = navigator.userAgent;
            DawnThemes.userAgent.isIE7 = appVersion.indexOf("MSIE 7.") !== -1;
            DawnThemes.userAgent.isIE8 = appVersion.indexOf("MSIE 8.") !== -1;
            DawnThemes.userAgent.isLowIE = DawnThemes.userAgent.isIE7 || DawnThemes.userAgent.isIE8;
            DawnThemes.userAgent.isAndroid = (/android/gi).test(appVersion);
            DawnThemes.userAgent.isIOS = (/iphone|ipad|ipod/gi).test(appVersion);
            DawnThemes.userAgent.isTouch = !!('ontouchstart' in window) || (!!('onmsgesturechange' in window) && !!window.navigator.maxTouchPoints);
            if (/(iPad|iPhone|iPod)/g.test(userAgent)) {
                $(document.documentElement).addClass('dt-os-ios');
            } else if (userAgent.toLowerCase().indexOf("android") > -1) {
                $(document.documentElement).addClass('dt-os-android');
            } else if (-1 !== userAgent.indexOf('Mac OS X')) {
                $(document.documentElement).addClass('dt-os-mac');
            } else if (-1 !== appVersion.indexOf("Win")) {
                $(document.documentElement).addClass('dt-os-win');
            }
            if (/chrom(e|ium)/.test(userAgent.toLowerCase())) {
                $(document.documentElement).addClass('dt-browser-chrome');
            } else if (-1 !== userAgent.indexOf('Firefox')) {
                $(document.documentElement).addClass('dt-browser-firefox');
            } else if (-1 !== userAgent.indexOf('Safari') && -1 === userAgent.indexOf('Chrome')) {
                $(document.documentElement).addClass('dt-browser-safari');
            } else if (userAgent.indexOf('MSIE') !== -1 || userAgent.indexOf('Trident/') > 0) {
                $(document.documentElement).addClass('dt-browser-ie');
            }
        }
    };
  DawnThemes.Event = {
    scrollTop: 0,
        runScrollEvent: false,
        runResizeEvent: false,
        windowpageYOffset: window.pageYOffset,
        windowHeight: window.innerHeight,
        windowWidth: window.innerWidth,
        init: function(){

          // remove DT preload
          $('.dt-post-category, .dt-posts-slider').removeClass('dt-preload');

          // Smart Content Box shortcode
          if( $('.dt-smart-content-box').length ){
            var $window = $( window );
            var $windowW = $window.width();

            var DTSmartContentBox = function($windowW, isResize){
              if($windowW <= 1200){
                var $blockBig = $('.dt-smart-content-box .smart-content-box__wrap .dt-smcb-block1 .dt-module-thumb');
                var $blockBigW = $blockBig.width();
                var $blockBigH = Math.round($blockBigW * 0.8052);
                $('.dt-smart-content-box .smart-content-box__wrap .dt-smcb-block1 .dt-module-thumb').css("height", $blockBigH);

                var $blockList = $('.dt-smart-content-box .smart-content-box__wrap .dt-smcb-block2 .dt-module-thumb');
                var $blockListW = $blockList.width();
                var $blockListH = Math.round($blockListW * 0.568);
                $('.dt-smart-content-box .smart-content-box__wrap .dt-smcb-block2 .dt-module-thumb, .dt-smart-content-box .smart-content-box__wrap .dt-smcb-block3 .dt-module-thumb').css("height", $blockListH);
              }else{
                $('.dt-smart-content-box .smart-content-box__wrap .dt-smcb-block1 .dt-module-thumb').attr("style", '');
                $('.dt-smart-content-box .smart-content-box__wrap .dt-smcb-block2 .dt-module-thumb, .dt-smart-content-box .smart-content-box__wrap .dt-smcb-block3 .dt-module-thumb').attr("style", '');
              }
            }
            DTSmartContentBox($windowW, true );
            $window.resize(function(){
              $windowW = $window.width();
              DTSmartContentBox($windowW, true);
            });
          }
          DawnThemes.menu_toggle();
          DawnThemes.menu();
          DawnThemes.scrollToTOp();
          
          //Responsive embed iframe
          DawnThemes.responsiveEmbedIframe();
          $(window).resize(function(){
            DawnThemes.responsiveEmbedIframe();
          });
          
          $(window).resize(function(){
            $('[data-layout="masonry"]').each(function(){
              var $this = $(this),
                container = $this.find('.masonry-wrap');
                container.isotope( 'layout' );
            });
          });
          
          // ajax load next-prev content
          DawnThemes.ajax_nav_content();

          DawnThemes.userAgent.init();
          DawnThemes.SmartSidebar.init();
          
          $(window).on('load', function() {
            DawnThemes.helperInit();
            
             if ($('.smartsidebar').length) DawnThemes.SmartSidebar.addItem({
                     content: $('.main-content'),
                     sidebar: $('.smartsidebar')
                 });
             if ($('.vc-as-smartsidebar').length) {
                     $('.vc-as-smartsidebar').each(function() {
                         var _this = $(this),
                             sidebar = _this.children('.wpb_wrapper'),
                             content = _this.closest('.vc_row').children('.vc_col-sm-8, .vc_col-sm-9').find('.wpb_wrapper');
                         DawnThemes.SmartSidebar.addItem({
                             content: content,
                             sidebar: sidebar
                         });
                     });
                 }
            
            DawnThemes.SmartSidebar.onResize();
          });
          
          $(window).on('scroll', function() {
            DawnThemes.Event.scrollTop = $(window).scrollTop();
            DawnThemes.Event.runScrollEvent = true;
            DawnThemes.Event.windowpageYOffset = window.pageYOffset;
            DawnThemes.SmartSidebar.onScroll(DawnThemes.Event.scrollTop);
            });
            $(window).on('resize', function() {
              DawnThemes.Event.runResizeEvent = true;
              DawnThemes.Event.windowHeight = window.innerHeight;
              DawnThemes.Event.windowWidth = window.innerWidth;
            });
            setInterval(function() {
                if (DawnThemes.Event.runScrollEvent) {
                  DawnThemes.Event.runScrollEvent = false;
                }
                if (DawnThemes.Event.runResizeEvent) {
                  DawnThemes.Event.runResizeEvent = false;
                  DawnThemes.SmartSidebar.onResize();
                }
            }, 100);

        }
  };

  DawnThemes.menu_toggle = function(){
    //Off Canvas menu
    $('.menu-toggle').on('click',function(e){
      e.preventDefault();
      if($('body').hasClass('open-offcanvas')){
        $('body').removeClass('open-offcanvas').addClass('close-offcanvas');
        $('html').removeClass('dt-html-overflow-y');
      }else{
        $('body').removeClass('close-offcanvas').addClass('open-offcanvas');
        $('html').addClass('dt-html-overflow-y');
      }
    });
    
    // mobile-menu-toggle
    $('.offcanvas .mobile-menu-toggle').on('click',function(e){
      e.preventDefault();
      $('html').removeClass('dt-html-overflow-y');
      $('body').removeClass('open-offcanvas');
    });
    
    //Open Search Box
    $('.sidebar-offcanvas-header .search-toggle').click(function(){
      $('.sidebar-offcanvas-header .user-panel').hide();
      $('.sidebar-offcanvas-header .toggle-wrap').hide();
      $('.sidebar-offcanvas-header .search-box').fadeIn();
    });

    //Close Search Box
    $(document).click(function (e) {    
      if (!$(e.target).hasClass("search-toggle") 
            && $(e.target).parents(".sidebar-offcanvas-header").length === 0) 
        {
            $(".search-box").hide();
            $('.sidebar-offcanvas-header .user-panel').fadeIn();
        $('.sidebar-offcanvas-header .toggle-wrap').fadeIn();
        }
    });
  };
  
  DawnThemes.menu = function(){
    // Sticky menu
    var iScrollPos = 0;

    $win.scroll(function () {
      if( $('body').hasClass('sticky-menu') ){
        var iCurScrollPos = $(this).scrollTop();
        var $doc    = document.documentElement;
        var $top_offset = (window.pageYOffset || $doc.scrollTop) - ($doc.clientTop || 0);
          var $wpadminbar = 0;
        if( $("#wpadminbar").length > 0 && $win.width() > 600 && iCurScrollPos > $("#wpadminbar").height()){
          var $wpadminbar = $("#wpadminbar").height();
        }

        var $sticky_nav_height = $('#dt-sticky-navigation-holder').attr('data-height');

        if( $win.width() >= 992 ){
          if (iCurScrollPos > iScrollPos) {
                //Scrolling Down
                $('#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper #primary-navigation').appendTo($('#dt-main-menu .dt-mainnav-wrapper'));

                $('#dt-sticky-navigation-holder').css('top',- $sticky_nav_height);
            $('#dt-sticky-navigation-holder').removeClass('scrolled bgc');
            } else if( $top_offset > parseInt($('#dt-main-menu').offset().top + 250) ){
               //Scrolling Up
               $('#dt-main-menu .dt-mainnav-wrapper #primary-navigation').appendTo($('#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper'));

                $('#dt-sticky-navigation-holder').css({'top': $wpadminbar });
            $('#dt-sticky-navigation-holder').addClass('scrolled bgc');
            }else{
              $('#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper #primary-navigation').appendTo($('#dt-main-menu .dt-mainnav-wrapper'));
              
              $('#dt-sticky-navigation-holder').css('top',- $sticky_nav_height);
            $('#dt-sticky-navigation-holder').removeClass('scrolled bgc');
            }
        }else{
          if (iCurScrollPos > iScrollPos) {
                //Scrolling Down
                $('#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper #mobile_sticky_top_bar').appendTo($('#header .top-header'));

                $('#dt-sticky-navigation-holder').css('top',- $sticky_nav_height);
            $('#dt-sticky-navigation-holder').removeClass('scrolled bgc');
            } else if( $top_offset > parseInt($('#header').offset().top + 320) ){
               //Scrolling Up
               $('#header .top-header #mobile_sticky_top_bar').appendTo($('#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper'));

                $('#dt-sticky-navigation-holder').css({'top': $wpadminbar });
            $('#dt-sticky-navigation-holder').addClass('scrolled bgc');
            }else{
              $('#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper #mobile_sticky_top_bar').appendTo($('#header .top-header'));
              
              $('#dt-sticky-navigation-holder').css('top',- $sticky_nav_height);
            $('#dt-sticky-navigation-holder').removeClass('scrolled bgc');
            }
        }
          
          
          iScrollPos = iCurScrollPos;
          if(iCurScrollPos == 0){
          $('#dt-sticky-navigation-holder').removeClass('scrolled bgc');
          }
      }
    });
  };
  
  DawnThemes.scrollToTOp = function(){
    //Go to top
    $(window).scroll(function () {
      if ($(this).scrollTop() > 500) {
        $('.go-to-top').addClass('on');
      }
      else {
        $('.go-to-top').removeClass('on');
      }
    });
    $('body').on( 'click', '.go-to-top, #scroll-to-top', function () {
      $("html, body").animate({
        scrollTop: 0
      }, 800);
      return false;
    });
  };
  
  DawnThemes.slickSlider = function(){
    // Breaking news
    if( $('.dt-breaking-news-content').length ){
      $('.dt-breaking-news-content').removeClass('dt-preload');
      $('.dt-breaking-news-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        //speed: 500,
        arrows: false,
        infinite: true,
        dots: false,
        //vertical: true,
        fade: true,
        cssEase: 'linear'
      });
    }

    if( $('.dt-smart-content-box .dt-smcb-slider').length ){
      $('.dt-smart-content-box .dt-smcb-slider').removeClass('dt-preload');
      $('.dt-smart-content-box .dt-smcb-slider').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: false,
        dots: false,
        responsive: [
                 {
                   breakpoint: 1024,
                   settings: {
                     slidesToShow: 3,
                     slidesToScroll: 1,
                     infinite: true,
                     dots: false,
                   }
                 },
                 {
                   breakpoint: 600,
                   settings: {
                     slidesToShow: 2,
                     slidesToScroll: 1,
                     dots: false,
                     autoplay: true,
             autoplaySpeed: 2000,
                   }
                 },
                 {
                   breakpoint: 480,
                   settings: {
                     slidesToShow: 1,
                     slidesToScroll: 1,
                     dots: false,
                     autoplay: true,
             autoplaySpeed: 2000,
                   }
                 }
                 // You can unslick at a given breakpoint now by adding:
                 // settings: "unslick"
                 // instead of a settings object
               ]
      });
    }

    if( $('.dt-slick-slider').length ){
      $('.dt-slick-slider').each(function(){
        var $this = $(this);
        var $infinite, $slidesToShow, $slidesToScroll, $dots;

        $dots = $(this).attr('data-dots');
        $infinite = $(this).attr('data-infinite');
        $slidesToShow = parseInt($(this).attr('data-visible'));
        $slidesToScroll = parseInt($(this).attr('data-scroll'));

        $($this).removeClass('dt-preload');

        $dots = ($dots == '1' || $dots == 'true') ? true : false;
        $infinite = ($infinite == '1' || $infinite == 'true') ? true : false;

        $(this).find('.dt-slick-items').slick({
          dots: $dots,
          infinite: $infinite,
          slidesToShow: $slidesToShow,
          slidesToScroll: $slidesToScroll,
          nextArrow: '<div class="navslider"><span class="next"><i class="fa fa-chevron-right"></i></span></div>',
          prevArrow: '<div class="navslider"><span class="prev"><i class="fa fa-chevron-left"></i></span></div>',
        });
      });
    }

    if( $('.dt-posts-slider').length ){
      $('.dt-posts-slider').each(function(){
        var $this = $(this);
        var $mode, $infinite, $slidesToShow, $slidesToScroll, $dots, $arrows, $autoplay;

        $mode = $(this).attr('data-mode');
        $dots = $(this).attr('data-dots');
        $arrows = $(this).attr('data-arrows');
        $infinite = $(this).attr('data-infinite');
        $slidesToShow = parseInt($(this).attr('data-visible'));
        $slidesToScroll = parseInt($(this).attr('data-scroll'));
        $autoplay = $(this).attr('data-autoplay');

        $($this).removeClass('dt-preload');

        $dots = ($dots == '1' || $dots == 'true') ? true : false;
        $arrows = ($arrows == '1' || $arrows == 'true') ? true : false;
        $infinite = ($infinite == '1' || $infinite == 'true') ? true : false;
        $autoplay = ($autoplay == '1' || $autoplay == 'true') ? true : false;

        if($mode == 'single_mode'){
          $($this).find('.posts-slider').slick({
              dots: false,
              infinite: true,
              autoplay: $autoplay,
              speed: 300,
              fade: true,
              cssEase: 'linear',
              nextArrow: '<div class="navslider"><span class="next"><i class="fa fa-chevron-right"></i></span></div>',
            prevArrow: '<div class="navslider"><span class="prev"><i class="fa fa-chevron-left"></i></span></div>',
          });
        }else{
          $($this).find('.posts-slider').slick({
            infinite: $infinite,
            slidesToShow: $slidesToShow,
            slidesToScroll: $slidesToScroll,
            dots: $dots,
            arrows: $arrows,
            nextArrow: '<div class="navslider"><span class="next"><i class="fa fa-arrow-right"></i></span></div>',
            prevArrow: '<div class="navslider"><span class="prev"><i class="fa fa-arrow-left"></i></span></div>',
            responsive: [
                     {
                       breakpoint: 1024,
                       settings: {
                         slidesToShow: $slidesToShow,
                         slidesToScroll: $slidesToScroll,
                         infinite: $infinite,
                         dots: $dots
                       }
                     },
                     {
                       breakpoint: 600,
                       settings: {
                         slidesToShow: 2,
                         slidesToScroll: 2
                       }
                     },
                     {
                       breakpoint: 480,
                       settings: {
                         slidesToShow: 1,
                         slidesToScroll: 1
                       }
                     }
                     // You can unslick at a given breakpoint now by adding:
                     // settings: "unslick"
                     // instead of a settings object
                   ]
          });
        }
        
      });
    }

    if( $('.related_posts-slider').length ){
      $('.related_posts-slider').removeClass('dt-preload');
      $('.related_posts-slider').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 3,
        nextArrow: '<div class="navslider"><span class="next"><i class="fa fa-arrow-right"></i></span></div>',
        prevArrow: '<div class="navslider"><span class="prev"><i class="fa fa-arrow-left"></i></span></div>',
        responsive: [
                 {
                   breakpoint: 1024,
                   settings: {
                     slidesToShow: 3,
                     slidesToScroll: 3,
                     infinite: true,
                     dots: true
                   }
                 },
                 {
                   breakpoint: 600,
                   settings: {
                     slidesToShow: 2,
                     slidesToScroll: 2
                   }
                 },
                 {
                   breakpoint: 480,
                   settings: {
                     slidesToShow: 1,
                     slidesToScroll: 1
                   }
                 }
                 // You can unslick at a given breakpoint now by adding:
                 // settings: "unslick"
                 // instead of a settings object
               ]
      });
    }
  };
  
  DawnThemes.carouselInit = function(){
	  if ($().owlCarousel) {
          $('.testimonial-carousel-slide').each(function(){
       	  var _this = $(this);
       	  _this.owlCarousel({
       		  navigationText : [DawnThemesL10n.prev,DawnThemesL10n.next],
       		  navigation: _this.data('show_control') == 1 ? true:false,
       		  pagination: _this.data('show_pagination') == 1 ? true:false,
       		  items: _this.data('destop_columns'),
       		  itemsDesktop:[1024,_this.data('destop_columns')],
       		  itemsDesktopSmall:[992,1]
       	  });
          });
       }
  };
  
  DawnThemes.CountdownInit = function(){
	  if( $('.dt-countdown').length ){
		  $('.dt-countdown').each(function(){
			  var _this = $(this);
			  console.log(_this.data('end'));
			  var $countdown = _this.data('end');
			  var $html = _this.data('html');
			  $(_this).find('.countdown-content').countdown($countdown, function(event) {
					//$(this).html(event.strftime('%-D : %H : %M : %S'));
					$(this).html(event.strftime($html));
			  });
		  });
	  }
  };

  DawnThemes.magnificpopupInit = function(){
    if($().magnificPopup){
      $("a[data-rel='magnific-popup-video']").each(function(){
        $(this).magnificPopup({
          type: 'inline',
          mainClass: 'dt-mfp-popup',
          fixedContentPos: true,
          callbacks : {
              open : function(){
                $(this.content).find(".video-embed.video-embed-popup,.audio-embed.audio-embed-popup").dt_mediaelementplayer();
                $(this.content).find('iframe:visible').each(function(){
                if(typeof $(this).attr('src') != 'undefined'){
                  if( $(this).attr('src').toLowerCase().indexOf("youtube") >= 0 || $(this).attr('src').toLowerCase().indexOf("vimeo") >= 0  || $(this).attr('src').toLowerCase().indexOf("twitch.tv") >= 0 || $(this).attr('src').toLowerCase().indexOf("kickstarter") >= 0 || $(this).attr('src').toLowerCase().indexOf("dailymotion") >= 0) {
                    $(this).attr('data-aspectRatio', this.height / this.width).removeAttr('height').removeAttr('width');
                    if($(this).attr('src').indexOf('wmode=transparent') == -1) {
                      if($(this).attr('src').indexOf('?') == -1){
                        $(this).attr('src',$(this).attr('src') + '?wmode=transparent');
                      } else {
                        $(this).attr('src',$(this).attr('src') + '&wmode=transparent');
                      }
                    }
                  }
                } 
              });
                $(this.content).find('iframe[data-aspectRatio]').each(function() {
                var newWidth = $(this).parent().width();
                var $this = $(this);
                $this.width(newWidth).height(newWidth * $this.attr('data-aspectRatio'));
                
               });
              },
              close: function() {
                $(this.st.el).closest('.video-embed-shortcode').find('.video-embed-shortcode').html($(this.st.el).data('video-inline'));
              }
          }
        });
      });
      $("a[data-rel='magnific-popup']").magnificPopup({
        type: 'image',
        mainClass: 'dt-mfp-popup',
        fixedContentPos: true,
        gallery:{
          enabled: true
        }
      });
      $("a[data-rel='magnific-popup-verticalfit']").magnificPopup({
        type: 'image',
        mainClass: 'dt-mfp-popup',
        overflowY: 'scroll',
        fixedContentPos: true,
        image: {
          verticalFit: false
        },
        gallery:{
          enabled: true
        }
      });
      $("a[data-rel='magnific-single-popup']").magnificPopup({
        type: 'image',
        mainClass: 'dt-mfp-popup',
        fixedContentPos: true,
        gallery:{
          enabled: false
        }
      });
    }
  };
  DawnThemes.responsiveEmbedIframe = function(){
    
  };
  DawnThemes.isotopeInit = function(){
    var self = this;
    $('[data-layout="masonry"]').each(function(){
      var $this = $(this),
        container = $this.find('.masonry-wrap'),
        itemColumn = $this.data('masonry-column'),
        itemWidth,
        container_width = container.width();
        if(DawnThemes.getViewport().width > 992){
          itemWidth = container_width / itemColumn;
        }else if(DawnThemes.getViewport().width <= 992 && DawnThemes.getViewport().width >= 768){
          itemWidth = container_width / 2;
        }else {
          itemWidth = container_width / 1;
        }
        container.isotope({
          layoutMode: 'masonry',
          itemSelector: '.masonry-item',
          transitionDuration : '0.8s',
          getSortData : { 
            title : function (el) { 
              return $(el).data('title');
            }, 
            date : function (el) { 
              return parseInt($(el).data('date'));
            } 
          },
          masonry : {
            gutter : 0
          }
        }).isotope( 'layout' );
        
        imagesLoaded($this,function(){
          container.isotope( 'layout' );
        });
      if(!$this.hasClass('masonry-inited')){
        $this.addClass('masonry-inited');
        var filter = $this.find('.masonry-filter ul a');
        filter.on('click',function(e){
          e.stopPropagation();
          e.preventDefault();
          
          var $this = jQuery(this);
          // don't proceed if already selected
          if ($this.hasClass('selected')) {
            return false;
          }
          
          var filters = $this.closest('ul');
          filters.find('.selected').removeClass('selected');
          $this.addClass('selected');
          $this.closest('.masonry-filter').find('.filter-heaeding h3').text($this.text());
          var options = {
            layoutMode : 'masonry',
            transitionDuration : '0.8s',
            getSortData : { 
              title : function (el) { 
                return $(el).data('title');
              }, 
              date : function (el) { 
                return parseInt($(el).data('date'));
              } 
            }
          }, 
          key = filters.attr('data-filter-key'), 
          value = $this.attr('data-filter-value');
    
          value = value === 'false' ? false : value;
          options[key] = value;
          container.isotope(options);
          var wrap = $this.closest('[data-layout="masonry"]');
        });
        $('[data-masonry-toogle="selected"]').trigger('click');
      }
    });
    
  },
  DawnThemes.easyZoomInit = function(){
    if($().easyZoom) {
      $('.easyzoom').easyZoom();
    }
  },
  DawnThemes.mediaelementplayerInit = function(){
    if($().mediaelementplayer) {
      $(".video-embed:not(.video-embed-popup),.audio-embed:not(.audio-embed-popup)").dt_mediaelementplayer();
    }
  };

  DawnThemes.loadmoreInit = function(){
    var self = this;
    $('[data-paginate="loadmore"]').each(function(){
      var $this = $(this);
      $this.dtLoadmore({
        contentSelector : $this.data('contentselector') || null,
        navSelector  : $this.find('div.paginate'),            
            nextSelector : $this.find('div.paginate a.next'),
            itemSelector : $this.data('itemselector'),
            finishedMsg : $this.data('finishedmsg') || DawnThemesL10n.ajax_finishedMsg
      },function(newElements){
        //DT.woocommerceLazyLoading();
        $(newElements).find(".video-embed:not(.video-embed-popup),.audio-embed:not(.audio-embed-popup)").dt_mediaelementplayer();
        
        if($this.hasClass('masonry')){
          $this.find('.masonry-wrap').isotope('appended', $(newElements));
          if($this.find('.masonry-filter').length){
            var selector = $this.find('.masonry-filter').find('a.selected').data('filter-value');
            $this.find('.masonry-wrap').isotope({ filter: selector });
          }
          imagesLoaded(newElements,function(){
            DawnThemes.magnificpopupInit();
            DawnThemes.responsiveEmbedIframe();
            if($this.hasClass('masonry')){
              $this.find('.masonry-wrap').isotope('layout');
            }
          });
        }
        setTimeout(function() {
                    DawnThemes.SmartSidebar.onResize();
                }, 500);
      });
    });
  },
  DawnThemes.infiniteScrollInit = function(){
    var self = this;
    //Posts
    $('[data-paginate="infinite_scroll"]').each(function(){
      var $this = $(this);
      var finishedmsg = $this.data('finishedmsg') || DawnThemesL10n.ajax_finishedMsg,
        msgtext = $this.data('msgtext') || DawnThemesL10n.ajax_msgText,
        maxPage = $this.data('contentselector') ? $($this.data('contentselector')).data('maxpage') : undefined;
      $this.find('.infinite-scroll-wrap').infinitescroll({
        navSelector  : $this.find('div.paginate'),            
            nextSelector : $this.find('div.paginate a.next'),    
            itemSelector : $this.data('itemselector'),
            contentSelector : $this.data('contentselector') || $this.find('.infinite-scroll-wrap'),
            msgText: " ",
            maxPage:maxPage,
            loading: {
              speed:0,
              finishedMsg: finishedmsg,
          msgText: $this.data('msgtext') || DawnThemesL10n.ajax_msgText,
          selector: $this.data('loading-selector') || $this,
          msg: $('<div class="infinite-scroll-loading"><div class="fade-loading"><i></i><i></i><i></i><i></i></div><div class="infinite-scroll-loading-msg">' + msgtext +'</div></div>')
        },
        errorCallback: function(){
          $this.find('.infinite-scroll-loading-msg').html(finishedmsg).animate({ opacity: 1 }, 2000, function () {
                    $(this).parent().fadeOut('fast',function(){
                      $this.find('.infinite-scroll-loading-msg').html(msgtext);
                    });
                });
        }
      },function(newElements){
        
        $(newElements).find(".video-embed:not(.video-embed-popup),.audio-embed:not(.audio-embed-popup)").dt_mediaelementplayer();
        
        if($this.hasClass('masonry')){
          $this.find('.masonry-wrap').isotope('appended', $(newElements));
          if($this.find('.masonry-filter').length){
            var selector = $this.find('.masonry-filter').find('a.selected').data('filter-value');
            $this.find('.masonry-wrap').isotope({ filter: selector });
          }
          imagesLoaded(newElements,function(){
            DawnThemes.magnificpopupInit();
            DawnThemes.responsiveEmbedIframe();
            if($this.hasClass('masonry')){
              $this.find('.masonry-wrap').isotope('layout');
            }
          });
        }
        // setTimeout(function() {
    //                 DawnThemes.SmartSidebar.onResize();
    //             }, 500);
        
      });
    });
    
  };

  DawnThemes.ajax_nav_content = function(){
    var self = this;
    $('.dt-next-prev-wrap').each(function(){
      var $this = $(this);
      $($this).find('a').on('click', function(e){
        e.preventDefault();
        var $_this = $(this);
        var $wrap_id = $($_this).parents('.dt-next-prev-wrap').attr('data-target');
        if( ! $(this).hasClass('ajax-page-disabled') ){
          
          jQuery('#'+$wrap_id+' .dt-content__wrap').addClass('dt-loading');

          var cat       = $($_this).parents('.dt-next-prev-wrap').attr('data-cat'),
            orderby     = $($_this).parents('.dt-next-prev-wrap').attr('data-orderby'),
            order       = $($_this).parents('.dt-next-prev-wrap').attr('data-order'),
            hover_thumbnail = $($_this).parents('.dt-next-prev-wrap').attr('data-hover-thumbnail'),
            offset      = $($_this).attr('data-offset'),
            current_page  = $($_this).attr('data-current-page'),
            posts_per_page  = $($_this).parents('.dt-next-prev-wrap').attr('data-posts-per-page'),
            template      = $($_this).parents('.dt-next-prev-wrap').attr('data-template');
            
          $.ajax({
              url : ticketbox_dt_ajaxurl,
              data:{
                action      : 'ticketbox_nav_content',
                cat       : cat,
                orderby     : orderby,
                order       : order,
                hover_thumbnail : hover_thumbnail,
                offset      : offset,
                current_page  : current_page,
                posts_per_page  : posts_per_page,
                template    : template,
              },
              type: 'POST',
              success: function(data){
                if(data != ''){
                  setTimeout(function(){
                    $('#'+$wrap_id+' .dt-content__wrap').removeClass('dt-loading');
                    
                    $('#'+$wrap_id+' .dt-content__wrap .dt-content').html(data).hide();
                    $('#'+$wrap_id+' .dt-content__wrap .dt-content').fadeIn('slow');
                            
                            // uddate current page - offset
                            var current_page  = parseInt( $($_this).attr('data-current-page') );
                            var current_offset  = parseInt( $($_this).attr('data-offset') );

                            if( $($_this).hasClass('dt-ajax-next-page') ) {
                              $('#'+$wrap_id+' .dt-next-prev-wrap .dt-ajax-next-page').attr('data-current-page', current_page + 1);
                              var prev_page = parseInt( $($_this).attr('data-current-page') - 1 );
                              $('#'+$wrap_id+' .dt-next-prev-wrap .dt-ajax-prev-page').attr('data-current-page', prev_page);

                              $($_this).attr('data-offset', parseInt(offset) + parseInt(posts_per_page));

                              $('#'+$wrap_id+' .dt-ajax-prev-page').removeClass('ajax-page-disabled');
                              $('#'+$wrap_id+' .dt-ajax-prev-page').attr('data-offset', parseInt(offset) - parseInt(posts_per_page));

                            }else if( $($_this).hasClass('dt-ajax-prev-page') ){
                              $('#'+$wrap_id+' .dt-next-prev-wrap .dt-ajax-prev-page').attr('data-current-page', current_page - 1);
                              $('#'+$wrap_id+' .dt-next-prev-wrap .dt-ajax-next-page').attr('data-current-page', current_page);

                              if(current_offset <= 0){
                                $($_this).addClass('ajax-page-disabled');
                                $($_this).attr('data-offset', 0);
                                $('#'+$wrap_id+' .dt-ajax-next-page').attr('data-offset', parseInt(posts_per_page));
                                $('#'+$wrap_id+' .dt-next-prev-wrap .dt-ajax-next-page').attr('data-current-page', 1);

                              }else{
                                $($_this).attr('data-offset', parseInt(current_offset) - parseInt(posts_per_page));

                                $('#'+$wrap_id+' .dt-ajax-next-page').attr('data-offset', parseInt(current_offset) + parseInt(posts_per_page));
                              }
                              
                              $('#'+$wrap_id+' .dt-ajax-next-page').removeClass('ajax-page-disabled');
                              
                    }

                            // hidden action
                            if( $('#'+$wrap_id+' #dt-ajax-no-p').length > 0 ){
                              $_this.addClass('ajax-page-disabled');
                            }

                  },500);
                  
                }else{

                }
              }
          });
        }
      });
    });
  };
  
  DawnThemes.SmartSidebar = {
        itemList: [],
        lastKnownScrollY: 0,
        navbar: undefined,
        navbarHeight: 0,
        navbarFixedHeight: DawnThemes.getNavbarFixedHeight(),
        enable: true,
        ready: false,
        hasItem: false,
        adminbarHeight: 0,
        windowHeight: 0,
        addItem: function(item) {
            if (item.sidebar.length && item.content.length) {
                DawnThemes.SmartSidebar.hasItem = true;
                item.sidebar.data('state', 'default');
                item.sidebar.data('sidebar_height', 0);
                item.sidebar.data('content_height', 0);
                item.sidebar.data('navbar_offset', 0);
                DawnThemes.SmartSidebar.itemList.push({
                    sidebar: {
                        element: item.sidebar,
                        height: 0,
                        width: 0,
                        top: 0,
                        bottom: 0
                    },
                    content: {
                        element: item.content,
                        top: 0,
                        height: 0,
                        bottom: 0
                    },
                    state: ''
                });
            }
        },
        _isEqual: function(number1, number2) {
            if (Math.abs(number1 - number2) >= 1) {
                if (number1 < number2) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return true;
            }
        },
        _isSmaller: function(number1, number2) {
            if (Math.abs(number1 - number2) >= 1) {
                if (number1 < number2) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
        _calc: function() {
            DawnThemes.SmartSidebar.adminbarHeight = DawnThemes.getAdminbarHeight();
            DawnThemes.SmartSidebar.navbarHeight = DawnThemes.SmartSidebar.navbarFixedHeight + DawnThemes.SmartSidebar.adminbarHeight;
            if ($('.header7-smart').length && $('.header-container').hasClass('header-type-7'))
                DawnThemes.SmartSidebar.navbarHeight = DawnThemes.SmartSidebar.adminbarHeight;
        },
        init: function() {
            if (!DawnThemes.enableAnimation() || !DawnThemes.SmartSidebar.hasItem) {
                DawnThemes.SmartSidebar.enable = false;
                return;
            }
            if (!DawnThemes.SmartSidebar.ready) {
                DawnThemes.SmartSidebar._calc();
                DawnThemes.SmartSidebar.ready = true;
            }
        },
        onScroll: function(scrollTop) {
            if (window.requestAnimationFrame) {
                window.requestAnimationFrame(function() {
                    DawnThemes.SmartSidebar.update(scrollTop);
                });
            } else {
                DawnThemes.SmartSidebar.update(scrollTop);
            }
        },
        _destroy: function() {
            if (!DawnThemes.SmartSidebar.hasItem || !DawnThemes.SmartSidebar.enable || !DawnThemes.SmartSidebar.ready) {
                return;
            }
            for (var i = 0; i < DawnThemes.SmartSidebar.itemList.length; i++) {
                var currentItem = DawnThemes.SmartSidebar.itemList[i];
                currentItem.sidebar.element.data('state', 'default');
                currentItem.sidebar.element.data('sidebar_height', 0);
                currentItem.sidebar.element.data('content_height', 0);
                currentItem.sidebar.element.data('navbar_offset', 0);
                currentItem.state = '';
                DawnThemes.SmartSidebar.ready = false;
                DawnThemes.SmartSidebar.enable = false;
                currentItem.sidebar.element.attr('style', '');
            }
        },
        onResize: function() {
            if (!DawnThemes.enableAnimation()) {
                if (DawnThemes.SmartSidebar.ready) {
                    DawnThemes.SmartSidebar._destroy();
                    DawnThemes.SmartSidebar.enable = false;
                }
                return;
            } else {
                DawnThemes.SmartSidebar.enable = true;
                DawnThemes.SmartSidebar.init();
                DawnThemes.SmartSidebar._calc();
                if (window.requestAnimationFrame) {
                    window.requestAnimationFrame(function() {
                        DawnThemes.SmartSidebar.update($(window).scrollTop());
                    });
                } else {
                    DawnThemes.SmartSidebar.update($(window).scrollTop());
                }
            }
        },
        _adjustSidebar: function(currentItem) {
            var state = currentItem.state;
            if ((('pinnedBottom' != state || 'fixedUp' != state) && state === currentItem.sidebar.element.data('state')) || ('pinnedBottom' === state && 'pinnedBottom' === currentItem.sidebar.element.data('state') && currentItem.sidebar.element.data('sidebar_height') === currentItem.sidebar.height && currentItem.sidebar.element.data('content_height') === currentItem.content.height) || ('fixedUp' === state && 'fixedUp' === currentItem.sidebar.element.data('state') && currentItem.sidebar.element.data('navbar_offset') === DawnThemes.SmartSidebar.navbarHeight))
                return;
            switch (state) {
                case 'fixedDown':
                    currentItem.sidebar.element.css({
                        width: currentItem.sidebar.width,
                        position: "fixed",
                        top: "auto",
                        bottom: "0",
                        "z-index": "1"
                    });
                    break;
                case 'default':
                    currentItem.sidebar.element.css({
                        width: "auto",
                        position: "static",
                        top: "auto",
                        bottom: "auto"
                    });
                    break;
                case 'pinnedBottom':
                    currentItem.sidebar.element.data('sidebar_height', currentItem.sidebar.height);
                    currentItem.sidebar.element.data('content_height', currentItem.content.height);
                    currentItem.sidebar.element.css({
                        width: currentItem.sidebar.width,
                        position: "absolute",
                        top: currentItem.content.bottom - currentItem.sidebar.height - currentItem.content.top,
                        bottom: "auto"
                    });
                    break;
                case 'fixedUp':
                    currentItem.sidebar.element.data('navbar_offset', DawnThemes.SmartSidebar.navbarHeight);
                    currentItem.sidebar.element.css({
                        width: currentItem.sidebar.width,
                        position: "fixed",
                        top: DawnThemes.SmartSidebar.navbarHeight,
                        bottom: "auto"
                    });
                    break;
                case 'pinnedTop':
                    currentItem.sidebar.element.css({
                        width: currentItem.sidebar.width,
                        position: "absolute",
                        top: currentItem.sidebar.top - currentItem.content.top,
                        bottom: "auto"
                    });
                    break;
            }
            currentItem.sidebar.element.data('state', state);
        },
        update: function(scrollTop) {
            if (!DawnThemes.SmartSidebar.hasItem || !DawnThemes.SmartSidebar.enable || !DawnThemes.SmartSidebar.ready) {
                return;
            }
            DawnThemes.SmartSidebar.windowHeight = DawnThemes.getViewport().height;
            var currentScrollY = scrollTop,
                windowBottom = scrollTop + DawnThemes.SmartSidebar.windowHeight,
                scrollDirection = '';
            if (currentScrollY !== DawnThemes.SmartSidebar.lastKnownScrollY) {
                if (currentScrollY > DawnThemes.SmartSidebar.lastKnownScrollY) {
                    scrollDirection = 'down';
                } else {
                    scrollDirection = 'up';
                }
            }
            DawnThemes.SmartSidebar.lastKnownScrollY = currentScrollY;
            currentScrollY = currentScrollY + DawnThemes.SmartSidebar.navbarHeight;
            for (var i = 0; i < DawnThemes.SmartSidebar.itemList.length; i++) {
                var currentItem = DawnThemes.SmartSidebar.itemList[i];
                currentItem.content.height = currentItem.content.element.outerHeight();
                currentItem.content.top = currentItem.content.element.offset().top;
                currentItem.content.bottom = currentItem.content.top + currentItem.content.height;
                currentItem.sidebar.top = currentItem.sidebar.element.offset().top;
                currentItem.sidebar.height = currentItem.sidebar.element.outerHeight();
                currentItem.sidebar.width = currentItem.sidebar.element.width();
                currentItem.sidebar.bottom = currentItem.sidebar.top + currentItem.sidebar.height;
                if (currentItem.content.height <= currentItem.sidebar.height) {
                    currentItem.state = 'default';
                    DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'default');
                } else if (currentItem.sidebar.height < DawnThemes.SmartSidebar.windowHeight) {
                    if (DawnThemes.SmartSidebar._isEqual(currentScrollY, currentItem.content.top)) {
                        currentItem.state = 'default';
                        DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'default');
                    } else if (true === DawnThemes.SmartSidebar._isSmaller(currentItem.sidebar.bottom, currentScrollY)) {
                        if (DawnThemes.SmartSidebar._isSmaller(currentScrollY, (currentItem.content.bottom - currentItem.sidebar.height))) {
                            currentItem.state = 'fixedUp';
                            DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedUp');
                        } else {
                            currentItem.state = 'pinnedBottom';
                            DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'pinnedBottom');
                        }
                    } else {
                        if (DawnThemes.SmartSidebar._isEqual(currentItem.content.bottom, currentItem.sidebar.bottom)) {
                            if ('up' === scrollDirection && DawnThemes.SmartSidebar._isEqual(currentScrollY, currentItem.sidebar.top)) {
                                currentItem.state = 'fixedUp';
                                DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedUp');
                            } else {
                                currentItem.state = 'pinnedBottom';
                                DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'pinnedBottom');
                            }
                        } else {
                            if (currentItem.content.bottom - currentScrollY >= currentItem.sidebar.height) {
                                currentItem.state = 'fixedUp';
                                DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedUp');
                            } else {
                                currentItem.state = 'pinnedBottom';
                                DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'pinnedBottom');
                            }
                        }
                    }
                } else {
                    if (true === DawnThemes.SmartSidebar._isSmaller(currentItem.sidebar.bottom, currentScrollY)) {
                        if (true === DawnThemes.SmartSidebar._isEqual(currentScrollY, currentItem.sidebar.top) && true === DawnThemes.SmartSidebar._isEqual(currentItem.content.top, currentScrollY)) {
                            currentItem.state = 'fixedUp';
                            DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedUp');
                        } else if (true === DawnThemes.SmartSidebar._isSmaller(currentItem.sidebar.bottom, windowBottom) && true === DawnThemes.SmartSidebar._isSmaller(currentItem.sidebar.bottom, currentItem.content.bottom) && currentItem.content.bottom >= windowBottom) {
                            currentItem.state = 'fixedDown';
                            DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedDown');
                        } else {
                            currentItem.state = 'pinnedBottom';
                            DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'pinnedBottom');
                        }
                    } else if (true === DawnThemes.SmartSidebar._isSmaller(currentItem.sidebar.bottom, windowBottom) && true === DawnThemes.SmartSidebar._isSmaller(currentItem.sidebar.bottom, currentItem.content.bottom) && 'down' === scrollDirection && currentItem.content.bottom >= windowBottom) {
                        currentItem.state = 'fixedDown';
                        DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedDown');
                    } else if (true === DawnThemes.SmartSidebar._isEqual(currentItem.sidebar.top, currentItem.content.top) && 'up' === scrollDirection && currentItem.content.bottom >= windowBottom) {
                        currentItem.state = 'default';
                        DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'default');
                    } else if ((true === DawnThemes.SmartSidebar._isEqual(currentItem.content.bottom, currentItem.sidebar.bottom) && 'down' === scrollDirection) || currentItem.content.bottom < windowBottom) {
                        currentItem.state = 'pinnedBottom';
                        DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'pinnedBottom');
                    } else if (true === DawnThemes.SmartSidebar._isEqual(currentScrollY, currentItem.sidebar.top) && 'up' === scrollDirection && true === DawnThemes.SmartSidebar._isEqual(currentItem.content.top, currentScrollY)) {
                        currentItem.state = 'fixedUp';
                        DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'fixedUp');
                    }
                    if (('fixedDown' === currentItem.sidebar.element.data('state') && 'up' === scrollDirection) || ('fixedUp' === currentItem.sidebar.element.data('state') && 'down' === scrollDirection)) {
                        currentItem.state = 'pinnedTop';
                        DawnThemes.SmartSidebar._adjustSidebar(currentItem, 'pinnedTop');
                    }
                }
            }
        }
    };
  DawnThemes.getAdminbarHeight = function() {
        var adminbarHeight = 0;
        if ($('#wpadminbar').length) {
            adminbarHeight = parseInt($('#wpadminbar').outerHeight());
        }
        return adminbarHeight;
    };
    
    DawnThemes.helperInit = function() {
    	//PopUp
	    DawnThemes.magnificpopupInit();
	      //Load more
	    DawnThemes.loadmoreInit();
	    //Infinite Scrolling
	    DawnThemes.infiniteScrollInit();
	    //Media element player
	    DawnThemes.mediaelementplayerInit();
	    //isotope
	    DawnThemes.isotopeInit();
	    DawnThemes.slickSlider();
	    DawnThemes.carouselInit();
	    DawnThemes.CountdownInit();
    };
    
  DawnThemes.getViewport = function() {
        var e = window,
            a = 'inner';
        if (!('innerWidth' in window)) {
            a = 'client';
            e = document.documentElement || document.body;
        }
        return {
            width: e[a + 'Width'],
            height: e[a + 'Height']
        };
    };
    DawnThemes.enableAnimation = function() {
        if ('yes' === DawnThemesL10n.is_mobile_theme)
            return false;
        return DawnThemes.getViewport().width > DawnThemesL10n.breakpoint && !DawnThemes.userAgent.isTouch;
    };
    DawnThemes.historySupport = function() {
        return !!window.history && !!history.pushState;
    };
  
  DawnThemes.Event.init();
  $.DawnThemes= DawnThemes;

  $(document).ajaxComplete(function(){
      //DawnThemes.SmartSidebar.onResize();
    });
})(window.jQuery);
(function($){
  'use strict';
  var body = $( 'body' ),
    $win = $( window );
  
  $(document).ready(function(){
    // Do something here
    var $windowHeight = $win.height();
    var $htmlHeight = $('html').outerHeight();
    
    if( $htmlHeight <  $windowHeight ){
      var $wpadminbarHeight = 0;
      if( $('#wpadminbar').length ){
        $wpadminbarHeight = $('#wpadminbar').height();
      }
      $( '#main.site-main' ).css('min-height', ($windowHeight - $wpadminbarHeight )- ($('#header').height() +  $('#footer').height()) );
    }
  });
  
})(window.jQuery);
