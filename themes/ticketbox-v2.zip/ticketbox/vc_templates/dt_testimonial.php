<?php
$output = '';
extract(shortcode_atts(array(
	'title'					=>'',
	'columns'				=>1,
	'style'					=>'style_1',
	'show_pagination'		=>'',
	'show_control'			=>'',
	'el_class'				=>'',
), $atts));
$indicators = '';
$el_class  = !empty($el_class) ? ' '.esc_attr( $el_class ) : '';
$id = uniqid('trainer_carousel_');
wp_enqueue_script('owl.carousel');
wp_enqueue_style('owl.carousel');
?>
<div class="testimonial-carousel testimonial-carousel-<?php echo esc_attr($style)?><?php echo esc_attr($el_class)?>">
	<?php if(!empty($title)):?>
		<h3 class="testimonial-carousel-title"><span><?php echo esc_html($title)?></span></h3>
	<?php endif;?>
	<div id="<?php echo esc_attr($id) ?>" class="owl-carousel testimonial-carousel-slide" data-show_pagination="<?php echo ('yes'===$show_pagination) ? '1':'0' ?>" data-show_control="<?php echo ('yes'===$show_control) ? '1':'0' ?>" data-destop_columns = "<?php echo esc_attr($columns) ?>">
		<?php echo wpb_js_remove_wpautop( $content );?>
	</div>
</div>