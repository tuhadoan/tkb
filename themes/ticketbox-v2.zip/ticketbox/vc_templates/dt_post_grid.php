<?php
$output = '';
extract(shortcode_atts(array(
	'title'				=>'',
	'layout_style'      =>'grid',
	'rows'				=>'1',
	'columns'			=>'1',
	'posts_per_page'	=>'',
	'orderby'			=>'latest',
	'categories'		=>'',
	'visibility'		=>'',
	'el_class'			=>'',
), $atts));

if( $layout_style == 'grid' )
	$posts_per_page = $rows * $columns;
if( $layout_style == '1big_4gird' )
	$posts_per_page = 5;

$class          = !empty($el_class) ?  ' '.esc_attr( $el_class ) : '';
switch ($visibility) {
	case 'hidden-phone':
		$class .= ' hidden-xs';
		break;
	case 'hidden-tablet':
		$class .= ' hidden-sm hidden-md';
		break;
	case 'hidden-pc':
		$class .= ' hidden-lg';
		break;
	case 'visible-phone':
		$class .= ' visible-xs-inline';
		break;
	case 'visible-tablet':
		$class .= ' visible-sm-inline visible-md-inline';
		break;
	case 'visible-pc':
		$class .= ' visible-lg-inline';
		break;
}

$order = 'DESC';
switch ($orderby) {
	case 'latest':
		$orderby = 'date';
		break;

	case 'oldest':
		$orderby = 'date';
		$order = 'ASC';
		break;

	case 'alphabet':
		$orderby = 'title';
		$order = 'ASC';
		break;

	case 'ralphabet':
		$orderby = 'title';
		break;

	default:
		$orderby = 'date';
		break;
}

$args = array(
	'orderby'         => "{$orderby}",
	'order'           => "{$order}",
	'post_type'       => "post",
	'posts_per_page'  => $posts_per_page
);

if(!empty($categories)){
	$args['category_name'] = $categories;
}
$r = new WP_Query($args);

if($r->have_posts()):
	ob_start();
	?>
	<div class="post-grid-sc">
		<?php if(!empty($title)):?>
		<h3 class="dt-sc-title"><span><?php echo esc_html($title);?></span></h3>
		<?php endif;?>
		<?php
		switch ($layout_style){
			case '1big_4gird':
			?>
			<div class="post-grid style_<?php echo esc_attr($layout_style); ?>">
				<?php
				$i = 0;
				while ($r->have_posts()): $r->the_post(); $i++;
				if( $i == 1 ){
					$size = 'ticketbox-thumbnail-640x360';
				}else{
					$size = 'ticketbox-thumbnail-415x234';
				}
				?>
					<article  <?php post_class(); ?>>
						<?php
						if( has_post_thumbnail() ):?>
						<div class="entry-featured <?php echo get_post_format() == 'video' ? 'video-featured' : '' ?>">
							<a class="post-thumbnail-link dt-image-link" href="<?php the_permalink(); ?>" aria-hidden="true">
								<?php the_post_thumbnail( $size, array( 'alt' => the_title_attribute( 'echo=0' ) ) ); ?>
								<?php echo get_post_format() == 'video' ? '<div class="dt-icon-video"></div>' : '' ?>
							</a>
						</div>
						<?php 
						endif;?>
						<div class="hentry-wrap">
							<header class="post-header">
								<?php	
								the_title( '<h2 class="post-title" data-itemprop="name"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
								?>
							</header><!-- .entry-header -->
						</div><!-- .entry-meta -->
						<meta content="<?php echo get_the_author()?>" itemprop="author" />
					</article>
				<?php endwhile;?>
			</div>
			<?php
				break;
			default: // layout grid
				$post_col = '';
				$post_col = 'col-sm-'.(12/$columns).' ';
				?>
				<div class="post-grid">
					<div class="row <?php echo ($layout_style == 'list') ?  'list' : 'grid col-'.$columns.''; ?>">
						<?php while ($r->have_posts()): $r->the_post();?>
							<article  <?php post_class($post_col); ?>>
								<?php
								if( has_post_thumbnail() ):?>
								<div class="entry-featured <?php echo get_post_format() == 'video' ? 'video-featured' : '' ?>">
									<a class="post-thumbnail-link dt-image-link" href="<?php the_permalink(); ?>" aria-hidden="true">
										<?php the_post_thumbnail( 'post-thumbnail', array( 'alt' => the_title_attribute( 'echo=0' ) ) ); ?>
										<?php echo get_post_format() == 'video' ? '<div class="dt-icon-video"></div>' : '' ?>
									</a>
								</div>
								<?php 
								endif;?>
								<div class="hentry-wrap">
									<header class="post-header">
										<?php	
										the_title( '<h2 class="post-title" data-itemprop="name"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
										?>
									</header><!-- .entry-header -->
								</div><!-- .entry-meta -->
								<meta content="<?php echo get_the_author()?>" itemprop="author" />
							</article>
						<?php endwhile;?>
					</div>
				</div>
				<?php
			break;
		}
		?>
	</div>
	<?php
	$html = ob_get_clean();
	echo $html;
endif;
wp_reset_postdata();