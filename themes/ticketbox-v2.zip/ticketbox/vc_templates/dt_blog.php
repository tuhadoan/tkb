<?php
/**
 * @package dawn
 */
$output = array();
extract(shortcode_atts(array(
	'title'				=>'',
	'layout'			=>'grid',
	'columns'			=> 3,
	'posts_per_page'	=>'10',
	'orderby'			=>'latest',
	'categories'		=>'',
	'exclude_categories'=>'',
	'pagination'		=>'loadmore',
	'loadmore_text'		=>esc_html__('Load More','ticketbox'),
	'visibility'		=>'',
	'el_class'			=>'',
), $atts));
if($layout == 'masonry'){
	wp_enqueue_script('isotope');
}
if($pagination === 'infinite_scroll'){
	wp_enqueue_script('infinitescroll');
}
$sc_id = ticketbox_dt_sc_get_id();
$class = !empty($el_class) ?  ' '.esc_attr( $el_class ) : '';
$class .= ticketbox_dt_visibility_class($visibility);

if( is_front_page() || is_home()) {
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1 );
} else {
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
}

$order = 'DESC';
switch ($orderby) {
	case 'latest':
		$orderby = 'date';
		break;

	case 'oldest':
		$orderby = 'date';
		$order = 'ASC';
		break;

	case 'alphabet':
		$orderby = 'title';
		$orderby = 'ASC';
		break;

	case 'ralphabet':
		$orderby = 'title';
		break;

	default:
		$orderby = 'date';
		break;
}

$args = array(
	'orderby'         => "{$orderby}",
	'order'           => "{$order}",
	'post_type'       => "post",
	'posts_per_page'  => "-1",
	'paged'			  => $paged
);
if(!empty($posts_per_page))
	$args['posts_per_page'] = $posts_per_page;

if(!empty($categories)){
	$args['category_name'] = $categories;
}
if(!empty($exclude_categories)){
	$args['tax_query'][] =  array(
			'taxonomy' => 'category',
			'terms'    => explode(',',$exclude_categories),
			'field'    => 'slug',
			'operator' => 'NOT IN'
	);
}
$r = new WP_Query($args);

$itemSelector = '';
$itemSelector .= (($pagination === 'infinite_scroll') ? '.post.infinite-scroll-item':'');
$itemSelector .= (($pagination === 'loadmore') ? '.post.loadmore-item':'');


if($r->have_posts()):
?>
<div id="<?php echo esc_attr($sc_id);?>" class="dt-blog-sc wpb_content_element <?php echo esc_attr( $class );?>">
	<div class="dt-blog-sc__wrap">
		<?php if( $title != '' ):?>
		<div class="dt-blog-sc__heading">
			<div class="dt-blog-sc__title">
				<h5 class="dt-title"><?php echo esc_html($title);?></h5>
			</div>
		</div>
		<?php endif;?>
		<div class="dt-content__wrap">
			<div data-itemselector="<?php echo esc_attr($itemSelector)  ?>"  class="posts <?php echo (($pagination === 'loadmore') ? ' loadmore':''); ?><?php echo (($pagination === 'infinite_scroll') ? ' infinite-scroll':'') ?><?php echo (($layout === 'masonry') ? ' masonry':'') ?>" data-paginate="<?php echo esc_attr($pagination) ?>" data-layout="<?php echo esc_attr($layout) ?>"<?php echo ($layout === 'masonry') ? ' data-masonry-column="'.$columns.'"':''?>>
				<div class="posts-wrap<?php echo (($pagination === 'loadmore') ? ' loadmore-wrap':'') ?><?php echo (($pagination === 'infinite_scroll') ? ' infinite-scroll-wrap':'') ?><?php echo (($layout === 'masonry') ? ' masonry-wrap':'') ?> posts-layout-<?php echo esc_attr($layout)?><?php if( $layout == 'default' || $layout == 'grid' || $layout == 'masonry') echo' row' ?>">
				<?php
				// Start the Loop.
				$grid_class = 'col-md-'.absint(12/$columns).' col-sm-'.absint(12/$columns).' col-xs-6';
				while ($r->have_posts() ) : $r->the_post();?>
					<?php
					$post_class = '';
					$post_class .= (($pagination === 'infinite_scroll') ? ' infinite-scroll-item':'');
					$post_class .= (($pagination === 'loadmore') ? ' loadmore-item':'');
					if($layout == 'masonry')
						$post_class.=' masonry-item';
					?>
					<?php
						ticketbox_dt_get_template('content.php', array(
							'post_class' 	=> $post_class,
							'columns' 		=> $grid_class,
							'size'			=> '',
						),
						'template-parts/loop', 'template-parts/loop'
						);
					?>
				<?php
				endwhile;
				?>
				</div>
				<?php
				// Previous/next post navigation.
				// this paging nav should be outside .posts-wrap
				$paginate_args = array();
				switch ($pagination){
					case 'loadmore':
						ticketbox_dt_paging_nav_ajax($loadmore_text, $r);
						$paginate_args = array('show_all'=>true);
						break;
					case 'infinite_scroll':
						$paginate_args = array('show_all'=>true);
						break;
				}
				if($pagination != 'no') ticketbox_dt_paginate_links($paginate_args, $r);
				?>
			</div>
		</div>
	</div>
</div>
<?php
endif;
wp_reset_postdata();
?>