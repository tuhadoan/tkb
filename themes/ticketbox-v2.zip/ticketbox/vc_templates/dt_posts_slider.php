<?php
$output = array();
extract(shortcode_atts(array(
	'style'				=>'',
	'title'				=>'',
	'posts_to_show'		=>'4',
	'posts_per_page'	=>'8',
	'orderby'			=>'latest',
	'categories'		=>'',
	'exclude_categories'=>'',
	'visibility'		=>'',
	'el_class'			=>'',
), $atts));

$class          = !empty($el_class) ?  ' '.esc_attr( $el_class ) : '';
$class .= ticketbox_dt_visibility_class($visibility);

$order = 'DESC';
switch ($orderby) {
	case 'latest':
		$orderby = 'date';
		break;

	case 'oldest':
		$orderby = 'date';
		$order = 'ASC';
		break;

	case 'alphabet':
		$orderby = 'title';
		$orderby = 'ASC';
		break;

	case 'ralphabet':
		$orderby = 'title';
		break;

	default:
		$orderby = 'date';
		break;
}

$args = array(
	'orderby'         => "{$orderby}",
	'order'           => "{$order}",
	'post_type'       => "post",
	'posts_per_page'  => $posts_per_page,
);

if(!empty($categories)){
	$args['category_name'] = $categories;
}
if(!empty($exclude_categories)){
	$args['tax_query'][] =  array(
			'taxonomy' => 'category',
			'terms'    => explode(',',$exclude_categories),
			'field'    => 'slug',
			'operator' => 'NOT IN'
	);
}
$r = new WP_Query($args);

if($r->have_posts()):
wp_enqueue_style('slick');
wp_enqueue_script('slick');
$data_arrows = 'true';
$dots = 'false';
$style = 'def';
?>
<div class="dt-posts-slider wpb_content_element dt-preload <?php echo esc_attr( $class . $style );?>" data-mode="<?php echo esc_attr($style);?>" data-visible="<?php echo esc_attr($posts_to_show)?>" data-scroll="<?php echo esc_attr($posts_to_show)?>" data-infinite="true" data-autoplay="false" data-arrows="<?php echo esc_attr($data_arrows);?>" data-dots="<?php echo esc_attr($dots);?>">
	<div class="dt-posts-slider__wrap">
		<?php if($title !=''):?>
		<div class="dt-post-slider__heading">
			<div class="dt-post-slider__title">
				<h5 class="dt-slider-title"><?php echo esc_html($title);?></h5>
			</div>
		</div>
		<?php endif; ?>
		<div class="posts-slider <?php echo esc_attr($style);?>">
			<?php
			switch ($style){
				case 'style_2':
					break;
				default:
					while ($r->have_posts()): $r->the_post();
					?>
						<div class="post-item-slide">
							<article class="post">
								<?php 
								if( has_post_thumbnail() ):?>
								<div class="entry-featured <?php echo get_post_format() == 'video' ? 'video-featured' : '' ?>">
									<a class="post-thumbnail-link dt-image-link" href="<?php the_permalink(); ?>" aria-hidden="true">
										<?php the_post_thumbnail( 'post-thumbnail', array( 'alt' => the_title_attribute( 'echo=0' ) ) ); ?>
										<?php echo get_post_format() == 'video' ? '<div class="dt-icon-video"></div>' : '' ?>
									</a>
								</div>
								<?php 
								endif;?>
								<div class="hentry-wrap">
									<header class="post-header">
										<?php	
										the_title( '<h2 class="post-title" data-itemprop="name"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
										?>
									</header><!-- .entry-header -->
								</div><!-- .entry-meta -->
								<meta content="<?php echo get_the_author()?>" itemprop="author" />
							</article>
						</div>
					<?php endwhile;
					break;
			}
			?>
		</div>
	</div>
</div>
<?php
endif;
wp_reset_postdata();
?>