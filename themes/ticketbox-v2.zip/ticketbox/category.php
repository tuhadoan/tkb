<?php
/**
 * The template for displaying Category pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dawn
 */
$cat = get_query_var('cat');
$term = get_category($cat);
$cat_id = $term->cat_ID;
$dt_category_representative_color = get_option("dt_category_representative_color$cat_id") ? get_option("dt_category_representative_color$cat_id") : '';

$layout = dawnthemes_get_theme_option('archive-layout', 'right-sidebar');
$style = dawnthemes_get_theme_option('blog-style', 'default');
$pagination = dawnthemes_get_theme_option('blog-pagination', 'loadmore'); // wp_pagenavi || def || loadmore || infinite_scroll
$loadmore_text = dawnthemes_get_theme_option('blog-loadmore-text', esc_html__('Load More','ticketbox'));
$columns = dawnthemes_get_theme_option('blog-columns', 2);

if($style == 'masonry'){
	wp_enqueue_script('isotope');
}
if($pagination === 'infinite_scroll'){
	wp_enqueue_script('infinitescroll');
}
ticketbox_display_sidebar($layout);
get_header(); ?>
<div id="main-content">
		<div class="row">
			<section id="primary" class="content-area <?php echo esc_attr(dawnthemes_get_main_class($layout))?>">
				<div id="content" class="main-content site-content" role="main">
					<div class="row">
						<div class="col-md-12">
							<?php 
							$itemSelector = '';
							$itemSelector .= (($pagination === 'infinite_scroll') ? '.post.infinite-scroll-item':'');
							$itemSelector .= (($pagination === 'loadmore') ? '.post.loadmore-item':'');
							?>
							<?php
							if( have_posts() ):
								?>
								<header class="page-header">
									<?php
										the_archive_title( '<h1 class="page-title">', '</h1>' );
										the_archive_description( '<div class="taxonomy-description">', '</div>' );
									?>
								</header><!-- .page-header -->
								<div data-itemselector="<?php echo esc_attr($itemSelector)  ?>"  class="posts <?php echo (($pagination === 'loadmore') ? ' loadmore':''); ?><?php echo (($pagination === 'infinite_scroll') ? ' infinite-scroll':'') ?><?php echo (($style === 'masonry') ? ' masonry':'') ?>" data-paginate="<?php echo esc_attr($pagination) ?>" data-layout="<?php echo esc_attr($style) ?>"<?php echo ($style === 'masonry') ? ' data-masonry-column="'.$columns.'"':''?>>
									<div class="posts-wrap<?php echo (($pagination === 'loadmore') ? ' loadmore-wrap':'') ?><?php echo (($pagination === 'infinite_scroll') ? ' infinite-scroll-wrap':'') ?><?php echo (($style === 'masonry') ? ' masonry-wrap':'') ?> posts-layout-<?php echo esc_attr($style)?><?php if( $style == 'default' || $style == 'grid' || $style == 'masonry') echo' row' ?>">
									<?php
									// Start the Loop.
									$i = 0;
									$grid_class = 'col-md-'.absint(12/$columns).' col-sm-'.absint(12/$columns).' col-xs-6';
									while ( have_posts() ) : the_post();?>
										<?php
										$post_class = '';
										$post_class .= (($pagination === 'infinite_scroll') ? ' infinite-scroll-item':'');
										$post_class .= (($pagination === 'loadmore') ? ' loadmore-item':'');
										if($style == 'masonry')
											$post_class.=' masonry-item';
										?>
										<?php
										ticketbox_dt_get_template('content.php', array(
											'post_class' => $post_class,
											'columns' => $grid_class,
											'size'		=> '',
										),
										'template-parts/loop', 'template-parts/loop'
										);
										$i++;
										?>
									<?php
									endwhile;
									
									?>
									</div>
									<?php
									// Previous/next post navigation.
									// this paging nav should be outside .posts-wrap
									$paginate_args = array();
									switch ($pagination){
										case 'def':
											ticketbox_dt_paging_nav_default();
											break;
										case 'loadmore':
											ticketbox_dt_paging_nav_ajax($loadmore_text);
											$paginate_args = array('show_all'=>true);
											break;
										case 'infinite_scroll':
											$paginate_args = array('show_all'=>true);
											break;
									}
									ticketbox_dt_paginate_links($paginate_args);
									?>
								</div>
							<?php
							else :
								// If no content, include the "No posts found" template.
								get_template_part( 'content', 'none' );
							endif;
							?>
						</div>
					</div><!-- /.row -->
				</div><!-- #content -->
			</section><!-- #primary -->
		<?php do_action('ticketbox_dt_left_sidebar');?>
		<?php do_action('ticketbox_dt_right_sidebar'); ?>

	</div><!-- .row -->
</div><!-- #main-content -->

<?php
get_footer();

