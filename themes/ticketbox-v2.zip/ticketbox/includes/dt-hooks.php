<?php
/**
 * MaTube Template Hooks
 *
 * Action/filter hooks used for theme functions/templates.
 *
 * @author 	DawnThemes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Breadcrumbs
 *
 * @see ticketbox_dt_breadcrumbs()
 */
add_action('ticketbox_breadcrumbs', 'ticketbox_dt_breadcrumbs', 10);

/**
 * Ajax load navigation
 *
 * @see ticketbox_nav_content()
 */
add_action('wp_ajax_ticketbox_nav_content', 'ticketbox_nav_content' );
add_action('wp_ajax_nopriv_ticketbox_nav_content', 'ticketbox_nav_content' );

/**
 * Go to Top
 *
 * @see ticketbox_dt_gototop()
 */
//add_action('wp_footer', 'ticketbox_dt_gototop');

/**
 * Add custom CSS theme
 *
 * @see ticketbox_dt_custom_css()
 */
add_action( 'ticketbox_main_inline_style', 'ticketbox_dt_custom_css', 10000,1 );
