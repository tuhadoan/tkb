<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ticketbox_Facebook_Widget extends DawnThemes_Widget{
	public function __construct(){
		$this->widget_cssclass		= 'dt-facebook__widget';
		$this->widget_description	= esc_html__( 'Display Facebook fanpage like box.', 'ticketbox' );
		$this->widget_id			= 'ticketbox_Facebook_Widget';
		$this->widget_name        	= esc_html__( 'DT Facebook', 'ticketbox' );

		$this->settings				= array(
			'title'		=> array(
				'type'	=> 'text',
				'std'	=> esc_html__( 'Facebook Fanpage', 'ticketbox' ),
				'label' => esc_html__( 'Title', 'ticketbox' )
			),
			'fanpage'		=> array(
				'type'	=> 'text',
				'std'	=> esc_html__( 'DawnThemes', 'ticketbox' ),
				'label' => esc_html__( 'Fanpage Name', 'ticketbox' )
			),
			'width'		=> array(
				'type'	=> 'text',
				'std'	=> '370',
				'label' => esc_html__( 'Width (pixel)', 'ticketbox' )
			),
		);

		parent::__construct();
	}

	public function widget($args, $instance){
		ob_start();
		extract( $args );
		$title      	= apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
		$fanpage		= !empty($instance['fanpage']) ? esc_html($instance['fanpage']) : 'DawnThemes' ;
		$width			= !empty($instance['width']) ? absint($instance['width']) : 370 ;

		if(!empty($fanpage)){
			echo $before_widget;
			if ( $title )
				echo $before_title . $title . $after_title;
				
			?>
			<div class="dt-facebook__widget_wrap">
				<div class="dt-facebook__content">
					<div id="fb-root"></div>
					<script>
						(function(d, s, id) {
							var js, fjs = d.getElementsByTagName(s)[0];
							if (d.getElementById(id)) return;
							js = d.createElement(s); js.id = id;
							js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5";
							fjs.parentNode.insertBefore(js, fjs);
						}(document, 'script', 'facebook-jssdk'));
					</script>
					<div class="fb-page" 
					data-href="https://www.facebook.com/<?php echo esc_html($fanpage); ?>"
					data-width="<?php echo absint($width);?>"
					data-height="215"
					data-tabs="timeline" 
					data-small-header="false" 
					data-adapt-container-width="true" 
					data-hide-cover="false" 
					data-show-facepile="true" 
					data-show-posts="false">
						<div class="fb-xfbml-parse-ignore">
							<blockquote cite="https://www.facebook.com/<?php echo esc_html($fanpage); ?>">
								<a href="https://www.facebook.com/<?php echo esc_html($fanpage); ?>"><?php echo esc_html($fanpage); ?></a>
							</blockquote>
						</div>
					</div>
				</div>
			</div>
			<?php
			echo $after_widget;
			$content = ob_get_clean();
			echo $content;
		}
	}
}

add_action('widgets_init', create_function('', 'return register_widget("ticketbox_Facebook_Widget");'));