<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ticketbox_DT_Posts extends DawnThemes_Widget{
	public function __construct(){
		$this->widget_cssclass    = 'dt-posts__wg';
		$this->widget_description = esc_html__( "A list of Your site’s Posts.", 'ticketbox' );
		$this->widget_id          = 'ticketbox_DT_Posts_Widget';
		$this->widget_name        = esc_html__( 'DT Posts', 'ticketbox' );

		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'	=>'',
				'label' => esc_html__( 'Title', 'ticketbox' )
			),
			'orderby' => array(
				'type'  => 'select',
				'std'   => 'date',
				'label' => esc_html__( 'Order by', 'ticketbox' ),
				'options' => array(
					'date'   => esc_html__( 'Recent posts', 'ticketbox' ),
					'featured'   => esc_html__( 'Featured posts', 'ticketbox' ),
					'rand'  => esc_html__( 'Random', 'ticketbox' ),
				)
			),
			'number'  => array(
				'type'  => 'number',
				'std'	=> '4',
				'label' => esc_html__( 'Number of posts to show:', 'ticketbox' )
			),
			'show_date'  => array(
				'type'  => 'checkbox',
				'std'	=>'',
				'label' => esc_html__( 'Display post date?', 'ticketbox' )
			),
		);
		parent::__construct();
	}

	public function widget($args, $instance){
		ob_start();
		extract( $args );
		$title       = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
		$orderby     	= sanitize_title( $instance['orderby'] );
		$number = isset($instance['number']) ? absint($instance['number']) : 4 ;
		$show_date = isset($instance['show_date']) ? $instance['show_date'] : '';

		echo $before_widget;

		if($title) {
			echo wp_kses( $before_title . esc_html($title) . $after_title, array(
				'h3' => array(
					'class' => array()
				),
				'h4' => array(
					'class' => array()
				),
				'span' => array(
					'class' => array()
				),
			) );
		}

		switch ($orderby) {
			case 'date':
				$orderby = 'date';
				break;

			case 'featured':
				$orderby = 'meta_value';
				break;

			case 'rand':
				$orderby = 'rand';
				break;

			default:
				$orderby = 'date';
				break;
		}

		$args = array(
			'post_type'      => 'post',
			'posts_per_page' => $number ,
			'order'          => 'DESC',
			'orderby'        => "{$orderby}",
			'ignore_sticky_posts' => true,
			'post_status'    => 'publish'
				);

		if( $orderby == 'meta_value' ){
			$args['meta_key'] = '_dt_post_meta_featured_post';
			$args['meta_value'] = 'yes';
		}

		$posts = new WP_Query($args);

		if($posts->have_posts()):
		?>
	        <ul class="dt-recent-posts-wg">
			<?php while($posts->have_posts()): $posts->the_post(); ?>
		        <li class="post-item">
					<?php if(has_post_thumbnail()): ?>
					<div class="post-img dt-effect1">
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
					    <?php the_post_thumbnail('ticketbox-posts-wg-thumbnail-size'); ?>
						</a>
					</div>
					<?php endif; ?>
			        <div class="post-content">
			        	<h3 class="post-title">
			        		<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title() ?></a>
			        	</h3>
			        	<div class="post-meta">
			        		<span class="post-author"><?php echo sprintf( __( 'By %s', 'ticketbox' ), get_the_author_posts_link() );?></span>
			        		<?php if( $show_date ) :?>
				        	<span class="separator">/</span>
				        	<span class="post-date"><?php echo get_the_date();?></span>
				        	<?php endif; ?>
			        	</div>
			        </div>
		        </li>
	        <?php endwhile; ?>
	        </ul>
		<?php
			wp_reset_postdata();
			endif;
		echo $after_widget;
		echo ob_get_clean();
	}
}

add_action('widgets_init', create_function('', 'return register_widget("ticketbox_DT_Posts");'));