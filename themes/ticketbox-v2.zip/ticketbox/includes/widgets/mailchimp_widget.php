<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ticketbox_DT_Mailchimp_Widget extends DawnThemes_Widget {
	public function __construct(){
		$this->widget_cssclass    = 'widget-mailchimp';
		$this->widget_description = esc_html__( "Widget Mailchimp Subscribe.", 'ticketbox' );
		$this->widget_id          = 'dt_widget_mailchimp';
		$this->widget_name        = esc_html__( 'DT Mailchimp Subscribe', 'ticketbox' );
		$this->cached = false;
		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'	=>'',
				'label' => esc_html__( 'Title', 'ticketbox' )
			),
			'info'  => array(
				'type'  => 'text',
				'std'	=>'',
				'label' => esc_html__( 'Info before Subscribe form', 'ticketbox' )
			),
		);
		parent::__construct();
	}
	
	public function widget($args, $instance){
		ob_start();
		extract( $args );
		$title      = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
		$info 		= isset($instance['info']) ? $instance['info'] : '';
		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;
		?>
		<div class="widget-mailchimp-wrapper">
			<?php if(!empty($info)): ?>
			<div class="widget-mailchimp-info font-2">
			<?php echo esc_html($info);?>
			</div>
			<?php endif;?>
			<?php ticketbox_dt_mailchimp_form(); ?>
		</div>
		<?php
		echo $after_widget;
		$content = ob_get_clean();
		echo $content;
	}
}

add_action('widgets_init', create_function('', 'return register_widget("ticketbox_DT_Mailchimp_Widget");'));