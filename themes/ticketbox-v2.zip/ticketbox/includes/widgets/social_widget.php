<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ticketbox_DT_Social_Widget extends DawnThemes_Widget {
	public function __construct(){
		$this->widget_cssclass    = 'social-widget';
		$this->widget_description = esc_html__( "Display Social Icon.", 'ticketbox' );
		$this->widget_id          = 'ticketbox_DT_Social_Widget';
		$this->widget_name        = esc_html__( 'DT Social', 'ticketbox' );
		
		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'	=>'',
				'label' => esc_html__( 'Title', 'ticketbox' )
			),
			'social' => array(
					'type'  => 'select',
					'std'   => '',
					'multiple'=>true,
					'label'=>esc_html__('Social','ticketbox'),
					'desc' => esc_html__( 'Select socials', 'ticketbox' ),
					'options' => array(
						'facebook'=>'Facebook',
						'twitter'=>'Twitter',
						'google-plus'=>'Google Plus',
						'pinterest'=>'Pinterest',
						'linkedin'=>'Linkedin',
						'rss'=>'Rss',
						'instagram'=>'Instagram',
						'github'=>'Github',
						'behance'=>'Behance',
						'stack-exchange'=>'Stack Exchange',
						'tumblr'=>'Tumblr',
						'soundcloud'=>'SoundCloud',
						'dribbble'=>'Dribbble'
					),
			),
			'style' => array(
				'type'  => 'select',
				'std'   => '',
				'label' => esc_html__( 'Style', 'ticketbox' ),
				'options' => array(
					'square' =>  esc_html__('Square', 'ticketbox' ),
					'round' =>  esc_html__('Round', 'ticketbox' ),
					'outlined' =>  esc_html__('Outlined', 'ticketbox' ),
				)
			),
		);
		parent::__construct();
	}
	
	public function widget($args, $instance){
		ob_start();
		extract( $args );
		$title       = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
		$social = isset($instance['social']) ? explode(',',$instance['social']) : array();
		$style = isset($instance['style']) ? $instance['style'] : 'square';
		if(!empty($social)){
			echo $before_widget;
			if ( $title )
				echo $before_title . $title . $after_title;
			echo '<div class="social-widget-wrap social-widget-'.$style.'">';
			$hover = false;
			$soild_bg = true;
			$outlined = false;
			if($style == 'outlined'){
				$hover = true;
				$soild_bg = false;
				$outlined = true;
			}
			ticketbox_dt_social($social,$hover,$soild_bg,$outlined);
			echo '</div>';
			echo $after_widget;
			$content = ob_get_clean();
			echo $content;
		}
	}
	
}

add_action('widgets_init', create_function('', 'return register_widget("ticketbox_DT_Social_Widget");'));