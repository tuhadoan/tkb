<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ticketbox_DT_About_US extends DawnThemes_Widget{
	public function __construct(){
		$this->widget_cssclass		= 'about-us__widget';
		$this->widget_description	= esc_html__( 'Display About US widget which contains information and social accounts.', 'ticketbox' );
		$this->widget_id			= 'DT_AboutUS_Widget';
		$this->widget_name        	= esc_html__( 'DT About US', 'ticketbox' );

		$this->settings				= array(
			'title'		=> array(
				'type'	=> 'text',
				'std'	=> esc_html__( 'About us', 'ticketbox' ),
				'label' => esc_html__( 'Title', 'ticketbox' )
			),
			'content'		=> array(
				'type'	=> 'textarea',
				'std'	=> '',
				'label' => esc_html__( 'Content', 'ticketbox' )
			),
			'social' => array(
				'type'  => 'select',
				'std'   => '',
				'multiple'=>true,
				'label'=>esc_html__('Social','ticketbox'),
				'desc' => esc_html__( 'Select socials', 'ticketbox' ),
				'options' => array(
					'facebook'=>'Facebook',
					'twitter'=>'Twitter',
					'google-plus'=>'Google Plus',
					'pinterest'=>'Pinterest',
					'linkedin'=>'Linkedin',
					'rss'=>'Rss',
					'instagram'=>'Instagram',
					'github'=>'Github',
					'behance'=>'Behance',
					'stack-exchange'=>'Stack Exchange',
					'tumblr'=>'Tumblr',
					'soundcloud'=>'SoundCloud',
					'dribbble'=>'Dribbble'
				),
			),
		);

		parent::__construct();
	}

	public function widget($args, $instance){
		ob_start();
		extract( $args );
		$title       = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
		$info = isset($instance['content']) ? wp_kses_post( stripslashes( $instance['content'] ) ) : '';
		$social = isset($instance['social']) ? explode(',',$instance['social']) : array();

		if(!empty($social)){
			echo $before_widget;
			if ( $title )
				echo $before_title . $title . $after_title;
			echo '<div class="about-us-widget">';
			echo '<div class="about-us-info">'.$info.'</div>';
			echo '<div class="wg-social">';
			$hover = false;
			$soild_bg = true;
			$outlined = false;
			ticketbox_dt_social($social,$hover,$soild_bg,$outlined);
			echo '</div>';
			echo '</div>';
			echo $after_widget;
			$content = ob_get_clean();
			echo $content;
		}
	}
}

add_action('widgets_init', create_function('', 'return register_widget("ticketbox_DT_About_US");'));