<?php
/*
 * Custom Fonts
 */
// Body font
$main_font = dawnthemes_get_theme_option('main_font');
if(isset($main_font['font-family'])){
$main_font_family = (1 === preg_match('~[0-9]~', $main_font['font-family'])) ? '"'. $main_font['font-family'] .'"' : $main_font['font-family'];
$main_font_size = (1 === preg_match('~[0-9]~', $main_font['font-size'])) ? $main_font['font-size'] : $main_font['font-size'];
if(!empty($main_font_family)):
?>
body{
	font-family:<?php echo ticketbox_dt_print_string($main_font_family) ?>;
}
<?php
endif;
if(!empty($main_font_size)):?>
body{
	font-size:<?php echo ticketbox_dt_print_string($main_font_size) ?>;
}
<?php
endif;
}
?>
<?php
if(!empty($main_font['font-style'])){
	$font_style = $main_font['font-style'];
	if(strpos($font_style,'italic') === false){
		?>
		body{
			font-weight:<?php echo ticketbox_dt_print_string($font_style); ?>;
		}
		<?php
	}elseif (strpos($font_style,'0italic') == true){
		$font_weight = explode("i",$font_style);
		?>
		body{
			font-weight:<?php echo @$font_weight[0] ?>;
			font-style: italic;
		}
		<?php
	}elseif (strpos($font_style,'italic') !== false){
		?>
		body{
			font-weight:400;
			font-style: italic;
		}
		<?php
	}
}
?>
<?php 
// Secondary font
$secondary_font = dawnthemes_get_theme_option('secondary_font');
if(isset($secondary_font['font-family'])){
	$secondary_font_family = (1 === preg_match('~[0-9]~', $main_font['font-family'])) ? '"'. $main_font['font-family'] .'"' : $main_font['font-family'];
	if(!empty($secondary_font_family)){
	?>
	h1,
	h2,
	h3,
	h4,
	h5,
	h6,
	.h1,
	.h2,
	.h3,
	.h4,
	.h5,
	.h6,
	.font-2, blockquote
	{
		font-family:<?php echo ticketbox_dt_print_string($secondary_font_family) ?>;
	}
	<?php
	}
}

// Navigation font
$navbar_typography = dawnthemes_get_theme_option('navbar_typography');
if(isset($navbar_typography['font-family'])){
	$navbar_typography_family = (1 === preg_match('~[0-9]~', $navbar_typography['font-family'])) ? '"'. $navbar_typography['font-family'] .'"' : $navbar_typography['font-family'];
	if(!empty($navbar_typography_family)){
		?>
	#primary-navigation li
	{
		font-family:<?php echo ticketbox_dt_print_string($navbar_typography_family) ?>;
	}
	<?php
	}
}
?>


<?php
// Custom css here (Main color...)
$main_color = dawnthemes_get_theme_option('main_color','#ff3333');
if( $main_color != '#ff3333' ):
?>
.ticketbox_main_color, a:hover,
.primary-navigation ul.main-menu > li.menu-item-has-children:hover > a, .primary-navigation ul.nav-menu > li.menu-item-has-children:hover > a,
.primary-navigation ul.main-menu > li:hover > a, .primary-navigation ul.nav-menu > li:hover > a,
.primary-navigation ul.main-menu > li.current-menu-item > a, .primary-navigation ul.nav-menu > li.current-menu-item > a,
.primary-navigation ul.main-menu > li ul li:hover > a, .primary-navigation ul.nav-menu > li ul li:hover > a,
.primary-navigation ul.main-menu > li ul li.menu-item-has-children:hover > a:after, .primary-navigation ul.nav-menu > li ul li.menu-item-has-children:hover > a:after,
.primary-navigation .megamenu > ul.main-menu > li.menu-item-has-children .sub-content.sub-preview .sub-grid-content .grid-item .grid-item-post:hover .title a,
#dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper #main-menu > li:hover > a, #dt-sticky-navigation-holder .dt-sticky-mainnav-wrapper ul.main-menu > li:hover > a,
.site-header .top-header .top-header-socials ul li a:hover,
.site-header .top-header .top-header-box #search-box button:hover i,
.dt-post-category .dt-post-category__wrap .dt-post-category__grid .dt-content.tem-list_big .post-item .entry-title:hover, .dt-post-category .dt-post-category__wrap .dt-post-category__grid .dt-content.tem-list_small .post-item .entry-title:hover,
.dt-posts-slider:not(.single_mode) article.post:hover .entry-title, .dt-post-category article.post:hover .entry-title,
.dt-post-category .dt-post-category__wrap .dt-post-category__grid .dt-content.tem-grid .post-item .entry-title:hover,
.posts-layout-default .post:hover .post-header .post-title a, .posts-layout-list .post:hover .post-header .post-title a, .posts-layout-grid .post:hover .post-header .post-title a, .posts-layout-classic .post:hover .post-header .post-title a, .posts-layout-masonry .post:hover .post-header .post-title a,
.posts-layout-default .post .cat-links a, .posts-layout-list .post .cat-links a, .posts-layout-grid .post .cat-links a, .posts-layout-classic .post .cat-links a, .posts-layout-masonry .post .cat-links a,
.dt-posts-slider .dt-posts-slider__wrap .posts-slider.single_mode .post-item-slide .post-content .entry-meta .byline a,
.entry-title a:hover, .sticky .post-title:before,
.cat-links a:hover, .entry-meta a:hover,
.tweets-widget a,
.widget .block-contact-widget p a,
.widget .tagcloud a:hover, .widget .tagcloud a:focus,
.dt-posts__wg ul li .post-content .post-title a:hover,
.main-content .dt-posts__wg ul li:hover .post-content .post-title a,
.post-meta a:hover, .posted-on a:hover, .byline a:hover, .comments-link a:hover,
.tags-list .tag-links a:hover,
.share-links ul li a:hover,
.posts-layout-default .post .post-meta .byline a:hover, .posts-layout-list .post .post-meta .byline a:hover, .posts-layout-grid .post .post-meta .byline a:hover, .posts-layout-classic .post .post-meta .byline a:hover, .posts-layout-masonry .post .post-meta .byline a:hover,
.single .author-info .author-description .author-primary .author-socials a:hover,
#comments .comment-list li .author-content .box-right .comment-reply-link,
#footer .footer-bottom a:hover
{
	color:<?php echo $main_color;?>;
}

.dt-posts-slider .dt-posts-slider__wrap .posts-slider.single_mode .post-item-slide .post-content .dt-post-category,
.dt-posts-slider .dt-posts-slider__wrap .posts-slider.single_mode .navslider .prev:hover, .dt-posts-slider .dt-posts-slider__wrap .posts-slider.single_mode .navslider .next:hover,
.readmore-link .more-link:hover,
.dt-next-prev-wrap a:hover,
.widget .dt-newsletter-wg input[type="submit"]:hover,
.btn-default:hover, button:hover, input[type=button]:hover, input[type=submit]:hover
{
	background-color:<?php echo $main_color;?>;
}

.readmore-link .more-link
{
	background-color: rgba( <?php echo ticketbox_dt_hex2rgb($main_color);?> , 0.8);
}

.dt-next-prev-wrap a:hover,
.share-links ul li a:hover,
.widget .tagcloud a:hover, .widget .tagcloud a:focus,
.widget .dt-newsletter-wg input[type="submit"]:hover,
.btn-default:hover, button:hover, input[type=button]:hover, input[type=submit]:hover
{
	border-color:<?php echo $main_color;?>!important;
}

<?php 
endif;
?>