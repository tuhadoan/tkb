<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly
}

class WPBakeryShortCode_DT_Mailchimp extends DTWPBakeryShortcode {
}
vc_map( 
	array( 
		'base' => 'dt_mailchimp', 
		"category" => esc_html__( "dawnthemes", 'ticketbox' ), 
		'name' => esc_html__( 'Mailchimp Subscribe', 'ticketbox' ), 
		'description' => esc_html__( 'Widget Mailchimp Subscribe.', 'ticketbox' ), 
		'class' => 'dt-vc-element dt-vc-element-dt_mailchimp', 
		'icon' => 'dt-vc-icon-dt_mailchimp', 
		'show_settings_on_create' => true, 
		'params' => array( 
			array( 
				'type' => 'textfield', 
				'heading' => esc_html__( 'Title', 'ticketbox' ), 
				'param_name' => 'title', 
				'description' => esc_html__( 
					'Enter text which will be used as widget title. Leave blank if no title is needed.', 
					'ticketbox' ) ),
			array( 
				'param_name' => 'el_class', 
				'heading' => __( '(Optional) Extra class name', 'ticketbox' ), 
				'type' => 'textfield', 
				'value' => '', 
				"description" => __( 
					"If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 
					'ticketbox' ) ) ) ) );