<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly
}

class WPBakeryShortCode_DT_Posts_Slider extends DTWPBakeryShortcode {
}
vc_map( 
	array( 
		'base' => 'dt_posts_slider', 
		'name' => esc_html__( 'Posts Slider', 'ticketbox' ), 
		'description' => esc_html__( 'Show mutiple posts in a slider.', 'ticketbox' ), 
		"category" => esc_html__( "dawnthemes", 'ticketbox' ), 
		'class' => 'dt-vc-element dt-vc-element-dt_post', 
		'icon' => 'dt-vc-icon-dt_post', 
		'show_settings_on_create' => true, 
		'params' => array( 
			/*array( 
				'type' => 'dropdown', 
				'heading' => esc_html__( 'Style', 'ticketbox' ), 
				'param_name' => 'style',
				'std' => 'def', 
				'value' => array( 
					esc_html__( 'Default', 'ticketbox' ) => 'def', 
					esc_html__( 'Style 2', 'ticketbox' ) => 'style_2' ), 
				'admin_label' => true ),*/
			array( 
				'param_name' => 'title', 
				'heading' => esc_html__( 'Title', 'ticketbox' ), 
				'description' => '', 
				'type' => 'textfield', 
				'value' => '', 
				'admin_label' => true ), 
			array( 
				'type' => 'post_category', 
				'heading' => esc_html__( 'Categories', 'ticketbox' ), 
				'param_name' => 'categories', 
				'admin_label' => true, 
				'description' => esc_html__( 'Select a category or leave blank for all', 'ticketbox' ) ), 
			array( 
				'type' => 'post_category', 
				'heading' => esc_html__( 'Exclude Categories', 'ticketbox' ), 
				'param_name' => 'exclude_categories', 
				'description' => esc_html__( 'Select a category to exclude', 'ticketbox' ) ), 
			array( 
				'type' => 'dropdown', 
				'heading' => esc_html__( 'Order by', 'ticketbox' ), 
				'param_name' => 'orderby', 
				'std' => 'latest', 
				'value' => array( 
					esc_html__( 'Recent First', 'ticketbox' ) => 'latest', 
					esc_html__( 'Older First', 'ticketbox' ) => 'oldest', 
					esc_html__( 'Title Alphabet', 'ticketbox' ) => 'alphabet', 
					esc_html__( 'Title Reversed Alphabet', 'ticketbox' ) => 'ralphabet' ) ), 
			array( 
				'type' => 'textfield', 
				'heading' => esc_html__( 'Posts to show', 'ticketbox' ), 
				'param_name' => 'posts_to_show', 
				'value' => 4, 
				'dependency' => array( 'element' => "mode", 'value' => array( 'def' ) ), 
				'description' => esc_html__( 'Select number of posts to show.', 'ticketbox' ) ), 
			array( 
				'type' => 'textfield', 
				'heading' => esc_html__( 'Posts Per page', 'ticketbox' ), 
				'param_name' => 'posts_per_page', 
				'value' => 8, 
				'description' => '' ), 
			array( 
				'param_name' => 'el_class', 
				'heading' => __( '(Optional) Extra class name', 'ticketbox' ), 
				'type' => 'textfield', 
				'value' => '', 
				"description" => __( 
					"If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 
					'ticketbox' ) ) ) ) );
