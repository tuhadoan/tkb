<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly
}

class WPBakeryShortCode_DT_Post_Grid extends DTWPBakeryShortcode {
}

vc_map( 
	array( 
		'base' => 'dt_post_grid', 
		'name' => __( 'Post Grid', 'ticketbox' ), 
		'description' => __( 'Display posts with multiple styles.', 'ticketbox' ), 
		"category" => __( "dawnthemes", 'ticketbox' ), 
		'class' => 'dt-vc-element dt-vc-element-dt_post', 
		'icon' => 'dt-vc-icon-dt_post', 
		'show_settings_on_create' => true, 
		'params' => array( 
			array( 
				'param_name' => 'title', 
				'heading' => esc_html__( 'Title', 'ticketbox' ), 
				'description' => '', 
				'type' => 'textfield', 
				'value' => '', 
				'admin_label' => true ), 
			array( 
				'type' => 'dropdown', 
				'heading' => __( 'Layout Style', 'ticketbox' ), 
				'param_name' => 'layout_style', 
				'std' => 'grid', 
				'admin_label' => true, 
				'value' => array( 
					__( 'Grid - Default', 'ticketbox' ) => 'grid', 
					__( '1 Big item - 4 grid items', 'ticketbox' ) => '1big_4gird' )

				, 
				'description' => __( 'Select style to display the latest posts.', 'ticketbox' ) ), 
			array( 
				'type' => 'dropdown', 
				'heading' => __( 'Rows', 'ticketbox' ), 
				'param_name' => 'rows', 
				'std' => 1, 
				'value' => array( __( '1', 'ticketbox' ) => '1', __( '2', 'ticketbox' ) => '2' ), 
				'dependency' => array( 'element' => "layout_style", 'value' => array( 'grid' ) ), 
				'description' => __( 'Select whether to display the layout in 1, 2 rows.', 'ticketbox' ) ), 
			array( 
				'type' => 'dropdown', 
				'heading' => __( 'Columns', 'ticketbox' ), 
				'param_name' => 'columns', 
				'std' => 1, 
				'value' => array( 
					__( '1', 'ticketbox' ) => '1', 
					__( '2', 'ticketbox' ) => '2', 
					__( '3', 'ticketbox' ) => '3', 
					__( '4', 'ticketbox' ) => '4' ), 
				'dependency' => array( 'element' => "layout_style", 'value' => array( 'grid' ) ), 
				'description' => __( 'Select whether to display the layout in 1, 2, 3 or 4 columns.', 'ticketbox' ) ), 
			
			array( 
				'type' => 'dropdown', 
				'heading' => __( 'Order by', 'ticketbox' ), 
				'param_name' => 'orderby', 
				'value' => array( 
					__( 'Recent First', 'ticketbox' ) => 'latest', 
					__( 'Older First', 'ticketbox' ) => 'oldest', 
					__( 'Title Alphabet', 'ticketbox' ) => 'alphabet', 
					__( 'Title Reversed Alphabet', 'ticketbox' ) => 'ralphabet' ) ), 
			array( 
				'type' => 'post_category', 
				'heading' => __( 'Categories', 'ticketbox' ), 
				'param_name' => 'categories', 
				'admin_label' => true, 
				'description' => __( 'Select a category or leave blank for all', 'ticketbox' ) ), 
			array( 
				'param_name' => 'el_class', 
				'heading' => __( '(Optional) Extra class name', 'ticketbox' ), 
				'type' => 'textfield', 
				'value' => '', 
				"description" => __( 
					"If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 
					'ticketbox' ) ) ) ) );