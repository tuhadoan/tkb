<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly
}

class WPBakeryShortCode_DT_Blog extends DTWPBakeryShortcode {
}
vc_map( 
	array( 
		'base' => 'dt_blog', 
		'name' => esc_html__( 'Blog Layout', 'ticketbox' ), 
		'description' => esc_html__( 'Display multiple blog layouts.', 'ticketbox' ), 
		"category" => esc_html__( "dawnthemes", 'ticketbox' ), 
		'class' => 'dt-vc-element dt-vc-element-dt_post', 
		'icon' => 'dt-vc-icon-dt_post', 
		'show_settings_on_create' => true, 
		'params' => array( 
			array( 
				'param_name' => 'title', 
				'heading' => esc_html__( 'Title', 'ticketbox' ), 
				'description' => '', 
				'type' => 'textfield', 
				'value' => '', 
				'admin_label' => true ),
				/*array(
				 'type' => 'dropdown',
				 'heading' => esc_html__( 'Layout', 'ticketbox' ),
				 'param_name' => 'layout',
				 'std' => 'grid',
				 'admin_label' => true,
				 'value' => array(
				 esc_html__( 'Default', 'ticketbox' ) => 'grid'
				 ),
				 'std' => 'grid',
				 'description' => esc_html__( 'Select the layout for the blog shortcode.', 'ticketbox' ) ), */
				 array( 
				'type' => 'dropdown', 
				'heading' => esc_html__( 'Columns', 'ticketbox' ), 
				'param_name' => 'columns', 
				'std' => 3, 
				'value' => array( 
					esc_html__( '2', 'ticketbox' ) => '2', 
					esc_html__( '3', 'ticketbox' ) => '3', 
					esc_html__( '4', 'ticketbox' ) => '4' ), 
				
				// 'dependency' => array( 'element' => "layout", 'value' => array( 'grid', 'masonry' ) ),
				'description' => esc_html__( 'Select whether to display the layout in 2, 3 or 4 column.', 'ticketbox' ) ), 
			array( 
				'type' => 'textfield', 
				'heading' => esc_html__( 'Posts Per Page', 'ticketbox' ), 
				'param_name' => 'posts_per_page', 
				'value' => 10, 
				'description' => esc_html__( 'Select number of posts per page.Set "-1" to display all', 'ticketbox' ) ), 
			array( 
				'type' => 'dropdown', 
				'heading' => esc_html__( 'Order by', 'ticketbox' ), 
				'param_name' => 'orderby', 
				'std' => 'latest', 
				'value' => array( 
					esc_html__( 'Recent First', 'ticketbox' ) => 'latest', 
					esc_html__( 'Older First', 'ticketbox' ) => 'oldest', 
					esc_html__( 'Title Alphabet', 'ticketbox' ) => 'alphabet', 
					esc_html__( 'Title Reversed Alphabet', 'ticketbox' ) => 'ralphabet' ) ), 
			array( 
				'type' => 'post_category', 
				'heading' => esc_html__( 'Categories', 'ticketbox' ), 
				'param_name' => 'categories', 
				'admin_label' => true, 
				'description' => esc_html__( 'Select a category or leave blank for all', 'ticketbox' ) ), 
			array( 
				'type' => 'post_category', 
				'heading' => esc_html__( 'Exclude Categories', 'ticketbox' ), 
				'param_name' => 'exclude_categories', 
				'description' => esc_html__( 'Select a category to exclude', 'ticketbox' ) ), 
			array( 
				'type' => 'dropdown', 
				'std' => 'loadmore', 
				'heading' => esc_html__( 'Pagination', 'ticketbox' ), 
				'param_name' => 'pagination', 
				'value' => array( 
					esc_html__( 'Ajax Load More', 'ticketbox' ) => 'loadmore', 
					esc_html__( 'WP PageNavi', 'ticketbox' ) => 'wp_pagenavi', 
					esc_html__( 'Infinite Scrolling', 'ticketbox' ) => 'infinite_scroll', 
					esc_html__( 'No', 'ticketbox' ) => 'no' ), 
				
				// 'dependency' => array( 'element' => 'layout', 'value' => array( 'default', 'list', 'grid', 'masonry'
				// ) ),
				'description' => esc_html__( 'Choose pagination type.', 'ticketbox' ) ), 
			array( 
				'type' => 'textfield', 
				'heading' => esc_html__( 'Load More Button Text', 'ticketbox' ), 
				'param_name' => 'loadmore_text', 
				'dependency' => array( 'element' => "pagination", 'value' => array( 'loadmore' ) ), 
				'value' => esc_html__( 'Load More', 'ticketbox' ) ), 
			array(
				'param_name' => 'el_class', 
				'heading' => __( '(Optional) Extra class name', 'ticketbox' ), 
				'type' => 'textfield', 
				'value' => '', 
				"description" => __( 
					"If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 
					'ticketbox' ) ) ) ) );
