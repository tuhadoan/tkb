<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly
}

class WPBakeryShortCode_DT_Countdown extends DTWPBakeryShortcode {
}
vc_map( 
	array( 
		'base' => 'dt_countdown', 
		'name' => esc_html__( 'Coundown', 'ticketbox' ), 
		'description' => esc_html__( 'Display Countdown.', 'ticketbox' ), 
		'class' => 'dt-vc-element dt-vc-element-dt_countdown', 
		'icon' => 'dt-vc-icon-dt_countdown', 
		'show_settings_on_create' => true, 
		"category" => esc_html__( "dawnthemes", 'ticketbox' ), 
		'params' => array( 
			array( 
				'type' => 'dropdown', 
				'heading' => esc_html__( 'Style', 'ticketbox' ), 
				'param_name' => 'style', 
				'admin_label' => true, 
				'value' => array( 
					esc_html__( 'White', 'ticketbox' ) => 'white', 
					esc_html__( 'Black', 'ticketbox' ) => 'black' ), 
				'description' => esc_html__( 'Select style.', 'ticketbox' ) ), 
			array( 
				'type' => 'ui_datepicker', 
				'heading' => esc_html__( 'Countdown end', 'ticketbox' ), 
				'param_name' => 'end', 
				'description' => esc_html__( 'Please select day to end.', 'ticketbox' ), 
				'value' => '' ), 
			array( 
				'param_name' => 'el_class', 
				'heading' => __( '(Optional) Extra class name', 'ticketbox' ), 
				'type' => 'textfield', 
				'value' => '', 
				"description" => __( 
					"If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 
					'ticketbox' ) ) ) ) );