<?php
function ticketbox_get_post_category() {
	// Get all post category
	$post_category = array();
	$post_categories = get_categories();
	$post_category[esc_html__( '--Select--', 'ticketbox' )] = '';
	foreach ( $post_categories as $p_cat ) {
		$post_category[$p_cat->name] = $p_cat->slug;
	}
	return $post_category;
}