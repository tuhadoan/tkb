<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit(); // Exit if accessed directly
}

require_once get_template_directory() . '/includes/vc-extend/functions.php';

$shorcodes = glob( get_template_directory() . '/includes/vc-extend/shortcodes/*.php' );

foreach ( $shorcodes as $shortcode ){
	require_once($shortcode);
}