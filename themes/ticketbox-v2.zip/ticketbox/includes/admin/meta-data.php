<?php
/*
 * DawnThemes Meta Box
 * 
 * This class loads all the methods and helpers specific to build a meta box.
 */

if (! class_exists ( 'DawnThemes_Metaboxes' )) :
	class DawnThemes_Metaboxes {
		
		function __construct() {
			if( !is_admin() ){
				return;
			}
			
			add_action ( 'add_meta_boxes', array (&$this, 'add_meta_boxes' ), 30 );
			add_action ( 'save_post', array (&$this,'save_meta_boxes' ), 1, 2 );
			
			add_action( 'admin_print_scripts-post.php', array( &$this, 'enqueue_scripts' ) );
			add_action( 'admin_print_scripts-post-new.php', array( &$this, 'enqueue_scripts' ) );
			
		}
		
		public function add_meta_boxes() {
			$meta_boxes = array();
			
			// Post Gallery
			$meta_box_post_gallery = array (
				'id' => 'dt-metabox-post-gallery',
				'title' => esc_html__( 'Gallery Settings', 'ticketbox' ),
				'description' =>'',
				'post_type' => 'post',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array (
					array (
						'label' => esc_html__( 'Gallery', 'ticketbox' ),
						'name' => '_dt_gallery',
						'type' => 'gallery',
					),
				)
			);
			add_meta_box ( $meta_box_post_gallery['id'], $meta_box_post_gallery['title'], 'dawnthemes_render_meta_boxes', $meta_box_post_gallery['post_type'],$meta_box_post_gallery['context'], $meta_box_post_gallery['priority'], $meta_box_post_gallery );
			
			//Post Quote
			$meta_box_post_quote = array(
				'id' => 'dt-metabox-post-quote',
				'title' =>  esc_html__('Quote Settings', 'ticketbox'),
				'description' => '',
				'post_type' => 'post',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array(
					array(
						'label' =>  esc_html__('Quote Content', 'ticketbox'),
						'description' => esc_html__('Please type the text for your quote here.', 'ticketbox'),
						'name' => '_dt_quote',
						'type' => 'textarea',
					),
					array(
						'label' =>  esc_html__('By', 'ticketbox'),
						'name' => '_dt_quote_author',
						'type' => 'text',
					)
				)
			);
			add_meta_box ( $meta_box_post_quote['id'], $meta_box_post_quote['title'], 'dawnthemes_render_meta_boxes', $meta_box_post_quote['post_type'],$meta_box_post_quote['context'], $meta_box_post_quote['priority'], $meta_box_post_quote );
			
			//Post Link
			$meta_box_post_link = array(
				'id' => 'dt-metabox-post-link',
				'title' =>  esc_html__('Link Settings', 'ticketbox'),
				'description' => '',
				'post_type' => 'post',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array(
					array(
						'label' =>  esc_html__('Link URL', 'ticketbox'),
						'description' => esc_html__('Please input the URL for your link. I.e. http://www.example.com', 'ticketbox'),
						'name' => '_dt_link',
						'type' => 'text',
					)
				)
			);
			add_meta_box ( $meta_box_post_link['id'], $meta_box_post_link['title'], 'dawnthemes_render_meta_boxes', $meta_box_post_link['post_type'],$meta_box_post_link['context'], $meta_box_post_link['priority'], $meta_box_post_link );
				
			//Post  Video
			$meta_box_post_video = array(
				'id' => 'dt-metabox-post-video',
				'title' => esc_html__('Video Settings', 'ticketbox'),
				'description' => '',
				'post_type' => 'post',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array(
					array(
						'type' => 'heading',
						'heading'=> esc_html__('Use service video','ticketbox'),
					),
					array(
						'label' => esc_html__('Embedded Code', 'ticketbox'),
						'description' => wp_kses( __('Used when you select Video format. Enter a Youtube, Vimeo, Soundcloud, etc URL. See supported services at <a href="http://codex.wordpress.org/Embeds">http://codex.wordpress.org/Embeds</a>.', 'ticketbox'), array( 'a' => array('href'=>array()) ) ),
						'name' => '_dt_video_embed',
						'type' => 'text',
						'hidden'=>true,
					),
					/*array(
						'type' => 'heading',
						'heading'=> esc_html__('Use hosted video','ticketbox'),
					),
					array(
						'label' => esc_html__('MP4 File URL', 'ticketbox'),
						'description' => esc_html__('Please enter in the URL to the .m4v video file.', 'ticketbox'),
						'name' => '_dt_video_mp4',
						'type' => 'media',
					),
					array(
						'label' => esc_html__('OGV/OGG File URL', 'ticketbox'),
						'description' => esc_html__('Please enter in the URL to the .ogv or .ogg video file.', 'ticketbox'),
						'name' => '_dt_video_ogv',
						'type' => 'media',
					),
					array(
						'label' => esc_html__('WEBM File URL', 'ticketbox'),
						'description' => esc_html__('Please enter in the URL to the .webm video file.', 'ticketbox'),
						'name' => '_dt_video_webm',
						'type' => 'media',
					),*/
				)
			);
			add_meta_box ( $meta_box_post_video['id'], $meta_box_post_video['title'], 'dawnthemes_render_meta_boxes', $meta_box_post_video['post_type'],$meta_box_post_video['context'], $meta_box_post_video['priority'], $meta_box_post_video );
				
			//Post  Audio
			$meta_box_post_audio = array(
				'id' => 'dt-metabox-post-audio',
				'title' =>  esc_html__('Audio Settings', 'ticketbox'),
				'description' => '',
				'post_type' => 'post',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array(
					array(
						'type' => 'heading',
						'heading'=> esc_html__('Use service audio','ticketbox'),
					),
					array(
						'label' => esc_html__('Audio Embed', 'ticketbox'),
						'description' => esc_html__('URL or code embed.', 'ticketbox'),
						'name' => '_dt_audio_embed',
						'type' => 'text',
					),
					array(
						'type' => 'heading',
						'heading'=> esc_html__('Use hosted video','ticketbox'),
					),
					array(
						'label' => esc_html__('MP3 File URL', 'ticketbox'),
						'description' => esc_html__('Please enter in the URL to the .mp3 file', 'ticketbox'),
						'name' => '_dt_audio_mp3',
						'type' => 'media',
					),
					array(
						'label' => esc_html__('OGA File URL', 'ticketbox'),
						'description' => esc_html__('Please enter in the URL to the .ogg or .oga file', 'ticketbox'),
						'name' => '_dt_audio_ogg',
						'type' => 'media',
					)
				)
			);
			add_meta_box ( $meta_box_post_audio['id'], $meta_box_post_audio['title'], 'dawnthemes_render_meta_boxes', $meta_box_post_audio['post_type'],$meta_box_post_audio['context'], $meta_box_post_audio['priority'], $meta_box_post_audio );
				
			//Post Settings
			$post_meta_box = array (
				'id' => 'dt-metabox-setting',
				'title' => esc_html__ ( 'Post Settings', 'ticketbox' ),
				'description' =>'',
				'post_type' => 'post',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array (
					array (
						'label' => esc_html__ ( 'Post Layout', 'ticketbox' ),
						'description' => esc_html__ ( 'Default to use the setting in Theme Options.', 'ticketbox' ),
						'name' => 'single-layout',
						'type' => 'image_select',
						'options'=>array(
							''=> array('alt' => 'Default', 'img' => DTINC_ASSETS_URL . '/images/0col.png'),
							'full-width'=> array('alt' => 'Fullwidth', 'img' => DTINC_ASSETS_URL . '/images/1col.png'),
							'left-sidebar'=> array('alt' => '2 Column Left', 'img' => DTINC_ASSETS_URL . '/images/2cl.png'),
							'right-sidebar'=> array('alt' => '2 Column Right', 'img' => DTINC_ASSETS_URL . '/images/2cr.png'),
						)
					),
					array (
						'label' => esc_html__ ( 'Post Style', 'ticketbox' ),
						'description' => esc_html__ ( 'Default to use the setting in Theme Options.', 'ticketbox' ),
						'name' => 'single-style',
						'type' => 'select',
						'options'=>array(
							''=> esc_html__('Default','ticketbox'),
							'style_1'=> esc_html__('Style 1','ticketbox'),
							'style_2'=> esc_html__('Style 2','ticketbox'),
							'style_3'=> esc_html__('Style 3','ticketbox'),
						)
					),
					array (
						'label' => esc_html__ ( 'Featured', 'ticketbox' ),
						'description' => esc_html__ ( 'Make this post featured. Featured posts will appear in DT Posts Wiget (orderby Featured).', 'ticketbox' ),
						'name' => 'post_meta_featured_post',
						'type' => 'select',
						'options'=>array(
							'no'=> esc_html__('No','ticketbox'),
							'yes'=> esc_html__('Yes','ticketbox')
						)
					),
				)
			);
			add_meta_box ( $post_meta_box['id'], $post_meta_box['title'], 'dawnthemes_render_meta_boxes', $post_meta_box['post_type'],$post_meta_box['context'], $post_meta_box['priority'], $post_meta_box );
			
		
			//Page Settings
			$revsliders = array();
			if ( ! function_exists( 'is_plugin_active' ) ) {
				include_once ( ABSPATH . 'wp-admin/includes/plugin.php' );
			}
			if ( is_plugin_active( 'revslider/revslider.php' ) ) {
				global $wpdb;
				$rs = $wpdb->get_results(
					"
						  SELECT id, title, alias
						  FROM " . $wpdb->prefix . "revslider_sliders
						  ORDER BY id ASC LIMIT 999
						  "
				);
				if ( $rs ) {
					foreach ( $rs as $slider ) {
						$revsliders[$slider->alias] = $slider->title;
					}
				} else {
					$revsliders[0] = esc_html__( 'No sliders found', 'ticketbox' );
				}
			}
			$menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
			$menu_options[''] = esc_html__('Default Menu...','ticketbox');
			foreach ( $menus as $menu ) {
				$menu_options[$menu->term_id] = $menu->name;
			}
			$page_meta_box = array (
				'id' => 'dt-metabox-page-settings',
				'title' => esc_html__( 'Page Settings', 'ticketbox' ),
				'description' =>'',
				'post_type' => 'page',
				'context' => 'normal',
				'priority' => 'high',
				'fields' => array (
					array (
						'label' => esc_html__( 'Page Heading', 'ticketbox' ),
						'description' => esc_html__( 'Enable/disable page heading or custom page heading', 'ticketbox' ),
						'name' => 'page_heading',
						'type' => 'select',
						'value'=>'heading',
						'options'=>array(
							'heading'=> esc_html__('Heading','ticketbox'),
							'rev'=> esc_html__('Use Revolution Slider','ticketbox'),
							'0'=> esc_html__('Hide','ticketbox')
						)
					),
					array (
						'label' => esc_html__( 'Revolution Slider', 'ticketbox' ),
						'description' => esc_html__( 'Select your Revolution Slider.', 'ticketbox' ),
						'name' => 'rev_alias',
						'type' => 'select',
						'options'=>$revsliders,
					),
					array (
						'label' => esc_html__( 'Page Heading Background Image', 'ticketbox' ),
						'description' => esc_html__( 'Custom heading background image.', 'ticketbox' ),
						'name' => 'page_heading_background_image',
						'type' => 'image',
					),
					array (
						'label' => esc_html__( 'Content Page no Padding', 'ticketbox' ),
						'description' => esc_html__( 'If checked. content of page  with no padding top and padding bottom', 'ticketbox' ),
						'name' => '_dt_no_padding',
						'type' => 'checkbox',
					),
					/*array (
						'label' => esc_html__( 'Show Page Title', 'ticketbox' ),
						'description' => '',
						'name' => 'show_title',
						'type' => 'select',
						'options'=>array(
							''=> esc_html__('No','ticketbox'),
							'yes'=> esc_html__('Yes','ticketbox'),
						)
					),
					array (
						'label' => esc_html__( 'Show Breadcrumbs', 'ticketbox' ),
						'description' => '',
						'name' => '_dt_show_breadcrumbs',
						'type' => 'select',
						'options'=>array(
							'no'=> esc_html__('No','ticketbox'),
							'yes'=> esc_html__('Yes','ticketbox'),
							
						)
					),*/
					array (
						'label' => esc_html__( 'Header Style', 'ticketbox' ),
						'description' => esc_html__( 'Please select your header style here.', 'ticketbox' ),
						'name' => 'header_style',
						'type' => 'select',
						'options'=>array(
								'-1'=> esc_html__('Global','ticketbox'),
							'layout_1'=> esc_html__('Layout 1','ticketbox'),
							'layout_2'=> esc_html__('Layout 2','ticketbox'),
							'layout_3'=> esc_html__('Layout 3','ticketbox'),
							'layout_4'=> esc_html__('Layout 4','ticketbox')
						)
					),
					array (
						'label' => esc_html__( 'Main Navigation Menu', 'ticketbox' ),
						'description' => esc_html__( 'Select which main menu displays on this page.', 'ticketbox' ),
						'name' => 'main_menu',
						'type' => 'select',
						'value'=>'',
						'options'=>$menu_options,
					),
					array (
						'label' => esc_html__( 'Main Sidebar', 'ticketbox' ),
						'description' => esc_html__( 'Select sidebar for page with 2 or 3 colums.', 'ticketbox' ),
						'name' => 'main_sidebar',
						'type' => 'widgetised_sidebars',
					),
				)
			);
			add_meta_box ( $page_meta_box['id'], $page_meta_box['title'], 'dawnthemes_render_meta_boxes', $page_meta_box['post_type'],$page_meta_box['context'], $page_meta_box['priority'], $page_meta_box );
		}
		
		public function add_video_featured_image($att_id){
			$p = get_post($att_id);
			update_post_meta($p->post_parent,'_thumbnail_id',$att_id);
		}
		
		
		public function save_meta_boxes($post_id, $post) {
			// $post_id and $post are required
			if (empty ( $post_id ) || empty ( $post )) {
				return;
			}
			// Dont' save meta boxes for revisions or autosaves
			if (defined ( 'DOING_AUTOSAVE' ) || is_int ( wp_is_post_revision ( $post ) ) || is_int ( wp_is_post_autosave ( $post ) )) {
				return;
			}
			// Check the nonce
			if (empty ( $_POST ['dt_meta_box_nonce'] ) || ! wp_verify_nonce ( $_POST ['dt_meta_box_nonce'], 'dt_meta_box_nonce' )) {
				return;
			}
			
			// Check the post being saved == the $post_id to prevent triggering this call for other save_post events
			if (empty ( $_POST ['post_ID'] ) || $_POST ['post_ID'] != $post_id) {
				return;
			}
			
			// Check user has permission to edit
			if (! current_user_can ( 'edit_post', $post_id )) {
				return;
			}
			if(isset( $_POST['dt_meta'] )){
				$dt_meta = $_POST['dt_meta'];
				if(get_post_format() == 'video' && dawnthemes_get_theme_option('blog_get_video_thumbnail','1') == '1'){
					$_dt_video_embed = $dt_meta['_dt_video_embed'];
					if(dawnthemes_is_video_support($_dt_video_embed) && ($_dt_video_embed != dawnthemes_get_post_meta('video_embed_hidden'))){
						$videoThumbUrl = dawnthemes_get_video_thumb_url($_dt_video_embed);
						if (!empty($videoThumbUrl)) {
							 // add the function above to catch the attachments creation
							add_action('add_attachment',array(&$this,'add_video_featured_image'));
							// load the attachment from the URL
							media_sideload_image($videoThumbUrl, $post_id, $post_id);
							// we have the Image now, and the function above will have fired too setting the thumbnail ID in the process, so lets remove the hook so we don't cause any more trouble
							remove_action('add_attachment',array(&$this,'add_video_featured_image'));
						}
					}
				}
				// Process
				foreach( (array)$_POST['dt_meta'] as $key=>$val ){
					$val = wp_unslash($val);
					if(is_array($val)){
						$option_value = array_filter( array_map( 'sanitize_text_field', (array) $val ) );
						update_post_meta( $post_id, $key, $option_value );
					}else{
						update_post_meta( $post_id, $key, wp_kses_post($val) );
					}
				}
			}
			do_action('dt_metabox_save',$post_id);
		}
		
		public function enqueue_scripts(){
			wp_enqueue_style('dt-meta-box',DTINC_ASSETS_URL.'/css/meta-box.css',null,DTINC_VERSION);
			wp_enqueue_script('dt-meta-box',DTINC_ASSETS_URL.'/js/meta-box.js',array('jquery','jquery-ui-sortable'),DTINC_VERSION,true);
		}
		
	}

	new DawnThemes_Metaboxes();

endif;
