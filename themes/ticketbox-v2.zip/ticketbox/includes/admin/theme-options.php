<?php
if ( function_exists( 'dawnthemes_register_theme_options' ) ) :
	/*
	 * Initialize Theme Options
	 */
	add_action( 'init', 'ticketbox_theme_options' );

	function ticketbox_theme_options() {
		$section = array();
		
		$section = array( 
			'general' => array( 
				'icon' => 'fa fa-home', 
				'title' => esc_html__( 'General', 'ticketbox' ), 
				'desc' => esc_html__( 'Here you will set your site-wide preferences', 'ticketbox' ), 
				'fields' => array( 
					array( 
						'name' => 'logo', 
						'type' => 'image', 
						'value' => get_template_directory_uri() . '/assets/images/logo.png', 
						'label' => esc_html__( 'Logo', 'ticketbox' ), 
						'desc' => esc_html__( 'Upload your own logo.', 'ticketbox' ) ), 
					array( 
						'name' => 'sticky_logo', 
						'type' => 'image', 
						'value' => get_template_directory_uri() . '/assets/images/logo.png', 
						'label' => esc_html__( 'Sticky Logo', 'ticketbox' ), 
						'desc' => esc_html__( 'Upload your own logo.This is optional use when fixed menu', 'ticketbox' ) ), 
					
					// array(
					// 'name' => 'logo-transparent',
					// 'type' => 'image',
					// 'value' => get_template_directory_uri() . '/assets/images/logo-dark.png',
					// 'label' => esc_html__( 'Transparent Menu Logo', 'ticketbox' ),
					// 'desc' => esc_html__(
					// 'Upload your own logo.This is optional use for menu transparent',
					// 'ticketbox' ) ),
					// array(
					// 'name' => 'logo-mobile',
					// 'type' => 'image',
					// 'value' => get_template_directory_uri() . '/assets/images/logo-mobile.png',
					// 'label' => esc_html__( 'Mobile Version Logo', 'ticketbox' ),
					// 'desc' => esc_html__(
					// 'Use this option to change your logo for mobile devices if your logo width is quite long to fit
					// in mobile device screen.',
					// 'ticketbox' ) ),
					// array(
					// 'name' => 'apple57',
					// 'type' => 'image',
					// 'label' => esc_html__( 'Apple Iphone Icon', 'ticketbox' ),
					// 'desc' => esc_html__( 'Apple Iphone Icon (57px 57px).', 'ticketbox' ) ),
					// array(
					// 'name' => 'apple72',
					// 'type' => 'image',
					// 'label' => esc_html__( 'Apple iPad Icon', 'ticketbox' ),
					// 'desc' => esc_html__( 'Apple Iphone Retina Icon (72px 72px).', 'ticketbox' ) ),
					// array(
					// 'name' => 'apple114',
					// 'type' => 'image',
					// 'label' => esc_html__( 'Apple Retina Icon', 'ticketbox' ),
					// 'desc' => esc_html__( 'Apple iPad Retina Icon (144px 144px).', 'ticketbox' ) ),
					/*array( 
						'name' => 'back_to_top', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Back To Top Button', 'ticketbox' ), 
						'value' => 1, 
						'desc' => esc_html__( 
							'Toggle whether or not to enable a back to top button on your pages.', 
							'ticketbox' ) )*/
				)
			),
			// 'design_layout' => array(
			// 'icon' => 'fa fa-columns',
			// 'title' => esc_html__( 'Design and Layout', 'ticketbox' ),
			// 'desc' => esc_html__( 'Customize Design and Layout', 'ticketbox' ),
			// 'fields' => array(
			// array(
			// 'name' => 'body-bg',
			// 'type' => 'color',
			// 'label' => esc_html__( 'Body background', 'ticketbox' ),
			// 'value' => '' ) ) ),
			'color_typography' => array( 
				'icon' => 'fa fa-font', 
				'title' => esc_html__( 'Color and Typography', 'ticketbox' ), 
				'desc' => esc_html__( 'Customize Color and Typography', 'ticketbox' ), 
				'fields' => array( 
					array( 
						'name' => 'theme-mode', 
						'type' => 'select', 
						'label' => esc_html__( 'Theme Mode', 'ticketbox' ), 
						'desc' => esc_html__( 'Select template background white or dark mode.', 'ticketbox' ), 
						'options' => array( 
							'white' => esc_html__( 'White Mode', 'ticketbox' ), 
							'dark' => esc_html__( 'Dark Mode', 'ticketbox' ) ), 
						'value' => 'white' ), 
					array( 
						'name' => 'main_color', 
						'type' => 'color', 
						'label' => esc_html__( 'Main Color', 'ticketbox' ), 
						'desc' => esc_html__( 'Choose main color of theme', 'ticketbox' ), 
						'value' => '#ff3333' ), 
					array( 
						'name' => 'main_font', 
						'type' => 'custom_font', 
						'field-label' => esc_html__( 'Main Font', 'ticketbox' ), 
						'desc' => esc_html__( 'Font family for body text', 'ticketbox' ), 
						'font-size' => 'true', 
						'value' => array() ), 
					array( 
						'name' => 'secondary_font', 
						'type' => 'custom_font', 
						'field-label' => esc_html__( 'Secondary Font', 'ticketbox' ), 
						'desc' => esc_html__( 'Font family for the secondary font (ex: heading text)', 'ticketbox' ), 
						'font-size' => 'false', 
						'value' => array() ), 
					array( 
						'name' => 'navbar_typography', 
						'type' => 'custom_font', 
						'field-label' => esc_html__( 'Navigation', 'ticketbox' ), 
						'desc' => esc_html__( 'Font family for the navigation', 'ticketbox' ), 
						'font-size' => 'false', 
						'value' => array() ) ) ), 
			'header' => array( 
				'icon' => 'fa fa-header', 
				'title' => esc_html__( 'Header', 'ticketbox' ), 
				'desc' => esc_html__( 'Customize Header', 'ticketbox' ), 
				'fields' => array( 
					
					// array(
					// 'name' => 'header-style',
					// 'type' => 'select',
					// 'label' => esc_html__( 'Header Style', 'ticketbox' ),
					// 'desc' => esc_html__( 'Please select your header style here.', 'ticketbox' ),
					// 'options' => array(
					// 'layout_1' => esc_html__( 'Layout 1', 'ticketbox' ),
					// 'layout_2' => esc_html__( 'Layout 2', 'ticketbox' ),
					// 'layout_3' => esc_html__( 'Layout 3', 'ticketbox' ),
					// 'layout_4' => esc_html__( 'Layout 4', 'ticketbox' ) ),
					// 'value' => 'layout_1' ),
					array( 
						'name' => 'sticky-menu', 
						'type' => 'switch', 
						'label' => esc_html__( 'Sticky Top menu', 'ticketbox' ), 
						'desc' => esc_html__( 'Enable or disable the sticky menu.', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'breaking_news', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Show Breaking News', 'ticketbox' ), 
						'desc' => esc_html__( 'Apply for home page.', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'breadcrumb', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Show breadcrumb', 'ticketbox' ), 
						'desc' => esc_html__( 'Enable or disable the site path under the page title.', 'ticketbox' ), 
						'value' => '1' ) ) ),  // 1 = checked | 0 = unchecked
			
			'blog' => array( 
				'icon' => 'fa fa-pencil', 
				'title' => esc_html__( 'Blog', 'ticketbox' ), 
				'desc' => esc_html__( 'Customize Blog', 'ticketbox' ), 
				'fields' => array( 
					array( 
						'name' => 'list_blog_setting', 
						'type' => 'heading', 
						'text' => esc_html__( 'List Blog Settings', 'ticketbox' ) ), 
					array( 
						'name' => 'blog-layout', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Main Blog Layout', 'ticketbox' ), 
						'desc' => esc_html__( 
							'Select main blog layout. Choose between 1, 2 or 3 column layout.', 
							'ticketbox' ), 
						'options' => array( 
							'full-width' => array( 
								'alt' => 'No sidebar', 
								'img' => DTINC_ASSETS_URL . '/images/1col.png' ), 
							'left-sidebar' => array( 
								'alt' => '2 Column Left', 
								'img' => DTINC_ASSETS_URL . '/images/2cl.png' ), 
							'right-sidebar' => array( 
								'alt' => '2 Column Right', 
								'img' => DTINC_ASSETS_URL . '/images/2cr.png' ) ), 
						'value' => 'right-sidebar' ), 
					array( 
						'name' => 'archive-layout', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Archive Layout', 'ticketbox' ), 
						'desc' => esc_html__( 
							'Select Archive layout. Choose between 1, 2 or 3 column layout.', 
							'ticketbox' ), 
						'options' => array( 
							'full-width' => array( 
								'alt' => 'No sidebar', 
								'img' => DTINC_ASSETS_URL . '/images/1col.png' ), 
							'left-sidebar' => array( 
								'alt' => '2 Column Left', 
								'img' => DTINC_ASSETS_URL . '/images/2cl.png' ), 
							'right-sidebar' => array( 
								'alt' => '2 Column Right', 
								'img' => DTINC_ASSETS_URL . '/images/2cr.png' ) ), 
						'value' => 'right-sidebar' ), 
					array( 
						'name' => 'blog-style', 
						'type' => 'select', 
						'label' => esc_html__( 'Style', 'ticketbox' ), 
						'desc' => esc_html__( 'How your blog posts will display.', 'ticketbox' ), 
						'options' => array( 
							'default' => esc_html__( 'Default', 'ticketbox' ), 
							'list' => esc_html__( 'List', 'ticketbox' ), 
							'grid' => esc_html__( 'Grid', 'ticketbox' ), 
							'classic' => esc_html__( 'Classic', 'ticketbox' ), 
							'masonry' => esc_html__( 'Masonry', 'ticketbox' ) ), 
						'value' => 'default' ), 
					array( 
						'name' => 'blog-columns', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Blogs Columns', 'ticketbox' ), 
						'desc' => esc_html__( 'Select blogs columns.', 'ticketbox' ), 
						'dependency' => array( 'element' => 'blog_style', 'value' => array( 'grid', 'masonry' ) ), 
						'options' => array( 
							'2' => array( 'alt' => '2 Column', 'img' => DTINC_ASSETS_URL . '/images/2col.png' ), 
							'3' => array( 'alt' => '3 Column', 'img' => DTINC_ASSETS_URL . '/images/3col.png' ), 
							'4' => array( 'alt' => '4 Column', 'img' => DTINC_ASSETS_URL . '/images/4col.png' ) ), 
						'value' => '3' ), 
					array( 
						'type' => 'select', 
						'label' => esc_html__( 'Pagination', 'ticketbox' ), 
						'name' => 'blog-pagination', 
						'options' => array( 
							'wp_pagenavi' => esc_html__( 'WP PageNavi', 'ticketbox' ), 
							'loadmore' => esc_html__( 'Ajax Load More', 'ticketbox' ), 
							'infinite_scroll' => esc_html__( 'Infinite Scrolling', 'ticketbox' ) ), 
						'value' => 'wp_pagenavi', 
						'dependency' => array( 
							'element' => 'blog_style', 
							'value' => array( 'default', 'list', 'grid', 'masonry' ) ), 
						'desc' => esc_html__( 'Choose pagination type.', 'ticketbox' ) ), 
					array( 
						'type' => 'text', 
						'label' => esc_html__( 'Load More Button Text', 'ticketbox' ), 
						'name' => 'blog-loadmore-text', 
						'dependency' => array( 'element' => "blog-pagination", 'value' => array( 'loadmore' ) ), 
						'value' => esc_html__( 'Load More', 'ticketbox' ) ), 
					array( 
						'name' => 'blog-excerpt-length', 
						'type' => 'text', 
						'label' => esc_html__( 'Excerpt Length', 'ticketbox' ), 
						'dependency' => array( 
							'element' => "blog_style", 
							'value' => array( 'default', 'list', 'grid', 'masonry' ) ), 
						'desc' => esc_html__( 'In Archive Blog. Enter the number words excerpt', 'ticketbox' ), 
						'value' => 55 ), 
					array( 
						'name' => 'blog_show_date', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Date Meta', 'ticketbox' ), 
						'desc' => esc_html__( 'In Archive Blog. Show/Hide the date meta', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'blog_show_comment', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Comment Meta', 'ticketbox' ), 
						'desc' => esc_html__( 'In Archive Blog. Show/Hide the comment meta', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'blog_show_category', 
						'type' => 'switch', 
						'label' => esc_html__( 'Show/Hide Category', 'ticketbox' ), 
						'desc' => esc_html__( 'In Archive Blog. Show/Hide the category meta', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'blog_show_tag', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'dependency' => array( 
							'element' => "blog_style", 
							'value' => array( 'default', 'medium', 'grid', 'masonry' ) ), 
						'label' => esc_html__( 'Tags', 'ticketbox' ), 
						'desc' => esc_html__( 'In Archive Blog. If enabled it will show tag.', 'ticketbox' ), 
						'value' => '0' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'blog_show_author', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'dependency' => array( 
							'element' => "blog_style", 
							'value' => array( 'default', 'medium', 'grid', 'masonry' ) ), 
						'label' => esc_html__( 'Author Meta', 'ticketbox' ), 
						'desc' => esc_html__( 'In Archive Blog. Show/Hide the author meta', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					
					array( 
						'name' => 'blog_show_readmore', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'dependency' => array( 
							'element' => "blog_style", 
							'value' => array( 'default', 'medium', 'grid', 'masonry' ) ), 
						'label' => esc_html__( 'Show/Hide Readmore', 'ticketbox' ), 
						'desc' => esc_html__( 'In Archive Blog. Show/Hide the post readmore', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					
					/*
					 * Single Blog Settings
					 */
					array( 
						'name' => 'single_blog_setting', 
						'type' => 'heading', 
						'text' => esc_html__( 'Single Blog Settings', 'ticketbox' ) ), 
					array( 
						'name' => 'single-layout', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Single Blog Layout', 'ticketbox' ), 
						'desc' => esc_html__( 
							'Select single content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 
							'ticketbox' ), 
						'options' => array( 
							'full-width' => array( 
								'alt' => 'No sidebar', 
								'img' => DTINC_ASSETS_URL . '/images/1col.png' ), 
							'left-sidebar' => array( 
								'alt' => '2 Column Left', 
								'img' => DTINC_ASSETS_URL . '/images/2cl.png' ), 
							'right-sidebar' => array( 
								'alt' => '2 Column Right', 
								'img' => DTINC_ASSETS_URL . '/images/2cr.png' ) ), 
						'value' => 'right-sidebar' ), 
					array( 
						'name' => 'single-style', 
						'type' => 'select', 
						'label' => esc_html__( 'Style', 'ticketbox' ), 
						'desc' => esc_html__( 'How your post will display.', 'ticketbox' ), 
						'options' => array( 
							'style_1' => esc_html__( 'Style 1', 'ticketbox' ), 
							'style_2' => esc_html__( 'Style 2', 'ticketbox' ), 
							'style_3' => esc_html__( 'Style 3', 'ticketbox' ) ), 
						'value' => 'style_1' ), 
					
					// as---
					array( 
						'name' => 'single_show_date', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Date Meta', 'ticketbox' ), 
						'desc' => esc_html__( 'In Single Blog. Show/Hide the date meta', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'single_show_category', 
						'type' => 'switch', 
						'label' => esc_html__( 'Show/Hide Category', 'ticketbox' ), 
						'desc' => esc_html__( 'In Single Blog. Show/Hide the category', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'single_show_author', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Author Meta', 'ticketbox' ), 
						'desc' => esc_html__( 'In Single Blog. Show/Hide the author meta', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'single_show_tag', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Show/Hide Tag', 'ticketbox' ), 
						'desc' => esc_html__( 'In Single Blog. If enabled it will show tag.', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
						                  
					// as--
					array( 
						'name' => 'single_show_authorbio', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Show Author Bio', 'ticketbox' ), 
						'desc' => esc_html__( 
							'Display the author bio at the bottom of post on single post page ?', 
							'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
						                  // array(
						                  // 'name' => 'single_show_postnav',
						                  // 'type' => 'switch',
						                  // 'on' => esc_html__( 'Show', 'ticketbox' ),
						                  // 'off' => esc_html__( 'Hide', 'ticketbox' ),
						                  // 'label' => esc_html__( 'Show Next/Prev Post Link On Single Post Page',
						                  // 'ticketbox'
						                  // ),
						                  // 'desc' => esc_html__(
						                  // 'Using this will add a link at the bottom of every post page that leads to the
						                  // next/prev post.',
						                  // 'ticketbox' ),
						                  // 'value' => '1' ), // 1 = checked | 0 = unchecked
					array( 
						'name' => 'show_related_posts', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Show Related Post On Single Post Page', 'ticketbox' ), 
						'desc' => esc_html__( 'Display related post the bottom of posts?', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'show_post_share', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Show Sharing Button', 'ticketbox' ), 
						'desc' => esc_html__( 
							'Activate this to enable social sharing buttons on single post page.', 
							'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_facebook', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Facebook', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_twitter', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Twitter', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_linkedIn', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on LinkedIn', 'ticketbox' ), 
						'value' => '0' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_tumblr', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Tumblr', 'ticketbox' ), 
						'value' => '0' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_google', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Google+', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_pinterest', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Pinterest', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'sharing_email', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show_post_share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Email', 'ticketbox' ), 
						'value' => '1' ) ) ) ); // 1 = checked | 0 = unchecked

		
		if ( defined( 'WOOCOMMERCE_VERSION' ) ) {
			$section['woocommerce'] = array( 
				'icon' => 'fa fa-shopping-cart', 
				'title' => esc_html__( 'Woocommerce', 'ticketbox' ), 
				'desc' => esc_html__( 'Customize Woocommerce', 'ticketbox' ), 
				'fields' => array( 
					array( 
						'name' => 'woo-cart-nav', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Cart In header', 'ticketbox' ), 
						'desc' => esc_html__( 'This will show cat in header.', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'woo-cart-mobile', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'label' => esc_html__( 'Mobile Cart Icon', 'ticketbox' ), 
						'desc' => esc_html__( 
							'This will show on mobile menu a shop icon with the number of cart items.', 
							'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'list_product_setting', 
						'type' => 'heading', 
						'text' => esc_html__( 'List Product Settings', 'ticketbox' ) ), 
					array( 
						'name' => 'woo-shop-layout', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Shop Layout', 'ticketbox' ), 
						'desc' => esc_html__( 'Select shop layout.', 'ticketbox' ), 
						'options' => array( 
							'full-width' => array( 
								'alt' => 'No sidebar', 
								'img' => DTINC_ASSETS_URL . '/images/1col.png' ), 
							'left-sidebar' => array( 
								'alt' => '2 Column Left', 
								'img' => DTINC_ASSETS_URL . '/images/2cl.png' ), 
							'right-sidebar' => array( 
								'alt' => '2 Column Right', 
								'img' => DTINC_ASSETS_URL . '/images/2cr.png' ) ), 
						'value' => 'right-sidebar' ), 
					array( 
						'name' => 'woo-category-layout', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Product Category Layout', 'ticketbox' ), 
						'desc' => esc_html__( 'Select product category layout.', 'ticketbox' ), 
						'options' => array( 
							'full-width' => array( 
								'alt' => 'No sidebar', 
								'img' => DTINC_ASSETS_URL . '/images/1col.png' ), 
							'left-sidebar' => array( 
								'alt' => '2 Column Left', 
								'img' => DTINC_ASSETS_URL . '/images/2cl.png' ), 
							'right-sidebar' => array( 
								'alt' => '2 Column Right', 
								'img' => DTINC_ASSETS_URL . '/images/2cr.png' ) ), 
						'value' => 'right-sidebar' ), 
					array( 
						'name' => 'dt_woocommerce_view_mode', 
						'type' => 'buttonset', 
						'label' => esc_html__( 'Default View Mode', 'ticketbox' ), 
						'desc' => esc_html__( 'Select default view mode', 'ticketbox' ), 
						'value' => 'grid', 
						'options' => array( 
							'grid' => esc_html__( 'Grid', 'ticketbox' ), 
							'list' => esc_html__( 'List', 'ticketbox' ) ) ), 
					array( 
						'name' => 'woo-per-page', 
						'type' => 'text', 
						'value' => 12, 
						'label' => esc_html__( 'Number of Products per Page', 'ticketbox' ), 
						'desc' => esc_html__( 'Enter the products of posts to display per page.', 'ticketbox' ) ), 
					array( 
						'name' => 'single_product_setting', 
						'type' => 'heading', 
						'text' => esc_html__( 'Single Product Settings', 'ticketbox' ) ), 
					array( 
						'name' => 'woo-product-layout', 
						'type' => 'image_select', 
						'label' => esc_html__( 'Single Product Layout', 'ticketbox' ), 
						'desc' => esc_html__( 'Select single product layout.', 'ticketbox' ), 
						'options' => array( 
							'full-width' => array( 
								'alt' => 'No sidebar', 
								'img' => DTINC_ASSETS_URL . '/images/1col.png' ), 
							'left-sidebar' => array( 
								'alt' => '2 Column Left', 
								'img' => DTINC_ASSETS_URL . '/images/2cl.png' ), 
							'right-sidebar' => array( 
								'alt' => '2 Column Right', 
								'img' => DTINC_ASSETS_URL . '/images/2cr.png' ) ), 
						'value' => 'right-sidebar' ), 
					array( 
						'name' => 'show-woo-share', 
						'type' => 'switch', 
						'label' => esc_html__( 'Show Sharing Button', 'ticketbox' ), 
						'desc' => esc_html__( 'Activate this to enable social sharing buttons.', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'woo-fb-share', 
						'type' => 'switch', 
						'on' => esc_html__( 'Show', 'ticketbox' ), 
						'off' => esc_html__( 'Hide', 'ticketbox' ), 
						'dependency' => array( 'element' => 'show-woo-share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Facebook', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'woo-tw-share', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show-woo-share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Twitter', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'woo-go-share', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show-woo-share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Google+', 'ticketbox' ), 
						'value' => '1' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'woo-pi-share', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show-woo-share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on Pinterest', 'ticketbox' ), 
						'value' => '0' ),  // 1 = checked | 0 = unchecked
					array( 
						'name' => 'woo-li-share', 
						'type' => 'switch', 
						'dependency' => array( 'element' => 'show-woo-share', 'value' => array( '1' ) ), 
						'label' => esc_html__( 'Share on LinkedIn', 'ticketbox' ), 
						'value' => '1' ) ) ); // 1 = checked | 0 = unchecked
		}
		
		$section['social'] = array( 
			'icon' => 'fa fa-twitter', 
			'title' => esc_html__( 'Social Profile', 'ticketbox' ), 
			'desc' => wp_kses( 
				__( 
					'Enter in your profile media locations here.<br><strong>Remember to include the "http://" in all URLs!</strong>', 
					'ticketbox' ), 
				array( 'br' => array(), 'strong' => array() ) ), 
			'fields' => array( 
				array( 'name' => 'facebook-url', 'type' => 'text', 'label' => esc_html__( 'Facebook URL', 'ticketbox' ) ), 
				array( 'name' => 'twitter-url', 'type' => 'text', 'label' => esc_html__( 'Twitter URL', 'ticketbox' ) ), 
				array( 
					'name' => 'google-plus-url', 
					'type' => 'text', 
					'label' => esc_html__( 'Google+ URL', 'ticketbox' ) ), 
				array( 'name' => 'youtube-url', 'type' => 'text', 'label' => esc_html__( 'Youtube URL', 'ticketbox' ) ), 
				array( 'name' => 'vimeo-url', 'type' => 'text', 'label' => esc_html__( 'Vimeo URL', 'ticketbox' ) ), 
				array( 
					'name' => 'pinterest-url', 
					'type' => 'text', 
					'label' => esc_html__( 'Pinterest URL', 'ticketbox' ) ), 
				array( 'name' => 'linkedin-url', 'type' => 'text', 'label' => esc_html__( 'LinkedIn URL', 'ticketbox' ) ), 
				array( 'name' => 'rss-url', 'type' => 'text', 'label' => esc_html__( 'RSS URL', 'ticketbox' ) ), 
				array( 
					'name' => 'instagram-url', 
					'type' => 'text', 
					'label' => esc_html__( 'Instagram URL', 'ticketbox' ) ), 
				array( 'name' => 'github-url', 'type' => 'text', 'label' => esc_html__( 'GitHub URL', 'ticketbox' ) ), 
				array( 'name' => 'behance-url', 'type' => 'text', 'label' => esc_html__( 'Behance URL', 'ticketbox' ) ), 
				array( 
					'name' => 'stack-exchange-url', 
					'type' => 'text', 
					'label' => esc_html__( 'Stack Exchange URL', 'ticketbox' ) ), 
				array( 'name' => 'tumblr-url', 'type' => 'text', 'label' => esc_html__( 'Tumblr URL', 'ticketbox' ) ), 
				array( 
					'name' => 'soundcloud-url', 
					'type' => 'text', 
					'label' => esc_html__( 'SoundCloud URL', 'ticketbox' ) ), 
				array( 'name' => 'dribbble-url', 'type' => 'text', 'label' => esc_html__( 'Dribbble URL', 'ticketbox' ) ), 
				array( 
					'name' => 'social-target', 
					'type' => 'select', 
					'label' => esc_html__( 'Target', 'ticketbox' ), 
					'desc' => esc_html__( 
						'The target attribute specifies where to open the linked social.', 
						'ticketbox' ), 
					'options' => array( 
						'_blank' => esc_html__( 'Blank', 'ticketbox' ), 
						'_self' => esc_html__( 'Layout 2', 'ticketbox' ) ), 
					'value' => '_blank' ) ) );
		
		$section['footer'] = array(
			'icon' => 'fa fa-list-alt',
			'title' => esc_html__( 'Footer', 'ticketbox' ),
			'desc' => esc_html__( 'Customize Footer', 'ticketbox' ),
			'fields' => array(
				array(
					'name' => 'footer-copyright',
					'type' => 'textarea',
					'label' => esc_html__( 'Footer Copyright Text', 'ticketbox' ),
					'desc' => esc_html__( 'Please enter the copyright section text.', 'ticketbox' ),
					'note' => esc_html__(
						'List of allowed HTML elements: <a></a> for links, <br/> for line break.',
						'ticketbox' ),
					'value' => wp_kses(
						__(
							'Copyright 2016 - Powered by <a href="http://dawnthemes.com/">DawnThemes</a>',
							'ticketbox' ),
						array( 'a' => array( 'href' => array() ) ) ) ),
				array(
					'name' => 'show_footer_social_profile',
					'type' => 'switch',
					'on' => esc_html__( 'Show', 'ticketbox' ),
					'off' => esc_html__( 'Hide', 'ticketbox' ),
					'label' => esc_html__( 'Show Social Profile on footer', 'ticketbox' ),
					'desc' => esc_html__(
						'Activate this to enable social profile buttons on foooter.',
						'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_facebook',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Facebook', 'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_twitter',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Twitter', 'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_google-plus',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Google+', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_youtube',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Youtube', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_vimeo',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Vimeo', 'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_pinterest',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Pinterest', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_linkedin',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share LinkedIn', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_rss',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share RSS', 'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_instagram',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Instagram', 'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_github',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share GitHub', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_behance',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Behance', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_stack-exchange',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Stack Exchange', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_tumblr',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Tumblr', 'ticketbox' ),
					'value' => '1' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_soundcloud',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share SoundCloud', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'show_footer_dribbble',
					'type' => 'switch',
					'dependency' => array( 'element' => 'show_footer_social_profile', 'value' => array( '1' ) ),
					'label' => esc_html__( 'Share Dribbble', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
					
				array(
					'name' => 'footer_color_setting',
					'type' => 'heading',
					'text' => esc_html__( 'Footer Color Scheme', 'ticketbox' ) ),
				array(
					'name' => 'footer-color',
					'type' => 'switch',
					'label' => esc_html__( 'Custom Footer Color Scheme', 'ticketbox' ),
					'value' => '0' ),  // 1 = checked | 0 = unchecked
				array(
					'name' => 'footer-custom-color',
					'type' => 'list_color',
					'dependency' => array( 'element' => 'footer-color', 'value' => array( '1' ) ),
					'options' => array(
						'footer-widget-bg' => esc_html__( 'Footer Widget Area Background', 'ticketbox' ),
						'footer-widget-color' => esc_html__( 'Footer Widget Area Color', 'ticketbox' ),
						'footer-widget-link' => esc_html__( 'Footer Widget Area Link', 'ticketbox' ),
						'footer-widget-link-hover' => esc_html__( 'Footer Widget Area Link Hover', 'ticketbox' ),
						'footer-bg' => esc_html__( 'Footer Copyright Background', 'ticketbox' ),
						'footer-color' => esc_html__( 'Footer Copyright Color', 'ticketbox' ),
						'footer-link' => esc_html__( 'Footer Copyright Link', 'ticketbox' ),
						'footer-link-hover' => esc_html__( 'Footer Copyright Link Hover', 'ticketbox' ) ) ) ) );
		
		$section['page_not_found'] = array( 
			'icon' => 'fa fa-exclamation-triangle', 
			'title' => esc_html__( '404 Page', 'ticketbox' ), 
			'fields' => array( 
				array( 
					'name' => 'page_not_found_bg', 
					'type' => 'image', 
					'value' => get_template_directory_uri() . '/assets/images/404-bg.jpg', 
					'label' => esc_html__( 'Background Image', 'ticketbox' ), 
					'desc' => '' ), 
				array( 
					'name' => 'page_not_found_subtitle', 
					'type' => 'textarea', 
					'label' => esc_html__( '404 SubTitle', 'ticketbox' ), 
					'value' => esc_html__( 'We are sorry', 'ticketbox' ) ), 
				array( 
					'type' => 'text', 
					'label' => esc_html__( '404 Heading', 'ticketbox' ), 
					'name' => 'page_not_found_title', 
					'value' => esc_html__( 'Page not found', 'ticketbox' ) ) ) );
		
		$section['custom_code'] = array( 
			'icon' => 'fa fa-code', 
			'title' => esc_html__( 'Custom Code', 'ticketbox' ), 
			'fields' => array( 
				array( 
					'name' => 'custom-css', 
					'type' => 'ace_editor', 
					'label' => esc_html__( 'Custom Style', 'ticketbox' ), 
					'desc' => esc_html__( 'Place you custom style here', 'ticketbox' ) ) ) );
		// array(
		// 'name' => 'custom-js',
		// 'type' => 'ace_editor',
		// 'label' => esc_html__('Custom Javascript','ticketbox'),
		// 'desc'=>esc_html__('Place you custom javascript here','ticketbox'),
		// ),
		
		$section['import_export'] = array( 
			'icon' => 'fa fa-refresh', 
			'title' => esc_html__( 'Import and Export', 'ticketbox' ), 
			'fields' => array( 
				array( 
					'name' => 'import', 
					'type' => 'import', 
					'field-label' => esc_html__( 
						'Input your backup file below and hit Import to restore your sites options from a backup.', 
						'ticketbox' ) ), 
				array( 
					'name' => 'export', 
					'type' => 'export', 
					'field-label' => esc_html__( 
						'Here you can download your current option settings.You can use it to restore your settings on this site (or any other site).', 
						'ticketbox' ) ) ) );
		
		dawnthemes_register_theme_options( $section );
	}




endif;