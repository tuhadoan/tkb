<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other 'pages' on your WordPress site will use a different template.
 *
 * @package dawn
 */
get_header();
$layout = 'full-width';
?>

<div id="main-content">
		<div class="row">
			<div id="primary" class="content-area <?php echo esc_attr(dawnthemes_get_main_class($layout))?>">
				<div id="content" class="main-content site-content" role="main">

					<?php
						// Start the Loop.
						while ( have_posts() ) : the_post();

							// Include the page content template.
							get_template_part( 'template-parts/single/content', 'page' );

							// If comments are open or we have at least one comment, load up the comment template.
							if ( comments_open() || get_comments_number() ) {
								comments_template();
							}
						endwhile;
					?>

				</div><!-- #content -->
			</div><!-- #primary -->
			<?php do_action('ticketbox_dt_left_sidebar');?>
			<?php do_action('ticketbox_dt_right_sidebar'); ?>
		</div><!-- .row -->
</div><!-- #main-content -->
<?php
get_footer();
