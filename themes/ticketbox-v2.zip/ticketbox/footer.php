<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #dawnthemes-page div elements.
 *
 * @package dawn
 */
$ticketbox_dt_footer_layout = dawnthemes_get_theme_option('footer_layout', 'footer-1');
$copyright = dawnthemes_get_theme_option('footer-copyright', '');
?>			
			<?php 
			if( !is_page_template('page-templates/page-full-width.php') ):
			?>
			</div><!-- .container.main-container -->
			<?php 
			endif;
			?>
		</div><!-- #main -->

		<footer id="footer" class="site-footer dark-div style-<?php echo esc_attr( $ticketbox_dt_footer_layout );?>">
			<?php if(dawnthemes_get_theme_option('back-to-top',1)): ?>
			<a id="scroll-to-top" href="" class="back-to-top"><i class="fa fa-arrow-up"></i></a>
			<?php endif;?>
			
			<?php
			ticketbox_dt_get_template("template-parts/footer/{$ticketbox_dt_footer_layout}.php", array(
				'copyright'		=> $copyright
			)); 
			?>
		</footer><!-- #footer -->
	</div><!-- #dawnthemes-page -->

	<?php wp_footer(); ?>
</body>
</html>