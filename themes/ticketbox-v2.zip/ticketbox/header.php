<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package dawn
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
</head>
<?php 
$header_layout = dawnthemes_get_theme_option('header_layout','header-1');
$is_sticky_menu = dawnthemes_get_theme_option('sticky_menu','yes') == 'yes' ? ' is_sticky_menu' : '';
?>
<body <?php body_class(); ?>>
<div class="offcanvas">
	  <a href="#" class="mobile-menu-toggle"><i class="fa fa-times-circle"></i></a>
      <div class="dt-sidenav-wrapper">
			<?php if( has_nav_menu('primary') ): ?>
			<nav id="side-navigation" class="site-navigation side-navigation">
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu', 'menu_id' => 'primary' ) ); ?>
			</nav>
			<?php else :?>
			<p class="dt-alert"><?php esc_html_e('Please sellect menu for Main navigation', 'ticketbox'); ?></p>
			<?php endif; ?>
		</div>
</div>

<div id="dawnthemes-page">
	<div class="offcanvas-overlay"></div>
	<div id="dt-sticky-navigation-holder" data-height="80">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="menu-toggle"><i class="fa fa-bars"></i></div>
					<div class="sticky-logo">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="logo" src="<?php echo dawnthemes_get_theme_option('sticky_logo', MATUBE_DT_ASSETS_URI . '/images/logo.png');?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"/></a>
					</div>
					<div class="dt-sticky-mainnav-wrapper"></div>
				</div>
			</div>
		</div>
	</div>
	<?php
	$header_class = '';
	$header_background_url = '';
	$page_heading_bg = dawnthemes_get_post_meta('page_heading_background_image', '', '');
	if( !empty($page_heading_bg) ){
		$header_background_url = wp_get_attachment_image_url($page_heading_bg, 'full');
		$header_class .= ' has-header-background';
	}
	
	if(is_404()){
		$header_background_url = dawnthemes_get_theme_option('page_not_found_bg', get_template_directory_uri() . '/assets/images/404-bg.jpg');
		if( !empty($header_background_url) ){
			$header_class .= ' has-header-background';
		}
	}
	
	$header_class .= $is_sticky_menu;
	?>
	<header id="header" class="site-header <?php echo esc_attr( $header_class );?>" <?php echo ($header_background_url != '' ? 'style="background-image:url('.$header_background_url.');"' : '');?>>
		<?php ticketbox_dt_get_template("template-parts/header/{$header_layout}.php"); ?>
	</header><!-- #header -->
	<?php
	$no_padding = dawnthemes_get_post_meta('no_padding');
	$site_main_class= (!empty($no_padding) ? ' no-padding ':'');
	?>
	<div id="main" class="site-main <?php echo esc_attr($site_main_class); ?>">
		<?php
		if( !is_page_template('page-templates/page-full-width.php') ):
		?>
		<div class="container main-container" >
		<?php 
		endif;
		?>