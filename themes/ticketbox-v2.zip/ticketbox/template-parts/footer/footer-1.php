<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$number_footer_sidebar = 0;
if( is_active_sidebar('footer-sidebar-1') ) $number_footer_sidebar = $number_footer_sidebar + 1;
if( is_active_sidebar('footer-sidebar-2') ) $number_footer_sidebar = $number_footer_sidebar + 1;
if( is_active_sidebar('footer-sidebar-3') ) $number_footer_sidebar = $number_footer_sidebar + 1;
if( is_active_sidebar('footer-sidebar-4') ) $number_footer_sidebar = $number_footer_sidebar + 1;
if( is_active_sidebar('footer-sidebar-5') ) $number_footer_sidebar = $number_footer_sidebar + 1;

if( $number_footer_sidebar > 0 ): ?>
<div id="footer-primary">
	<div id="footer-sidebar" class="footer-sidebar widget-area" role="complementary">
		<div class="container">
			<div class="row footer-primary__columns__<?php echo absint($number_footer_sidebar);?>">
				<?php
				for( $i = 0; $i <= 5 ; $i++):
					if( is_active_sidebar("footer-sidebar-$i") ): ?>
					<div class="footer-primary__group">
						<?php dynamic_sidebar( "footer-sidebar-$i" ); ?>
					</div>
					<?php
					endif;
				endfor;
				?>
			</div>
		</div>
	</div><!-- #footer-sidebar -->
</div><!-- #footer-primary -->
<?php
endif;
?>
<?php
$show_footer_social = false;
$show_footer_social_profile = dawnthemes_get_theme_option('show_footer_social_profile', "1");
$social_list = array();
$social_list_get = array(
	'facebook','twitter','google-plus','youtube','vimeo','pinterest','linkedin','instagram','github','behance','stack-exchange','tumblr','soundcloud','dribbble','rss'
);

if($show_footer_social_profile == '1'){
	foreach ($social_list_get as $social_get){
		if( dawnthemes_get_theme_option("show_footer_{$social_get}", '0') == '1' )
			$social_list[$social_get] = $social_get;
	}
}
if( $show_footer_social_profile == '1' &&  !empty($social_list) )
	$show_footer_social = true;
?>
<div class="footer-bottom">
	<div class="container">
		<div class="copyright-section <?php echo ($show_footer_social) ? 'has-footer-social':'';?>">
				<div class="site-info">
					<?php do_action( 'dt_credits' ); ?>
					<?php 
					echo ( isset( $copyright ) && $copyright !='' ) ? wp_kses($copyright, array(
					'a' => array(
						'href' => array(),
						'class' => array(),
						'data-original-title' => array(),
						'data-toggle' => array(),
						'title' => array()
					),
					'br' => array(),
					)) : 'Copyright 2016 &#169; <a href="#" title="TicketBox">TicketBox.</a>. All Rights Reserved'; ?>
				</div><!-- .site-info -->
				<?php 
				if( $show_footer_social ):
				?>
				<div class="footer-social-profile">
					<?php ticketbox_dt_print_social_profile($social_list); ?>
				</div>
				<?php endif;?>
			</div><!-- .copyright-section -->
	</div>
</div><!-- /.footer-bottom -->
