<?php
/**
 * The template part for displaying content
 *
 * @subpackage Dawn
 */
?>
<?php
$size = (isset($size)) ? $size : '';
$columns = (isset($columns)) ? $columns : '';

$get_video_thumbnail = dawnthemes_get_theme_option('blog_get_video_thumbnail','1') == '1' ? 'yes' : '';
$blog_show_date = dawnthemes_get_theme_option('blog_show_date','1') == '1' ? 'yes':'';
$blog_show_comment = dawnthemes_get_theme_option('blog_show_comment','1') == '1' ? 'yes':'';
$blog_show_category = dawnthemes_get_theme_option('blog_show_category','1') == '1' ? 'yes':'';
$blog_show_author = dawnthemes_get_theme_option('blog_show_author','1') == '1' ? 'yes':'';
$blog_show_tag = dawnthemes_get_theme_option('blog_show_tag','1') == '1' ? 'yes':'';
$show_readmore = dawnthemes_get_theme_option('blog_show_readmore','0') == '1' ? 'yes':'';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('col-md-12 col-sm-6' . $post_class); ?> itemscope="">
	<?php 
	if( has_post_thumbnail() ):
		if( $get_video_thumbnail == 'yes'){
			ticketbox_dt_post_featured('','',true,false,'','default', $size);
		}else{?>
			<div class="entry-featured <?php echo get_post_format() == 'video' ? 'video-featured' : '' ?>">
				<a class="post-thumbnail-link dt-image-link" href="<?php the_permalink(); ?>" aria-hidden="true">
					<?php the_post_thumbnail( 'post-thumbnail', array( 'alt' => the_title_attribute( 'echo=0' ) ) ); ?>
					<?php echo get_post_format() == 'video' ? '<div class="dt-icon-video"></div>' : '' ?>
				</a>
			</div>
		<?php
		}
		?>
	<?php 
	endif;?>
	<div class="hentry-wrap">
		<header class="post-header">
			<?php	
			the_title( '<h2 class="post-title" data-itemprop="name"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
			?>
		</header><!-- .entry-header -->
		<div class="entry-meta">
			<div class="entry-meta-content">
				<?php
				if( $blog_show_author == 'yes' ):
					printf('<span class="byline"><span class="author vcard">%1$s <a class="url fn n" href="%2$s" rel="author">%3$s</a></span></span>',
						esc_html__('By','ticketbox'),
						esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
						get_the_author()
					);
				endif;
				?>
				<?php
				if( $blog_show_date == 'yes' )
					ticketbox_dt_posted_on();
				?>
			</div>
			<div class="entry-meta__express">
				<span class="post-views"><?php echo ticketbox_get_post_views(get_the_ID()) . esc_html__(' views', 'ticketbox');?></span>
			</div>
		</div>
	</div><!-- .entry-meta -->
	<meta content="<?php echo get_the_author()?>" itemprop="author" />
</article><!-- #post-## -->
