<?php
/**
 * The template part for displaying single posts
 *
 * @package Dawn
 */

$single_show_date = dawnthemes_get_theme_option('single_show_date', '1');
$single_show_category = dawnthemes_get_theme_option('single_show_category', '1');
$single_show_author = dawnthemes_get_theme_option('single_show_author', '1');
$single_show_tag = dawnthemes_get_theme_option('single_show_tag', '1');
//$single_show_postnav = dawnthemes_get_theme_option('single_show_postnav', '1');
$single_show_authorbio = dawnthemes_get_theme_option('single_show_authorbio', '1');
$comments_type	= dawnthemes_get_theme_option('comments_type', 'wp');
?>
<div class="row">
	<div id="primary" class="content-area <?php echo esc_attr(dawnthemes_get_main_class($layout)) ?>">
		<div id="content" class="main-content site-content dawn-single-post" role="main">
			<?php
				// Start the Loop.
				while ( have_posts() ) : the_post();
					// Set post view count
					ticketbox_set_post_views(get_the_ID());
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<header class="entry-header">
							<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
							<div class="entry-meta">
								<?php
								if( $single_show_author == 1 ):
								printf('<span class="byline"><span class="author vcard">%1$s <a class="url fn n" href="%2$s" rel="author">%3$s</a></span></span>',
									esc_html__('By', 'ticketbox'),
									esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
									get_the_author()
								);
								endif;
								?>
								<?php
								if ( $single_show_date == 1 && 'post' == get_post_type() )
									ticketbox_dt_posted_on();
								?>
								<?php edit_post_link( esc_html__( ' Edit', 'ticketbox' ), '<span class="edit-link">', '</span>' ); ?>
								<div class="entry-meta__express">
									<?php
									if ( $comments_type === 'wp' && comments_open() && get_comments_number() ) :
									?>
										<span class="comments-link"><i class="fa fa-comments"></i><?php comments_popup_link( esc_html__( '0', 'ticketbox' ), esc_html__( '1', 'ticketbox' ), esc_html__( '%', 'ticketbox' ) ); ?></span>
									<?php
									endif;
									?>
									<span class="post-views"><i class="fa fa-eye"></i><?php echo ticketbox_get_post_views(get_the_ID());?></span>
								</div>
							</div><!-- .entry-meta -->
						</header><!-- .entry-header -->
						<?php ticketbox_dt_post_featured(); ?>
						<div class="post-content">
							<div class="entry-content">
								<?php
									the_content();
						
									wp_link_pages( array(
										'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'ticketbox' ) . '</span>',
										'after'       => '</div>',
										'link_before' => '<span>',
										'link_after'  => '</span>',
										'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'ticketbox' ) . ' </span>%',
										'separator'   => '<span class="screen-reader-text">, </span>',
									) );
								?>
							</div> <!-- .entry-content -->
						</div>
						<footer class="entry-footer">
							<?php if( dawnthemes_get_theme_option('show_post_share', '1') == '1' ): ?>
							<div class="entry-share">
								<span class="share-title"><?php echo esc_html__( 'Share this:', 'ticketbox' );?></span>
								<?php ticketbox_dt_print_social_share(); ?>
							</div>
							<?php endif;?>
							<?php if ( $single_show_category == 1 && in_array( 'category', get_object_taxonomies( get_post_type() ) ) && ticketbox_dt_categorized_blog() ) : ?>
							<div class="post-category">
								<span class="cat-title"><?php echo esc_html__( 'Category:', 'ticketbox' );?></span>
								<span class="cat-links"><?php echo get_the_category_list( esc_html_x( ', ', 'Used between list items, there is a space after the comma.', 'ticketbox' ) ); ?></span>
							</div>
							<?php
							endif;
							?>
					
							<?php
							if($single_show_tag == '1'):
								$tags_list = get_the_tag_list( '', _x( ', ', 'Used between list items, there is a space after the comma.', 'ticketbox' ) );
								if ( $tags_list ) {
									printf( '<div class="tags-list"><span class="tag-title">%1$s </span><span class="tag-links">%2$s</span></div>',
										_x( 'Tag:', 'Used before tag names.', 'ticketbox' ),
										$tags_list
									);
								}
							endif;
							?>
						</footer>
					</article><!-- #post-## -->
					<?php
					if ( 'post' === get_post_type() && $single_show_authorbio == 1) :?>
					<div class="author-info">
						<?php
						$author_avatar_size = apply_filters( 'dt_author_avatar_size', 340 );
						?>
						<div class="author-avatar">
							<?php echo get_avatar( get_the_author_meta( 'user_email' ), $author_avatar_size ); ?>
						</div>
						<div class="author-description">
							<div class="author-primary">
								<h5 class="author-title">
									<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );?>"><?php echo get_the_author(); ?></a>
								</h5>
								<div class="author-socials">
									<?php ticketbox_dt_show_author_social_links('', get_the_author_meta( 'ID' ), 'echo'); ?>
								</div>
							</div>
							<div class="author-desc"><?php echo get_the_author_meta('description'); ?></div>
						</div>
					</div>
					<?php
					endif;
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					
					if ( is_singular( 'attachment' ) ) {
						// Parent post navigation.
						the_post_navigation( array(
							'prev_text' => _x( '<span class="meta-nav">Published in</span><span class="post-title">%title</span>', 'Parent post link', 'ticketbox' ),
						) );
					} elseif ( is_singular( 'post' ) ) {
						// Previous/next post navigation.
						the_post_navigation( array(
							'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next', 'ticketbox' ) . '</span> ' .
								'<span class="screen-reader-text">' . __( 'Next post:', 'ticketbox' ) . '</span> ' .
								'<span class="post-title">%title</span>',
							'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous', 'ticketbox' ) . '</span> ' .
								'<span class="screen-reader-text">' . __( 'Previous post:', 'ticketbox' ) . '</span> ' .
								'<span class="post-title">%title</span>',
						) );
					}

					get_template_part( 'template-parts/single/single', 'related' );
				endwhile; // end of the loop.
			?>
		</div><!-- #content -->
</div><!-- #primary -->
<?php do_action('ticketbox_dt_left_sidebar');?>
<?php do_action('ticketbox_dt_right_sidebar'); ?>
</div><!-- .row -->
