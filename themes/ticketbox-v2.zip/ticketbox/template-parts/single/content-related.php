<?php
/**
 * The template part for displaying related posts
 *
 * @package Dawn
 */
?>

<div class="related-post-item col-md-3 col-sm-4 col-xs-6">
	<article id="post-<?php the_ID(); ?>" class="post">
		<?php 
		ticketbox_dt_post_featured('','',false,true,'','default');
		?>
		<?php the_title( sprintf('<h5 class="related-post-title"><a href="%s" rel="bookmark">', esc_url(get_permalink()) ), '</a></h5>' ); ?>
		<div class="entry-meta">
			<div class="entry-meta-content">
				<?php
				printf('<div class="byline"><span class="author vcard">%1$s <a class="url fn n" href="%2$s" rel="author">%3$s</a></span></div>',
					esc_html__('By', 'ticketbox'),
					esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
					get_the_author()
				);
				?>
				<?php
				ticketbox_dt_posted_on();
				?>
			</div>
			<div class="entry-meta__express">
				<span class="post-views"><?php echo ticketbox_get_post_views(get_the_ID()) . esc_html__(' views', 'ticketbox');?></span>
			</div>
		</div><!-- .entry-meta -->
	</article>
</div>
