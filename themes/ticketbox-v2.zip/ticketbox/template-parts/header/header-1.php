<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="top-header">
	<div id="dt-main-menu">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="header-main">
						<div class="menu-toggle"><i class="fa fa-bars"></i></div>
						<div class="logo-wrap sticky-logo">
							<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="logo" src="<?php echo dawnthemes_get_theme_option('logo', MATUBE_DT_ASSETS_URI . '/images/logo.png');?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"/></a></h1>
						</div>
						<div class="dt-mainnav-wrapper">
							<nav id="primary-navigation" class="site-navigation primary-navigation">
							<?php if( has_nav_menu('primary') ): ?>
								<?php
									wp_nav_menu(array( 'theme_location'  => 'primary','is_megamenu' => true));
								?>
							<?php else :?>
							<p class="dt-alert"><?php esc_html_e('Please sellect menu for Main navigation', 'ticketbox'); ?></p>
							<?php endif; ?>
							<div class="top-toolbar">
									<div class="cart"><a href="#" class="view-cart"><i class="fa fa-shopping-cart"></i> Cart <sup class="number">1</sup></a></div>
							</div>
							</nav>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
if( is_page() && dawnthemes_get_post_meta('page_heading', '', 'heading') == 'heading' || is_404() ):
?>
<div class="page-heading">
	<div class="container">
		<?php 
		if(is_404()):?>
		<div class="not-found-subtitle">
			<?php echo esc_html(dawnthemes_get_theme_option('page_not_found_subtitle')); ?>
		</div>
		<header class="page-header">
			<h1 class="page-not-found__title" ><?php echo esc_html(dawnthemes_get_theme_option('page_not_found_title')); ?></h1>
		</header>
		<?php
		else:
		?>
		<div class="row">
			<div class="col-md-6">
				<header class="entry-header">
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				</header><!-- .entry-header -->
			</div>
			<div class="col-md-6">
				<?php do_action('ticketbox_breadcrumbs', 10); ?>
			</div>
		</div>
		<?php endif;?>
	</div>
</div>
<?php endif; ?>